<?php
	$app_name = "Geely";
	$app_url = "http://190.92.199.143/geely_golive/"; 
	$current_url = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] .parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
?>
