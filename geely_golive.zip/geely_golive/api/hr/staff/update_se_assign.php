<?php
    // required headers
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: POST");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/staff.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $staff = new Staff($db);
    $data = json_decode(file_get_contents("php://input"));

    $staff->id = $data->id;
    $staff->sa_id = (!empty($data->sa_id))?(int)$data->sa_id:0;

    if($staff->updateAssignUnassign()){
        $msg_arr = array(
            "message" => "updated"
        );
    }else{
        $msg_arr = array(
            "message" => "error"
        );
    }
    echo json_encode($msg_arr);
?>