<?php
class LookupCheckList{
	private $conn;
	private $table_name = "lookup_check_list";

	public $id;
	public $category_id;
	public $category;
	public $subcategory_id;
	public $subcategory;
	public $check_list;
	public $type;
	public $order_no;

	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRows(){
		$query = "SELECT lcl.*, lccln.order_no AS c_order_no, group_order FROM lookup_check_list AS lcl LEFT JOIN lookup_category_cl_name AS lccln ON lcl.category_id=lccln.category_id WHERE lccln.check_list_name=:check_list_name ORDER BY lccln.order_no, lcl.order_no";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":check_list_name", $this->check_list_name);
		$stmt->execute();
		return $stmt;
	}
}
?>