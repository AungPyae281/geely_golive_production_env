<?php
class Order{
    private $conn;
    private $table_name = "order";
 
	public $id;
	public $date;
	public $oc_no;
	public $customer_id;
	public $broker_id;
	public $broker_name;

	public $vehicle_status;
	public $brand;
	public $model;
    public $vin_no;
    public $engine_no;
    public $grade;
    public $model_year;
    public $exterior_color;
    public $interior_color;

	public $sales_center;

    public $sales_type;
	public $vehicle_price;	
    public $commercial_tax;
    public $rtad_tax;
    public $promotion_code;
	public $promotion_discount;
	public $selling_price;
	public $payment_type;
	public $bank;
	public $payment_percent;
	public $payment_term;

    public $same_as_buyer;
    public $rtad_name;
    public $rtad_nrc_no;
    public $rtad_mobile_no;
    public $rtad_township;

    public $customer_type;
    public $company_name;
    public $company_register_no;

    public $deposit; 

    public $employee_id; 
    public $entry_by;
    public $entry_date_time;

    public function __construct($db){
        $this->conn = $db;
    }

    function getGenerateOCNo(){
		$query = "SELECT SUBSTRING(oc_no, 1, 5) AS f, SUBSTRING(oc_no, 6, 5) AS oc_no FROM `" . $this->table_name . "` WHERE SUBSTRING(oc_no, 5, 1)=:brand AND RIGHT(oc_no, 4)=:year ORDER BY oc_no DESC limit 0,1";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":brand", $this->brand_b);
		$stmt->bindParam(":year", $this->year);

		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return "PAL-" . $this->brand_b . sprintf("%05d", ((int)$row['oc_no'] + 1)) . "-" . $this->year;
		}else{
			return "PAL-" . $this->brand_b . "00001-" . $this->year;
		}
	}

	function create(){
		$query = "INSERT INTO `" . $this->table_name . "` SET `date`=:date
		, oc_no=:oc_no
		, customer_id=:customer_id
		, broker_id=:broker_id
		, broker_name=:broker_name

		, vehicle_status=:vehicle_status
		, `brand`=:brand
		, `model`=:model
		, `grade`=:grade
		, `model_year`=:model_year
		, vin_no=:vin_no
		, engine_no=:engine_no
		, exterior_color=:exterior_color
		, interior_color=:interior_color

		, sales_center=:sales_center

		, sales_type=:sales_type
		, vehicle_price=:vehicle_price 
		, commercial_tax=:commercial_tax 
		, rtad_tax=:rtad_tax 
		, promotion_code=:promotion_code
		, promotion_discount=:promotion_discount
		, selling_price=:selling_price
		, payment_type=:payment_type
		, bank=:bank
		, payment_percent=:payment_percent
		, payment_term=:payment_term
		, deposit=:deposit

		, same_as_buyer=:same_as_buyer
		, rtad_name=:rtad_name
		, rtad_nrc_no=:rtad_nrc_no
		, rtad_mobile_no=:rtad_mobile_no
		, rtad_township=:rtad_township

		, customer_type=:customer_type
		, company_name=:company_name
		, company_register_no=:company_register_no

		, staff_id=:staff_id
        , entry_by=:entry_by
        , entry_date_time=:entry_date_time";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":customer_id", $this->customer_id);
		$stmt->bindParam(":broker_id", $this->broker_id);
		$stmt->bindParam(":broker_name", $this->broker_name);

		$stmt->bindParam(":vehicle_status", $this->vehicle_status);
		$stmt->bindParam(":brand", $this->brand);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":grade", $this->grade);
		$stmt->bindParam(":model_year", $this->model_year);
		$stmt->bindParam(":vin_no", $this->vin_no);
		$stmt->bindParam(":engine_no", $this->engine_no);
		$stmt->bindParam(":exterior_color", $this->exterior_color);
		$stmt->bindParam(":interior_color", $this->interior_color);

		$stmt->bindParam(":sales_center", $this->sales_center);

		$stmt->bindParam(":sales_type", $this->sales_type);
		$stmt->bindParam(":vehicle_price", $this->vehicle_price);	
		$stmt->bindParam(":commercial_tax", $this->commercial_tax);	
		$stmt->bindParam(":rtad_tax", $this->rtad_tax);	
		$stmt->bindParam(":promotion_code", $this->promotion_code);	
		$stmt->bindParam(":promotion_discount", $this->promotion_discount);	
		$stmt->bindParam(":selling_price", $this->selling_price);	
		$stmt->bindParam(":payment_type", $this->payment_type);
		$stmt->bindParam(":bank", $this->bank);
		$stmt->bindParam(":payment_percent", $this->payment_percent);
		$stmt->bindParam(":payment_term", $this->payment_term);
		$stmt->bindParam(":deposit", $this->deposit);

		$stmt->bindParam(":same_as_buyer", $this->same_as_buyer);
		$stmt->bindParam(":rtad_name", $this->rtad_name);
		$stmt->bindParam(":rtad_nrc_no", $this->rtad_nrc_no);
		$stmt->bindParam(":rtad_mobile_no", $this->rtad_mobile_no);
		$stmt->bindParam(":rtad_township", $this->rtad_township);

		$stmt->bindParam(":customer_type", $this->customer_type);
		$stmt->bindParam(":company_name", $this->company_name);
		$stmt->bindParam(":company_register_no", $this->company_register_no);

		$stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;
    }

    function getOrderList(){
    	$condition = "";
        if($this->position=="Sales Executive"){
            $condition .= " AND `order`.staff_id=:staff_id";
        }else if($this->position=="Sales Admin"){
            $condition .= " AND staff.sa_id=:staff_id";
        }

		$query = "SELECT `order`.*, staff.`name` AS staff_name, customer.name, (IFNULL(total_approval, 0) - IFNULL(approve_count, 0)) AS approve_left
FROM `order`
LEFT JOIN sales ON `order`.oc_no=sales.oc_no
LEFT JOIN staff ON `order`.staff_id=staff.id
LEFT JOIN customer ON `order`.customer_id=customer.id
LEFT JOIN (
SELECT main_id, COUNT(*) AS approve_count
FROM approval
WHERE `process`=:process AND approve=1
GROUP BY main_id) AS apv ON `order`.oc_no=apv.main_id
LEFT JOIN (SELECT staff_id, SUM(apv_count) AS total_approval
FROM ((
SELECT staff_id, COUNT(order_no) AS apv_count
FROM approval_assign
WHERE `process`=:process AND `condition`='AND' GROUP BY staff_id) UNION ALL (
SELECT staff_id, COUNT(distinct order_no) AS apv_count
FROM approval_assign
WHERE `process`=:process AND `condition`='OR'
GROUP BY staff_id)) AS apv GROUP BY staff_id) AS apv_assign ON `order`.staff_id=apv_assign.staff_id
WHERE IFNULL(sales.dc_due_date_time, '')='' " . $condition . "
ORDER BY `order`.oc_no, `order`.date, RIGHT(`order`.entry_date_time, 8)";

		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":process", $this->process);
		if($this->position=="Sales Executive" || $this->position=="Sales Admin") $stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->execute();
		return $stmt;
	}

	function getOneRow(){
		$query = "SELECT `order`.*, customer.name AS customer_name, customer.nrc_no AS c_nrc_no, customer.registration_no AS c_registration_no, customer.mobile_no AS c_mobile_no, customer.email AS c_email, customer.township AS c_township, IFNULL(broker.registration_no, '') AS b_registration_no FROM `" . $this->table_name . "` LEFT JOIN customer ON `order`.customer_id=customer.id LEFT JOIN broker ON `order`.broker_id=broker.id WHERE `order`.oc_no=:oc_no";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->sales_center = $row['sales_center'];
			$this->oc_no = $row['oc_no'];
			$this->date = $row['date'];
			$this->sales_type = $row['sales_type'];
			$this->staff_id = $row['staff_id'];

			$this->broker_id = $row['broker_id'];
			$this->b_registration_no = $row['b_registration_no'];
			$this->broker_name = $row['broker_name'];

			$this->c_registration_no = $row['c_registration_no'];
			$this->customer_id = $row['customer_id'];
			$this->customer_name = $row['customer_name'];
			$this->c_nrc_no = $row['c_nrc_no'];
			$this->c_mobile_no = $row['c_mobile_no']; 
			$this->c_email = $row['c_email'];	
			$this->c_township = $row['c_township'];
			$this->customer_type = $row['customer_type'];
			$this->company_name = $row['company_name'];
			$this->company_register_no = $row['company_register_no'];

			$this->same_as_buyer = $row['same_as_buyer'];	
			$this->rtad_name = $row['rtad_name'];
			$this->rtad_nrc_no = $row['rtad_nrc_no'];
			$this->rtad_mobile_no = $row['rtad_mobile_no'];
			$this->rtad_township = $row['rtad_township'];

			$this->vehicle_status = $row['vehicle_status'];
			$this->brand = $row['brand'];		
			$this->model = $row['model'];	
			$this->model_year = $row['model_year'];
			$this->grade = $row['grade'];
			$this->exterior_color = $row['exterior_color'];
			$this->interior_color = $row['interior_color'];
			$this->vin_no = $row['vin_no'];
			$this->engine_no = $row['engine_no'];

			$this->payment_type = $row['payment_type'];
			$this->bank = $row['bank'];
			$this->payment_percent = $row['payment_percent'];
			$this->payment_term = $row['payment_term'];

			$this->promotion_code = $row['promotion_code'];
			$this->promotion_discount = $row['promotion_discount'];
			$this->vehicle_price = $row['vehicle_price'];
			$this->rtad_tax = $row['rtad_tax'];	
			$this->deposit = $row['deposit'];
		}
	}

    function update(){
		$query = "UPDATE `" . $this->table_name . "` SET `date`=:date
		, broker_id=:broker_id
		, broker_name=:broker_name

		, vehicle_status=:vehicle_status
		, brand=:brand
		, model=:model
		, grade=:grade
		, model_year=:model_year
		, vin_no=:vin_no
		, engine_no=:engine_no
		, exterior_color=:exterior_color
		, interior_color=:interior_color 

		, sales_type=:sales_type
		, vehicle_price=:vehicle_price 
		, commercial_tax=:commercial_tax 
		, rtad_tax=:rtad_tax 
		, promotion_code=:promotion_code
		, promotion_discount=:promotion_discount
		, selling_price=:selling_price
		, payment_type=:payment_type
		, bank=:bank
		, payment_percent=:payment_percent
		, payment_term=:payment_term
		, deposit=:deposit

		, same_as_buyer=:same_as_buyer
		, rtad_name=:rtad_name
		, rtad_nrc_no=:rtad_nrc_no
		, rtad_mobile_no=:rtad_mobile_no
		, rtad_township=:rtad_township

		, customer_type=:customer_type
		, company_name=:company_name
		, company_register_no=:company_register_no WHERE oc_no=:oc_no";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":broker_id", $this->broker_id);
		$stmt->bindParam(":broker_name", $this->broker_name);

		$stmt->bindParam(":vehicle_status", $this->vehicle_status);
		$stmt->bindParam(":brand", $this->brand);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":grade", $this->grade);
		$stmt->bindParam(":model_year", $this->model_year);
		$stmt->bindParam(":vin_no", $this->vin_no);
		$stmt->bindParam(":engine_no", $this->engine_no);
		$stmt->bindParam(":exterior_color", $this->exterior_color);
		$stmt->bindParam(":interior_color", $this->interior_color); 

		$stmt->bindParam(":sales_type", $this->sales_type);
		$stmt->bindParam(":vehicle_price", $this->vehicle_price);	
		$stmt->bindParam(":commercial_tax", $this->commercial_tax);	
		$stmt->bindParam(":rtad_tax", $this->rtad_tax);	
		$stmt->bindParam(":promotion_code", $this->promotion_code);	
		$stmt->bindParam(":promotion_discount", $this->promotion_discount);	
		$stmt->bindParam(":selling_price", $this->selling_price);	
		$stmt->bindParam(":payment_type", $this->payment_type);
		$stmt->bindParam(":bank", $this->bank);
		$stmt->bindParam(":payment_percent", $this->payment_percent);
		$stmt->bindParam(":payment_term", $this->payment_term);
		$stmt->bindParam(":deposit", $this->deposit);

		$stmt->bindParam(":same_as_buyer", $this->same_as_buyer);
		$stmt->bindParam(":rtad_name", $this->rtad_name);
		$stmt->bindParam(":rtad_nrc_no", $this->rtad_nrc_no);
		$stmt->bindParam(":rtad_mobile_no", $this->rtad_mobile_no);
		$stmt->bindParam(":rtad_township", $this->rtad_township);

		$stmt->bindParam(":customer_type", $this->customer_type);
		$stmt->bindParam(":company_name", $this->company_name);
		$stmt->bindParam(":company_register_no", $this->company_register_no);

		if($stmt->execute()){
			return true;
		}
		return false;
    }

	function getOneOrderConfirm(){
		$query = "SELECT `order`.*, IFNULL(customer.name, '') AS customer_name, IFNULL(customer.address, '') AS address, IFNULL(customer.email, '') AS email, IFNULL(customer.mobile_no, '') AS mobile_no, IFNULL(customer.nrc_no, '') AS nrc_no, IFNULL(staff.name, '') AS staff_name, IFNULL(staff.signature, '') AS staff_sig, IFNULL(dc_due_date_time, '') AS dc_due_date_time FROM `order`
LEFT JOIN customer ON `order`.customer_id=customer.id
LEFT JOIN staff ON `order`.staff_id=staff.id
LEFT JOIN sales ON `order`.oc_no=sales.oc_no
WHERE `order`.oc_no=:oc_no";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->execute();

		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$this->id = $row['id'];
			$this->date = $row['date'];
			$this->oc_no = $row['oc_no'];
			$this->customer_id = $row['customer_id'];
			$this->customer_name = $row['customer_name'];
			$this->nrc_no = $row['nrc_no'];
			$this->mobile_no = $row['mobile_no'];
			$this->email = $row['email'];
			$this->address = $row['address'];

			$this->broker_id = $row['broker_id'];
			$this->broker_name = $row['broker_name'];

			$this->brand = $row['brand'];	
			$this->model = $row['model'];
			$this->grade = $row['grade'];
			$this->model_year = $row['model_year'];	
			$this->vin_no = $row['vin_no'];
			$this->engine_no = $row['engine_no'];
			$this->exterior_color = $row['exterior_color'];
			$this->interior_color = $row['interior_color'];		

			$this->sales_center = $row['sales_center'];	
			$this->sales_type = $row['sales_type'];

			$this->vehicle_price = $row['vehicle_price'];
			$this->commercial_tax = $row['commercial_tax'];
			$this->rtad_tax = $row['rtad_tax'];
			$this->promotion_code = $row['promotion_code'];
			$this->promotion_discount = $row['promotion_discount'];
			$this->selling_price = $row['selling_price'];

			$this->deposit = $row['deposit'];
			$this->dc_due_date_time = $row['dc_due_date_time'];

			$this->payment_type = $row['payment_type'];
			$this->bank = $row['bank'];
			$this->payment_percent = $row['payment_percent'];
			$this->payment_term = $row['payment_term'];

			$this->same_as_buyer = $row['same_as_buyer'];
			$this->rtad_name = $row['rtad_name'];
			$this->rtad_nrc_no = $row['rtad_nrc_no'];
			$this->rtad_mobile_no = $row['rtad_mobile_no'];
			$this->rtad_township = $row['rtad_township'];

			$this->customer_type = $row['customer_type'];	
			$this->company_name = $row['company_name'];
			$this->company_register_no = $row['company_register_no'];

			$this->staff_id = $row['staff_id'];
			$this->staff_sig = $row['staff_sig'];
			$this->staff_name = $row['staff_name']; 
		}
	}

	function search(){
        $condition = "";
        
        if($this->df){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " order.date >= :df";
        }

        if($this->dt){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " order.date <= :dt";
        }

        if($this->oc_no){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " order.oc_no = :oc_no";
        }

        if($this->customer_name){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " customer.name = :customer_name";
        }

        if($this->customer_phone){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (customer.mobile_no LIKE  :customer_phone '%' or customer.mobile_no LIKE '%' :customer_phone '%' or customer.mobile_no Like '%' :customer_phone )";
        }

        if($this->broker_name){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " broker.name = :broker_name";
        }

        if($this->sales_center){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " order.sales_center = :sales_center";
        }

        if($this->staff_name){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (customer.name LIKE  :staff_name '%' or customer.name LIKE '%' :staff_name '%' or customer.name Like '%' :staff_name )";
        }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }

        $query = "SELECT order.date, order.oc_no,customer.name AS customer_name, customer.mobile_no AS customer_phone, IFNULL(broker.name, '') AS broker_name, order.vin_no, order.sales_type, order.vehicle_status, order.sales_center
FROM `order`
LEFT JOIN staff ON order.staff_id=staff.id
LEFT JOIN customer ON order.customer_id=customer.id
LEFT JOIN broker ON order.broker_id=broker.id" . $condition . " ORDER BY order.date DESC, order.oc_no DESC";
        $stmt = $this->conn->prepare($query);
        if($this->df) $stmt->bindParam(":df", $this->df);
        if($this->dt) $stmt->bindParam(":dt", $this->dt);
        if($this->oc_no) $stmt->bindParam(":oc_no", $this->oc_no);
        if($this->customer_name) $stmt->bindParam(":customer_name", $this->customer_name);
        if($this->customer_phone) $stmt->bindParam(":customer_phone", $this->customer_phone);
        if($this->broker_name) $stmt->bindParam(":broker_name", $this->broker_name);
        if($this->sales_center) $stmt->bindParam(":sales_center", $this->sales_center);
        if($this->staff_name) $stmt->bindParam(":staff_name", $this->staff_name);
        $stmt->execute();
        return $stmt;
    }
}
?>