<?php
class Staff{
    private $conn;
    private $table_name = "staff";
 
	public $id;
	public $card_no;
	public $name;
	public $join_date;
	public $department;
	public $position;
	public $sa_id;
	public $dob;
	public $nrc_no;
	public $gender;
	public $marital_status;
	public $phone;
	public $email;
	public $contact_address;
	public $permanent_address;
	public $signature;
	public $id_card;
	public $reporting_to_id;
	public $wt_monday;
	public $wt_tuesday;
	public $wt_wednesday;
	public $wt_thursday;
	public $wt_friday;
	public $wt_saturday;
	public $wt_sunday;
	public $entry_by;
	public $entry_date_time;
 
    public function __construct($db){
        $this->conn = $db;
    }

    function getStaffByPosition(){
		$condition = "";	

		if($this->department){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " department = :department ";
		}

		if($this->position){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (position LIKE  :position '%' or position LIKE '%' :position '%' or position Like '%' :position ) ";
		}

		if($this->unassign_sa==1){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " sa_id = 0 ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY department, position, `name`";
		$stmt = $this->conn->prepare( $query );

		if($this->department) $stmt->bindParam(":department", $this->department);
		if($this->position) $stmt->bindParam(":position", $this->position);

		$stmt->execute();
		return $stmt;
	} 
	
	function getAllRowsExceptBySelf(){
		$condition = "";
		if($this->id){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " id <>:id ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY department, position, `name`";
		$stmt = $this->conn->prepare( $query );
		if($this->id) $stmt->bindParam(":id", $this->id);
		$stmt->execute();
		return $stmt;
	}

	function getAllStaff(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY department, position, `name`";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function checkCardNo(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE card_no = ? LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->card_no=htmlspecialchars(strip_tags($this->card_no));
		$stmt->bindParam(1, $this->nrc_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$statement = "";
		if($this->signature){
			$statement .= ", signature=:signature";
		}

		if($this->id_card){
			$statement .= ", id_card=:id_card";
		}

		$query = "INSERT INTO " . $this->table_name . " SET card_no=:card_no,
		 name=:name,
		 join_date=:join_date,  
		 department=:department, 
		 position=:position, 
		 dob=:dob,  
		 nrc_no=:nrc_no, 
		 gender=:gender,  
		 marital_status=:marital_status, 
		 phone=:phone, 
		 email=:email,
		 contact_address=:contact_address, 
		 permanent_address=:permanent_address, 
		 reporting_to_id=:reporting_to_id, 
		 wt_monday=:wt_monday, 
		 wt_tuesday=:wt_tuesday, 
		 wt_wednesday=:wt_wednesday,
		 wt_thursday=:wt_thursday,  
		 wt_friday=:wt_friday, 
		 wt_saturday=:wt_saturday, 
		 wt_sunday=:wt_sunday,
		 entry_by=:entry_by, 
		 entry_date_time=:entry_date_time" . $statement;
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":card_no", $this->card_no);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":join_date", $this->join_date);
		$stmt->bindParam(":department", $this->department);
		$stmt->bindParam(":position", $this->position);
		$stmt->bindParam(":dob", $this->dob);
		$stmt->bindParam(":nrc_no", $this->nrc_no);
		$stmt->bindParam(":gender", $this->gender);
		$stmt->bindParam(":marital_status", $this->marital_status);
		$stmt->bindParam(":phone", $this->phone);
		$stmt->bindParam(":email", $this->email);
		$stmt->bindParam(":contact_address", $this->contact_address);
		$stmt->bindParam(":permanent_address", $this->permanent_address);
		$stmt->bindParam(":reporting_to_id", $this->reporting_to_id);
		$stmt->bindParam(":wt_monday", $this->wt_monday);
		$stmt->bindParam(":wt_tuesday", $this->wt_tuesday);
		$stmt->bindParam(":wt_wednesday", $this->wt_wednesday);
		$stmt->bindParam(":wt_thursday", $this->wt_thursday);
		$stmt->bindParam(":wt_friday", $this->wt_friday);
		$stmt->bindParam(":wt_saturday", $this->wt_saturday);
		$stmt->bindParam(":wt_sunday", $this->wt_sunday);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($this->signature) $stmt->bindParam(":signature", $this->signature);
		if($this->id_card) $stmt->bindParam(":id_card", $this->id_card);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function update(){
		$statement = "";
		if($this->signature){
			$statement .= ", signature=:signature";
		}

		if($this->id_card){
			$statement .= ", id_card=:id_card";
		}

		$query = "UPDATE " . $this->table_name . " SET name=:name,
		join_date=:join_date,  
		department=:department, 
		position=:position, 
		dob=:dob,  
		nrc_no=:nrc_no, 
		gender=:gender,  
		marital_status=:marital_status, 
		phone=:phone, 
		email=:email,
		contact_address=:contact_address, 
		permanent_address=:permanent_address, 
		reporting_to_id=:reporting_to_id, 
		wt_monday=:wt_monday, 
		wt_tuesday=:wt_tuesday, 
		wt_wednesday=:wt_wednesday,
		wt_thursday=:wt_thursday,  
		wt_friday=:wt_friday, 
		wt_saturday=:wt_saturday, 
		wt_sunday=:wt_sunday,
		entry_by=:entry_by, 
		entry_date_time=:entry_date_time" . $statement . " WHERE id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);	
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":join_date", $this->join_date);
		$stmt->bindParam(":department", $this->department);
		$stmt->bindParam(":position", $this->position);
		$stmt->bindParam(":dob", $this->dob);
		$stmt->bindParam(":nrc_no", $this->nrc_no);
		$stmt->bindParam(":gender", $this->gender);
		$stmt->bindParam(":marital_status", $this->marital_status);
		$stmt->bindParam(":phone", $this->phone);
		$stmt->bindParam(":email", $this->email);
		$stmt->bindParam(":contact_address", $this->contact_address);
		$stmt->bindParam(":permanent_address", $this->permanent_address);
		$stmt->bindParam(":reporting_to_id", $this->reporting_to_id);
		$stmt->bindParam(":wt_monday", $this->wt_monday);
		$stmt->bindParam(":wt_tuesday", $this->wt_tuesday);
		$stmt->bindParam(":wt_wednesday", $this->wt_wednesday);
		$stmt->bindParam(":wt_thursday", $this->wt_thursday);
		$stmt->bindParam(":wt_friday", $this->wt_friday);
		$stmt->bindParam(":wt_saturday", $this->wt_saturday);
		$stmt->bindParam(":wt_sunday", $this->wt_sunday);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		
		if($this->signature) $stmt->bindParam(":signature", $this->signature);
		if($this->id_card) $stmt->bindParam(":id_card", $this->id_card);

		if($stmt->execute()){
			return true;
		}
		return false;
	} 

	function getOneStaff(){	
		$query = "SELECT staff.*, IFNULL(emp.name, '') AS reporting_to_name, IFNULL(emp.position, '') AS reporting_to_position FROM " . $this->table_name . " LEFT JOIN staff AS emp ON staff.reporting_to_id=emp.id WHERE staff.id=:id";
		$stmt = $this->conn->prepare($query);
			
		$stmt->bindParam(":id", $this->id);

		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->card_no = $row['card_no'];		
			$this->join_date = $row['join_date'];	
			$this->department = $row['department'];
			$this->position = $row['position'];
			$this->name = $row['name'];	
			$this->dob = $row['dob'];	
			$this->gender = $row['gender'];		
			$this->nrc_no = $row['nrc_no'];	
			$this->marital_status = $row['marital_status'];	
			$this->phone = $row['phone'];	
			$this->email = $row['email'];	
			$this->contact_address = $row['contact_address'];	
			$this->permanent_address = $row['permanent_address'];	
			$this->reporting_to_id = $row['reporting_to_id'];	
			$this->reporting_to_name = $row['reporting_to_name'];	
			$this->reporting_to_position = $row['reporting_to_position'];	
			$this->signature = $row['signature'];		
			$this->id_card = $row['id_card'];
			$this->wt_monday = $row['wt_monday'];
			$this->wt_tuesday = $row['wt_tuesday'];
			$this->wt_wednesday = $row['wt_wednesday'];	
			$this->wt_thursday = $row['wt_thursday'];	
			$this->wt_friday = $row['wt_friday'];	
			$this->wt_saturday = $row['wt_saturday'];	
			$this->wt_sunday = $row['wt_sunday'];
		}
	}

	function updateAssignUnassign(){
		$query = "UPDATE " . $this->table_name . " SET sa_id=:sa_id WHERE id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);	
		$stmt->bindParam(":sa_id", $this->sa_id);

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getAllSEAssign(){
		$condition = "";
		if($this->sa_id){
			$condition .= " AND staff.sa_id = :sa_id ";
		}

		$query = "SELECT staff.id, staff.`name` AS sales_executive, sa.`name` AS sales_admin FROM " . $this->table_name . " LEFT JOIN staff AS sa ON staff.sa_id=sa.id WHERE staff.position='Sales Executive' AND staff.sa_id<>0 " . $condition . " ORDER BY sa.`name`";
		$stmt = $this->conn->prepare( $query );
		if($this->sa_id) $stmt->bindParam(":sa_id", $this->sa_id);
		$stmt->execute();
		return $stmt;
	}

	function autocomplete(){
		$condition = "";
		
		if($this->card_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (card_no LIKE  :card_no '%' or card_no LIKE '%' :card_no '%' or card_no Like '%' :card_no )";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY card_no DESC";
		$stmt = $this->conn->prepare($query);
		if($this->card_no) $stmt->bindParam(":card_no", $this->card_no);
		$stmt->execute();
		return $stmt;
	}

	function search(){
		$condition = "";	

		if($this->card_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " card_no =:card_no ";
		}
		if($this->name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (name LIKE :name '%' or name LIKE '%' :name '%' or name Like '%' :name) ";
		}
		if($this->department){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " department =:department ";
		}
		if($this->position){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " position=:position ";
		}
		if($this->nrc_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (nrc_no LIKE :nrc_no '%' or nrc_no LIKE '%' :nrc_no '%' or nrc_no Like '%' :nrc_no ) ";
		}
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY card_no, `name`";

		$stmt = $this->conn->prepare($query);
		
		if($this->card_no) $this->registration_no=htmlspecialchars(strip_tags($this->card_no));
		if($this->name) $this->name_english=htmlspecialchars(strip_tags($this->name));
		if($this->department) $this->nrc=htmlspecialchars(strip_tags($this->department));
		if($this->position) $this->nrc=htmlspecialchars(strip_tags($this->position));
		if($this->nrc_no) $this->nrc=htmlspecialchars(strip_tags($this->nrc_no));
		
		if($this->card_no) $stmt->bindParam(":card_no", $this->card_no);
		if($this->name) $stmt->bindParam(":name", $this->name);
		if($this->department) $stmt->bindParam(":department", $this->department);
		if($this->position) $stmt->bindParam(":position", $this->position);
		if($this->nrc_no) $stmt->bindParam(":nrc_no", $this->nrc_no);
		
		$stmt->execute();
		return $stmt;
	} 

	// function getAllRowsBySM(){
	// 	$query = "SELECT staff_id, name FROM HR_incharge LEFT JOIN staff ON HR_incharge.staff_id=staff.id WHERE incharge_id=:id ORDER BY name";
	// 	$stmt = $this->conn->prepare($query);
	// 	$stmt->bindParam(":id", $this->id);
	// 	$stmt->execute();
	// 	return $stmt;
	// } 

	// function getGenerateCode($prefix){
	// 	$query = "SELECT card_no FROM `" . $this->table_name . "` WHERE card_no like '$prefix%'  ORDER BY card_no desc limit 0,1";
	// 	$stmt = $this->conn->prepare($query);
	// 	$stmt->execute();
	// 	if($stmt->rowCount()>0){
	// 		$row = $stmt->fetch(PDO::FETCH_ASSOC);
	// 		return $prefix . sprintf("%'06d", ((int)str_replace($prefix,"",$row['card_no']) + 1));
	// 	}else{
	// 		return $prefix . "000001";
	// 	}
	// }  

	// function getAllTechnician(){
	// 	$query = "SELECT * FROM " . $this->table_name . " WHERE `position`='Technician' ORDER BY `name`";
	// 	$stmt = $this->conn->prepare($query);		
	// 	$stmt->execute();
	// 	return $stmt;
	// }
}
?>