<?php
class ServiceFinalInspection{ 
	private $conn;
	private $table_name = "service_final_inspection";

	public $id;
	public $service_id;
	public $service_booklet;
	public $jack_and_handle;
	public $paking_sign;
	public $spare_wheel;
	public $mobile_charger;
	public $car_key;
	public $wheel_tax;
	public $fuel_level;
	public $other_items;
	public $remark;
	public $customer_complaint;
	public $restored_position;
	public $road_test_done;
	public $battery_health;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET service_id=:service_id, service_booklet=:service_booklet, jack_and_handle=:jack_and_handle,paking_sign=:paking_sign, spare_wheel=:spare_wheel, mobile_charger=:mobile_charger, car_key=:car_key, wheel_tax=:wheel_tax, fuel_level=:fuel_level, other_items=:other_items, remark=:remark, customer_complaint=:customer_complaint, restored_position=:restored_position, road_test_done=:road_test_done, battery_health=:battery_health, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_id", $this->service_id);
		$stmt->bindParam(":service_booklet", $this->service_booklet);
		$stmt->bindParam(":jack_and_handle", $this->jack_and_handle);
		$stmt->bindParam(":paking_sign", $this->paking_sign);
		$stmt->bindParam(":spare_wheel", $this->spare_wheel);
		$stmt->bindParam(":mobile_charger", $this->mobile_charger);
		$stmt->bindParam(":car_key", $this->car_key);
		$stmt->bindParam(":wheel_tax", $this->wheel_tax);
		$stmt->bindParam(":fuel_level", $this->fuel_level);
		$stmt->bindParam(":other_items", $this->other_items);
		$stmt->bindParam(":remark", $this->remark);
		$stmt->bindParam(":customer_complaint", $this->customer_complaint);
		$stmt->bindParam(":restored_position", $this->restored_position);
		$stmt->bindParam(":road_test_done", $this->road_test_done);
		$stmt->bindParam(":battery_health", $this->battery_health);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;
	}
}
?>