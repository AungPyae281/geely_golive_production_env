<?php
class SparepartStockTransfer{ 
    private $conn;
    private $table_name = "sparepart_stock_transfer";
  
	public $id;
	public $date;
	public $transfer_no;
	public $store_name_from; 
	public $store_name_to;
	public $sparepart_code;
    public $sparepart_name;
    public $quantity;
    public $remark;
	public $stock_transfer_by;
	public $entry_by;
	public $entry_date_time;
	
    public function __construct($db){
        $this->conn = $db;
    }

	function generateTransferNo($prefix){//HHYS
		$query = "SELECT transfer_no FROM `" . $this->table_name . "` GROUP BY transfer_no HAVING transfer_no LIKE ? ORDER BY transfer_no DESC LIMIT 0,1";
		$stmt = $this->conn->prepare($query);
		$keywords = htmlspecialchars(strip_tags($prefix));
		$keywords = "{$keywords}%";
		
		$stmt->bindParam(1, $keywords);
		$stmt->execute();

		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return $prefix . sprintf("%04d", ((int)str_replace($prefix, "", $row['transfer_no']) + 1));
		}else{
			return $prefix . "0001";
		}
	}

	function create(){//HHYS
		$query = "INSERT INTO " . $this->table_name . " SET `date`=:date, transfer_no=:transfer_no, store_name_from=:store_name_from, store_name_to=:store_name_to, sparepart_code=:sparepart_code, sparepart_name=:sparepart_name, quantity=:quantity, stock_transfer_by=:stock_transfer_by, remark=:remark, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query); 
	 
		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":transfer_no", $this->transfer_no);
		$stmt->bindParam(":store_name_from", $this->store_name_from); 
        $stmt->bindParam(":store_name_to", $this->store_name_to);
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":sparepart_name", $this->sparepart_name);
		$stmt->bindParam(":quantity", $this->quantity);
		$stmt->bindParam(":stock_transfer_by", $this->stock_transfer_by);
		$stmt->bindParam(":remark", $this->remark); 
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time); 

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getAllTransferList(){ //HHYS
		$query = "SELECT stock_transfer.*, total_items FROM (SELECT sst.`date`, sst.transfer_no, sst.store_name_from, sst.store_name_to, sst.stock_transfer_by, sst.remark FROM sparepart_stock_transfer AS sst
			LEFT JOIN (SELECT transfer_no, sparepart_code, SUM(quantity) AS receive_qty FROM sparepart_stock_receive AS ssr GROUP BY transfer_no, sparepart_code) AS ssr1 ON sst.transfer_no=ssr1.transfer_no AND sst.sparepart_code=ssr1.sparepart_code WHERE sst.quantity > IFNULL(ssr1.receive_qty, 0) AND store_name_to=:store_name_to) AS stock_transfer
			LEFT JOIN (SELECT transfer_no, COUNT(DISTINCT(sparepart_code)) AS total_items FROM sparepart_stock_transfer GROUP BY transfer_no) AS sstsp ON stock_transfer.transfer_no=sstsp.transfer_no GROUP BY stock_transfer.transfer_no ORDER BY stock_transfer.`date`, stock_transfer.transfer_no";
		$stmt = $this->conn->prepare($query);
        $stmt->bindParam(":store_name_to", $this->store_name_to);
		$stmt->execute();
		return $stmt;
	}

	function getTransferDetail(){ //HHYS
		$query = "SELECT sst.sparepart_code, sst.sparepart_name, sst.quantity, IFNULL(receive_qty, 0) AS receive_qty FROM " . $this->table_name . " AS sst LEFT JOIN (SELECT transfer_no, sparepart_code, SUM(quantity) AS receive_qty FROM sparepart_stock_receive AS ssr WHERE transfer_no=:transfer_no GROUP BY transfer_no, sparepart_code) AS ssr1 ON sst.transfer_no=ssr1.transfer_no AND sst.sparepart_code=ssr1.sparepart_code WHERE sst.transfer_no=:transfer_no ORDER BY (quantity - IFNULL(receive_qty, 0))";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":transfer_no", $this->transfer_no);
		$stmt->execute();
		return $stmt;
	}
}
?>
