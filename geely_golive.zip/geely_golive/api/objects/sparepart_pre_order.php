<?php
class SparepartPreOrder{
	private $conn;
	private $table_name = "sparepart_pre_order";
 
	public $id;
	public $wl_id;
	public $pre_order_date;
	public $by;
	public $remark; 
	public $make_order;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){//HHYS
		$query = "INSERT INTO " . $this->table_name . " SET wl_id=:wl_id, pre_order_date=:pre_order_date, `by`=:by, remark=:remark, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":wl_id", $this->wl_id);
		$stmt->bindParam(":pre_order_date", $this->pre_order_date);
		$stmt->bindParam(":by", $this->by);
		$stmt->bindParam(":remark", $this->remark); 
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		
		$stmt->execute();
		if($stmt->rowCount()>0){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;
	}

	function getOnePreOrder(){//HHYS
		$query = "SELECT spo.id, spo.wl_id, pre_order_date, swl.service_center, swl.service_customer_id, IFNULL(service_customer.name, '') AS customer_name, IFNULL(service_customer.phone_no, '') AS customer_phone, swl.service_car_id, swl.plate_no, spo.`by`, spo.remark FROM sparepart_pre_order AS spo
			LEFT JOIN sparepart_waiting_list AS swl ON spo.wl_id=swl.wl_id
			LEFT JOIN service_customer ON swl.service_customer_id=service_customer.id WHERE spo.id=:id";
		$stmt = $this->conn->prepare($query);
			
		$stmt->bindParam(":id", $this->id);

		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];	
			$this->wl_id = $row['wl_id'];	
			$this->pre_order_date = $row['pre_order_date'];	
			$this->service_center = $row['service_center'];		
			$this->service_customer_id = $row['service_customer_id'];	
			$this->customer_name = $row['customer_name'];	
			$this->customer_phone = $row['customer_phone'];	
			$this->service_car_id = $row['service_car_id'];	
			$this->plate_no = $row['plate_no'];  
			$this->by = $row['by'];		
			$this->remark = $row['remark'];
		}
	}

	function getAllPreOrderList(){	
		$query = "SELECT spo.id, spo.wl_id, pre_order_date, swl.service_center, total_items, total_quantity, spo.remark, IFNULL(spop.payment, 0) AS total_payment FROM sparepart_pre_order AS spo
			LEFT JOIN (SELECT sparepart_pre_order_id, COUNT(sparepart_code) AS total_items, SUM(quantity) AS total_quantity FROM sparepart_pre_order_detail GROUP BY sparepart_pre_order_id) AS spod ON spo.id=spod.sparepart_pre_order_id 
			LEFT JOIN sparepart_waiting_list AS swl ON spo.wl_id=swl.wl_id
			LEFT JOIN (SELECT sparepart_pre_order_id, SUM(amount) AS payment FROM sparepart_pre_order_payment GROUP BY sparepart_pre_order_id) AS spop ON spo.id=spop.sparepart_pre_order_id WHERE make_order=0 AND IFNULL(spop.payment, 0)>0 AND swl.service_center=:service_center";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->execute();
		return $stmt;
	} 

	function getAllPreOrderPaymentRemain(){	
		$condition = "";
		
		if($this->df){
			$condition .= " AND pre_order_date >= :df ";
		}

		if($this->dt){
			$condition .= " AND pre_order_date <= :dt ";
		}

		if($this->deposit){
			$condition .= ($this->deposit=="Yes")?" AND IFNULL(payment, 0) > 0 ":" AND IFNULL(payment, 0) = 0 ";
		}
		$query = "SELECT spo.id, spo.wl_id, pre_order_date, swl.service_center, service_customer.name AS customer_name, service_customer.phone_no AS customer_phone, swl.plate_no, total_items, total_quantity, total_amount, IFNULL(payment, 0) AS payment, (total_amount - IFNULL(payment, 0)) AS balance FROM sparepart_pre_order AS spo
		LEFT JOIN (SELECT sparepart_pre_order_id, COUNT(sparepart_code) AS total_items, SUM(quantity) AS total_quantity FROM sparepart_pre_order_detail GROUP BY sparepart_pre_order_id) AS spod ON spo.id=spod.sparepart_pre_order_id
		LEFT JOIN sparepart_waiting_list AS swl ON spo.wl_id=swl.wl_id
		LEFT JOIN service_customer ON swl.service_customer_id=service_customer.id
		LEFT JOIN (SELECT sparepart_pre_order_id AS spoi, SUM(amount) AS payment FROM sparepart_pre_order_payment AS spop GROUP BY sparepart_pre_order_id) AS spopay ON spo.id=spopay.spoi
		LEFT JOIN (SELECT spod.sparepart_pre_order_id AS spodid, sum(spod.quantity * sparepart.sales_price) AS total_amount FROM sparepart_pre_order_detail AS spod LEFT JOIN sparepart ON spod.sparepart_code=sparepart.code GROUP BY spod.sparepart_pre_order_id) AS spod1 ON spo.id=spod1.spodid WHERE total_amount>IFNULL(payment, 0) " . $condition . " ORDER BY spo.wl_id DESC, pre_order_date DESC, swl.service_center";
		$stmt = $this->conn->prepare( $query );
		if($this->df) $stmt->bindParam(":df", $this->df);
		if($this->dt) $stmt->bindParam(":dt", $this->dt);
		$stmt->execute();
		return $stmt;
	} 

	function getOnePreOrderPayment(){
		$query = "SELECT spo.id, spo.wl_id, pre_order_date, swl.service_center, service_customer.name AS customer_name, service_customer.phone_no AS customer_phone, swl.plate_no, total_items, total_quantity, total_amount, IFNULL(payment, 0) AS payment, (total_amount - IFNULL(payment, 0)) AS balance FROM sparepart_pre_order AS spo
		LEFT JOIN (SELECT sparepart_pre_order_id, COUNT(sparepart_code) AS total_items, SUM(quantity) AS total_quantity FROM sparepart_pre_order_detail GROUP BY sparepart_pre_order_id) AS spod ON spo.id=spod.sparepart_pre_order_id
		LEFT JOIN sparepart_waiting_list AS swl ON spo.wl_id=swl.wl_id
		LEFT JOIN service_customer ON swl.service_customer_id=service_customer.id
		LEFT JOIN (SELECT sparepart_pre_order_id AS spoi, SUM(amount) AS payment FROM sparepart_pre_order_payment AS spop GROUP BY sparepart_pre_order_id) AS spopay ON spo.id=spopay.spoi
		LEFT JOIN (SELECT spod.sparepart_pre_order_id AS spodid, sum(spod.quantity * sparepart.sales_price) AS total_amount FROM sparepart_pre_order_detail AS spod LEFT JOIN sparepart ON spod.sparepart_code=sparepart.code GROUP BY spod.sparepart_pre_order_id) AS spod1 ON spo.id=spod1.spodid WHERE spo.id=:id";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":id", $this->id);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];	
			$this->wl_id = $row['wl_id'];	
			$this->pre_order_date = $row['pre_order_date'];	
			$this->service_center = $row['service_center'];		
			$this->customer_name = $row['customer_name'];	
			$this->customer_phone = $row['customer_phone'];	
			$this->plate_no = $row['plate_no'];	
			$this->total_items = $row['total_items'];	
			$this->total_quantity = $row['total_quantity']; 
			$this->total_amount = $row['total_amount'];	 
			$this->payment = $row['payment'];		
			$this->balance = $row['balance'];
		}else{
			$this->id = "";	
			$this->wl_id = "";	
			$this->pre_order_date = "";	
			$this->service_center = "";		
			$this->customer_name = "";	
			$this->customer_phone = "";	
			$this->plate_no = "";	
			$this->total_items = 0;	
			$this->total_quantity = 0; 
			$this->total_amount = 0;	 
			$this->payment = 0;		
			$this->balance = 0;
		}
	} 

	function updateMakeOrder(){
		$query = "UPDATE " . $this->table_name . " SET make_order=1 WHERE id IN (" . $this->id . ")";
		$stmt = $this->conn->prepare($query);
		if($stmt->execute()){
			return true;
		}
		return false;
	}
}
?>