<?php
class CarPriceChangeLog{
    // database connection and table name
	private $conn;
	private $table_name = "car_price_change_log";

	// object properties

	public $id;
	public $car_list_id;
	public $car_stock_id;
	public $request_date;
	public $change_date;
	public $vehicle_price;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET car_list_id=:car_list_id, car_stock_id=:car_stock_id, request_date=:request_date, change_date=:change_date, vehicle_price=:vehicle_price, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":car_list_id", $this->car_list_id);
		$stmt->bindParam(":car_stock_id", $this->car_stock_id);
		$stmt->bindParam(":request_date", $this->request_date);
		$stmt->bindParam(":change_date", $this->change_date);
		$stmt->bindParam(":vehicle_price", $this->vehicle_price);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){ 
			return true;
		}
		return false;		
	}
}
?>