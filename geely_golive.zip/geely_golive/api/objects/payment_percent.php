<?php
class PaymentPercent{
	private $conn;
	private $table_name = "payment_percent";

	public $id;
	public $payment_percent;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}
 
    function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY payment_percent";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	} 
}
?>