<?php
class Advance{ 
	private $conn;
	private $table_name = "advance";
 
    public $id;	
	public $date;
	public $due_days;
	public $gl_code_to;
	public $amount;
	public $description; 
	public $advance_by; 
	public $gl_code_from;
	public $upload_receipt;
	public $entry_by;
	public $entry_date_time;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET date=:date, due_days=:due_days, gl_code_to=:gl_code_to, amount=:amount, description=:description, advance_by=:advance_by, gl_code_from=:gl_code_from, upload_receipt=:upload_receipt, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":due_days", $this->due_days);
		$stmt->bindParam(":gl_code_to", $this->gl_code_to);
		$stmt->bindParam(":amount", $this->amount);
		$stmt->bindParam(":description", $this->description); 
		$stmt->bindParam(":advance_by", $this->advance_by); 
		$stmt->bindParam(":gl_code_from", $this->gl_code_from); 
		$stmt->bindParam(":upload_receipt", $this->upload_receipt);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$condition = "";	

		if($this->date){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " date = :date ";
		}
		 
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY `date`, account_from, account_to DESC";
		$stmt = $this->conn->prepare( $query );
		if($this->date) $stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}
	
}
