<?php
class AccountTransfer{ 
	private $conn;
	private $table_name = "account_transfer";
 
    public $id;	
	public $gl_code_from;
	public $gl_code_to;
	public $date;
	public $amount;
	public $transfer_by; 
	public $upload_receipt;
	public $entry_by;
	public $entry_date_time;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET gl_code_from=:gl_code_from, gl_code_to=:gl_code_to, date=:date, amount=:amount, transfer_by=:transfer_by, upload_receipt=:upload_receipt, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":gl_code_from", $this->gl_code_from);
		$stmt->bindParam(":gl_code_to", $this->gl_code_to);
		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":amount", $this->amount);
		$stmt->bindParam(":transfer_by", $this->transfer_by); 
		$stmt->bindParam(":upload_receipt", $this->upload_receipt);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$condition = "";	

		if($this->date){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " acct.`date` = :date ";
		}
		 
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT acct.*, glf.`name` AS name_from, glt.`name` AS name_to FROM account_transfer AS acct
LEFT JOIN gl_account AS glf ON acct.gl_code_from=glf.gl_code
LEFT JOIN gl_account AS glt ON acct.gl_code_to=glt.gl_code " . $condition . " ORDER BY `date`, gl_code_from, gl_code_to DESC";
		$stmt = $this->conn->prepare( $query );
		if($this->date) $stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}
	
}
