<?php
class ProductionOrder{
	    // database connection and table name
	private $conn;
	private $table_name = "production_order";

	// object properties 
	public $id;
	public $car_list_id; 
	public $order_date; 
	public $order_no;
	public $quantity;
	public $vehicle_price;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	} 

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET car_list_id=:car_list_id, order_date=:order_date, order_no=:order_no, quantity=:quantity, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":car_list_id", $this->car_list_id); 
		$stmt->bindParam(":order_date", $this->order_date);
		$stmt->bindParam(":order_no", $this->order_no);
		$stmt->bindParam(":quantity", $this->quantity);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){ 
			return true;
		}
		return false;		
	}

	function getAllProductionOrderList(){
		$condition = "";	

		if($this->brand){ 
			$condition .= " AND car_list.`brand` =:brand ";
		}
		if($this->model){
			$condition .= " AND car_list.`model` =:model ";
		}
		if($this->model_year){
			$condition .= " AND car_list.`model_year` =:model_year ";
		}

		$query = "SELECT po.*, brand, model, model_year, grade, engine_power, interior_color, exterior_color, quantity AS order_qty, IFNULL(stock_in_qty, 0) AS stock_in_qty, (quantity - IFNULL(stock_in_qty, 0)) AS remaining_qty FROM production_order AS po LEFT JOIN car_list ON po.car_list_id=car_list.id LEFT JOIN (SELECT production_order_id AS poid, COUNT(id) AS stock_in_qty FROM car_stock GROUP BY production_order_id) AS cs ON po.id = cs.poid WHERE quantity > IFNULL(stock_in_qty, 0) " . $condition . " ORDER BY `brand`, `model`, `model_year`, `grade`";

		$stmt = $this->conn->prepare($query);
		
		if($this->brand) $this->brand=htmlspecialchars(strip_tags($this->brand));
		if($this->model) $this->model=htmlspecialchars(strip_tags($this->model));
		if($this->model_year) $this->model_year=htmlspecialchars(strip_tags($this->model_year));
		
		if($this->brand) $stmt->bindParam(":brand", $this->brand);
		if($this->model) $stmt->bindParam(":model", $this->model);
		if($this->model_year) $stmt->bindParam(":model_year", $this->model_year);
		
		$stmt->execute();
		return $stmt;
	}

	function getAllOrderNo(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE vehicle_price=0 GROUP BY order_no ORDER BY order_no desc";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}

	function getAllProductionOrderListByOrderNo(){
		$query = "SELECT production_order.*, brand, model, model_year, grade, engine_power, interior_color, exterior_color FROM " . $this->table_name . " LEFT JOIN car_list ON production_order.car_list_id=car_list.id WHERE order_no=:order_no AND production_order.vehicle_price=0 ORDER BY car_list.`brand`, car_list.`model`, car_list.model_year, car_list.grade";
		$stmt = $this->conn->prepare($query);
		if($this->order_no) $this->order_no=htmlspecialchars(strip_tags($this->order_no));
		if($this->order_no) $stmt->bindParam(":order_no", $this->order_no);
		$stmt->execute();
		return $stmt;
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET vehicle_price=:vehicle_price WHERE id=:id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":vehicle_price", $this->vehicle_price);
		if($stmt->execute()){ 
			return true;
		}
		return false;		
	} 

	// function getAllOrderListByPayment(){

	// 	$query = "SELECT id, order_no, order_amount, payment_amount, (IFNULL(order_amount-payment_amount,0)) AS remain_order_amount FROM (SELECT production_order.id, production_order.order_no, 
	// 		SUM(quantity*vehicle_price) AS order_amount, IFNULL(bat.payment_amount,0) AS payment_amount FROM 
	// 		production_order left JOIN (SELECT *, SUM(credit_amount) AS payment_amount FROM bank_account_transaction GROUP BY order_no) AS bat ON 
	// 		production_order.order_no=bat.order_no GROUP BY order_no) AS bm WHERE (payment_amount-order_amount)<>0";

	// 	$stmt = $this->conn->prepare($query);
		
	// 	$stmt->execute();
	// 	return $stmt;
	// }

	// function getOneOrderByPayment(){
	// 	$condition = "";	

	// 	if($this->order_no){ 
	// 		$condition .= " AND order_no =:order_no ";
	// 	}

	// 	$query = "SELECT id, order_no, order_amount, payment_amount, (IFNULL(order_amount-payment_amount,0)) AS remain_order_amount FROM (SELECT production_order.id, production_order.order_no, 
	// 		SUM(quantity*vehicle_price) AS order_amount, IFNULL(bat.payment_amount,0) AS payment_amount FROM 
	// 		production_order left JOIN (SELECT *, SUM(debit_amount) AS payment_amount FROM bank_account_transaction GROUP BY order_no) AS bat ON 
	// 		production_order.order_no=bat.order_no GROUP BY order_no) AS bm WHERE (payment_amount-order_amount)<>0" . $condition;

	// 	$stmt = $this->conn->prepare($query);
		
	// 	if($this->order_no) $this->order_no=htmlspecialchars(strip_tags($this->order_no));
		
	// 	if($this->order_no) $stmt->bindParam(":order_no", $this->order_no);
		
	// 	$stmt->execute();
	// 	return $stmt;
	// } 
}
?>