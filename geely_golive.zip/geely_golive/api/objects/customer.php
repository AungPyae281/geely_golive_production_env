<?php
class Customer{
    private $conn;
    private $table_name = "customer";

	public $id;
	public $registration_no;
	public $staff_id;
	public $staff_name;
	public $sales_center;
    public $gender;
    public $name;
    public $nrc_no;
    public $mobile_no;
    public $dob;
    public $vehicle_of_interest;
    public $btc_am;
    public $btc_pm;
    public $soi_phone_inout;
    public $soi_facebook;
    public $soi_advert;
    public $soi_road_show;
    public $soi_television;
    public $soi_website;
    public $soi_existing_customer;
    public $soi_review;
    public $soi_walkin;
    public $soi_car_magazine;
    public $soi_broker; 
    public $soi_other;
    public $soi_other_remark;
    public $sales_status;
    public $needs_requirements;
    public $estimate_delivery_date;
    public $close_date;
    public $case_close;
    public $alternative_telephone_no;
    public $email;
    public $home_phone;
    public $pcm_mobile;
    public $pcm_email;
    public $pcm_other;
    public $business;
    public $township;
    public $address;
    public $vip;
    public $customer_history;
    public $cv_brand;
    public $cv_model_year;
    public $cv_rtad_no;
    public $cv_mileage;
    public $cv_vehicle_as_commercial;
    public $cvd_outstanding_payments;
    public $cv_private;
    public $cv_business;
    public $cv_off_road;
    public $cv_travelling;
    public $cv_dislike_about_car;
    public $cv_would_you_like_to_have_that_not_already_have;
    public $cv_annual_usage;
    public $cv_who_will_be_using_vehicle;
    public $lifestyle_family_members;
    public $lifestyle_dream_brand;
    public $lifestyle_dream_car;
    public $lifestyle_interested_model;
    public $lifestyle_hobbies_interests;
    public $lifestyle_expectations_of_new_vehicle;
    public $ls_reason;
	public $entry_by;
    public $entry_date_time;

	public $df;
	public $dt;    

    public function __construct($db){
        $this->conn = $db;
    }

    function getAllCustomerList(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE staff_id=:staff_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":staff_id", $this->staff_id);		
		$stmt->execute();
		return $stmt;
	}

	function checkCustomer(){
		$query = "SELECT staff_name FROM " . $this->table_name . " WHERE mobile_no = :mobile_no LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":mobile_no", $this->mobile_no);
		$stmt->execute();

		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->staff_name = $row['staff_name'];
			return true;
		}
		return false;
	}

	function getOneRow(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE	id = :id LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":id", $this->id);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->registration_no = $row['registration_no'];
			$this->staff_id = $row['staff_id'];
			$this->staff_name = $row['staff_name'];
			$this->sales_center = $row['sales_center'];
			$this->gender = $row['gender'];	
			$this->name = $row['name'];
			$this->nrc_no = $row['nrc_no'];
			$this->mobile_no = $row['mobile_no'];
			$this->dob = $row['dob'];	
			$this->btc_am = $row['btc_am'];
			$this->btc_pm = $row['btc_pm'];
			$this->soi_phone_inout = $row['soi_phone_inout'];
			$this->soi_facebook = $row['soi_facebook'];
			$this->soi_advert = $row['soi_advert'];
			$this->soi_road_show = $row['soi_road_show'];
			$this->soi_television = $row['soi_television'];
			$this->soi_website = $row['soi_website'];
			$this->soi_existing_customer = $row['soi_existing_customer'];
			$this->soi_review = $row['soi_review'];
			$this->soi_walkin = $row['soi_walkin'];
			$this->soi_car_magazine = $row['soi_car_magazine'];
			$this->soi_broker = $row['soi_broker']; 
			$this->soi_other = $row['soi_other'];
			$this->soi_other_remark = $row['soi_other_remark'];
			$this->vehicle_of_interest = $row['vehicle_of_interest'];
			$this->sales_status = $row['sales_status'];
			$this->needs_requirements = $row['needs_requirements'];
			$this->estimate_delivery_date = $row['estimate_delivery_date'];
			$this->close_date = $row['close_date'];
			$this->case_close = $row['case_close'];
			$this->alternative_telephone_no = $row['alternative_telephone_no'];
			$this->email = $row['email'];
			$this->home_phone = $row['home_phone'];
			$this->pcm_mobile = $row['pcm_mobile'];
			$this->pcm_email = $row['pcm_email'];
			$this->pcm_other = $row['pcm_other'];
			$this->business = $row['business'];
			$this->township = $row['township'];
			$this->address = $row['address'];
			$this->vip = $row['vip'];
			$this->customer_history = $row['customer_history'];
			$this->cv_brand = $row['cv_brand'];
			$this->cv_model_year = $row['cv_model_year'];
			$this->cv_rtad_no = $row['cv_rtad_no'];
			$this->cv_mileage = $row['cv_mileage'];
			$this->cv_vehicle_as_commercial = $row['cv_vehicle_as_commercial'];
			$this->cvd_outstanding_payments = $row['cvd_outstanding_payments'];
			$this->cv_private = $row['cv_private'];
			$this->cv_business = $row['cv_business'];
			$this->cv_off_road = $row['cv_off_road'];
			$this->cv_travelling = $row['cv_travelling'];
			$this->cv_dislike_about_car = $row['cv_dislike_about_car'];
			$this->cv_would_you_like_to_have_that_not_already_have = $row['cv_would_you_like_to_have_that_not_already_have'];
			$this->cv_annual_usage = $row['cv_annual_usage'];
			$this->cv_who_will_be_using_vehicle = $row['cv_who_will_be_using_vehicle'];
			$this->lifestyle_family_members = $row['lifestyle_family_members'];
			$this->lifestyle_dream_brand = $row['lifestyle_dream_brand'];
			$this->lifestyle_dream_car = $row['lifestyle_dream_car'];
			$this->lifestyle_interested_model = $row['lifestyle_interested_model'];
			$this->lifestyle_hobbies_interests = $row['lifestyle_hobbies_interests'];
			$this->lifestyle_expectations_of_new_vehicle = $row['lifestyle_expectations_of_new_vehicle'];
			$this->entry_by = $row['entry_by'];
			$this->entry_date_time = $row['entry_date_time'];
		}
	}

    function getGenerateRegistrationNo($prefix){
		$query = "SELECT registration_no FROM `" . $this->table_name . "` WHERE registration_no like ? ORDER BY registration_no DESC LIMIT 0,1";
		$stmt = $this->conn->prepare($query);
		$keywords = htmlspecialchars(strip_tags($prefix));
		$keywords = "{$keywords}%";
		
		$stmt->bindParam(1, $keywords);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return $prefix . sprintf("%03d", ((int)str_replace($prefix, "", $row['registration_no']) + 1));
		}else{
			return $prefix . "001";
		}
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET 
		registration_no=:registration_no
		, staff_id=:staff_id
		, staff_name=:staff_name
		, sales_center=:sales_center
		, gender=:gender
		, name=:name
		, mobile_no=:mobile_no
		, dob=:dob 
		, btc_am=:btc_am
		, btc_pm=:btc_pm
		, soi_phone_inout=:soi_phone_inout
		, soi_facebook=:soi_facebook
		, soi_advert=:soi_advert
		, soi_road_show=:soi_road_show
		, soi_television=:soi_television
		, soi_website=:soi_website
		, soi_existing_customer=:soi_existing_customer
		, soi_review=:soi_review
		, soi_walkin=:soi_walkin
		, soi_car_magazine=:soi_car_magazine
		, soi_broker=:soi_broker
		, soi_other=:soi_other	
		, soi_other_remark=:soi_other_remark	
		, vehicle_of_interest=:vehicle_of_interest
		, sales_status=:sales_status
		, needs_requirements=:needs_requirements
		, estimate_delivery_date=:estimate_delivery_date
		, close_date=:close_date
		, alternative_telephone_no=:alternative_telephone_no
		, email=:email
		, home_phone=:home_phone
		, pcm_mobile=:pcm_mobile
		, pcm_email=:pcm_email
		, pcm_other=:pcm_other
		, business=:business
		, township=:township 
		, address=:address
		, vip=:vip
		, customer_history=:customer_history
		, cv_brand=:cv_brand
		, cv_model_year=:cv_model_year
		, cv_rtad_no=:cv_rtad_no
		, cv_mileage=:cv_mileage
		, cv_vehicle_as_commercial=:cv_vehicle_as_commercial
		, cvd_outstanding_payments=:cvd_outstanding_payments
		, cv_private=:cv_private
		, cv_business=:cv_business
		, cv_off_road=:cv_off_road
		, cv_travelling=:cv_travelling
		, cv_dislike_about_car=:cv_dislike_about_car
		, cv_would_you_like_to_have_that_not_already_have=:cv_would_you_like_to_have_that_not_already_have
		, cv_annual_usage=:cv_annual_usage
		, cv_who_will_be_using_vehicle=:cv_who_will_be_using_vehicle
		, lifestyle_family_members=:lifestyle_family_members
		, lifestyle_dream_brand=:lifestyle_dream_brand
		, lifestyle_dream_car=:lifestyle_dream_car
		, lifestyle_interested_model=:lifestyle_interested_model
		, lifestyle_hobbies_interests=:lifestyle_hobbies_interests
		, lifestyle_expectations_of_new_vehicle=:lifestyle_expectations_of_new_vehicle
        , entry_by=:entry_by
        , entry_date_time=:entry_date_time";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":registration_no", $this->registration_no);
		$stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->bindParam(":staff_name", $this->staff_name);
		$stmt->bindParam(":sales_center", $this->sales_center);
		$stmt->bindParam(":gender", $this->gender);
        $stmt->bindParam(":name", $this->name);	
        $stmt->bindParam(":mobile_no", $this->mobile_no);
        $stmt->bindParam(":dob", $this->dob);
		$stmt->bindParam(":btc_am", $this->btc_am);
		$stmt->bindParam(":btc_pm", $this->btc_pm);
		$stmt->bindParam(":soi_phone_inout", $this->soi_phone_inout);
		$stmt->bindParam(":soi_facebook", $this->soi_facebook);
		$stmt->bindParam(":soi_advert", $this->soi_advert);
		$stmt->bindParam(":soi_road_show", $this->soi_road_show);
		$stmt->bindParam(":soi_television", $this->soi_television);
		$stmt->bindParam(":soi_website", $this->soi_website);
		$stmt->bindParam(":soi_existing_customer", $this->soi_existing_customer);
		$stmt->bindParam(":soi_review", $this->soi_review);
		$stmt->bindParam(":soi_walkin", $this->soi_walkin);
		$stmt->bindParam(":soi_car_magazine", $this->soi_car_magazine);
		$stmt->bindParam(":soi_broker", $this->soi_broker); 
		$stmt->bindParam(":soi_other", $this->soi_other);
		$stmt->bindParam(":soi_other_remark", $this->soi_other_remark);
        $stmt->bindParam(":vehicle_of_interest", $this->vehicle_of_interest);
		$stmt->bindParam(":sales_status", $this->sales_status);
		$stmt->bindParam(":needs_requirements", $this->needs_requirements);
		$stmt->bindParam(":estimate_delivery_date", $this->estimate_delivery_date);
		$stmt->bindParam(":close_date", $this->close_date);
		$stmt->bindParam(":alternative_telephone_no", $this->alternative_telephone_no);
		$stmt->bindParam(":email", $this->email);
		$stmt->bindParam(":home_phone", $this->home_phone);
		$stmt->bindParam(":pcm_mobile", $this->pcm_mobile);
		$stmt->bindParam(":pcm_email", $this->pcm_email);
		$stmt->bindParam(":pcm_other", $this->pcm_other);
		$stmt->bindParam(":business", $this->business);
        $stmt->bindParam(":township", $this->township);
		$stmt->bindParam(":address", $this->address);
		$stmt->bindParam(":vip", $this->vip);
		$stmt->bindParam(":customer_history", $this->customer_history);
		$stmt->bindParam(":cv_brand", $this->cv_brand);
		$stmt->bindParam(":cv_model_year", $this->cv_model_year);
		$stmt->bindParam(":cv_rtad_no", $this->cv_rtad_no);
		$stmt->bindParam(":cv_mileage", $this->cv_mileage);
		$stmt->bindParam(":cv_vehicle_as_commercial", $this->cv_vehicle_as_commercial);
		$stmt->bindParam(":cvd_outstanding_payments", $this->cvd_outstanding_payments);
		$stmt->bindParam(":cv_private", $this->cv_private);
		$stmt->bindParam(":cv_business", $this->cv_business);
		$stmt->bindParam(":cv_off_road", $this->cv_off_road);
		$stmt->bindParam(":cv_travelling", $this->cv_travelling);
		$stmt->bindParam(":cv_dislike_about_car", $this->cv_dislike_about_car);
		$stmt->bindParam(":cv_would_you_like_to_have_that_not_already_have", $this->cv_would_you_like_to_have_that_not_already_have);
		$stmt->bindParam(":cv_annual_usage", $this->cv_annual_usage);
		$stmt->bindParam(":cv_who_will_be_using_vehicle", $this->cv_who_will_be_using_vehicle);
		$stmt->bindParam(":lifestyle_family_members", $this->lifestyle_family_members);
		$stmt->bindParam(":lifestyle_dream_brand", $this->lifestyle_dream_brand);
		$stmt->bindParam(":lifestyle_dream_car", $this->lifestyle_dream_car);
		$stmt->bindParam(":lifestyle_interested_model", $this->lifestyle_interested_model);
		$stmt->bindParam(":lifestyle_hobbies_interests", $this->lifestyle_hobbies_interests);
		$stmt->bindParam(":lifestyle_expectations_of_new_vehicle", $this->lifestyle_expectations_of_new_vehicle);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;
    }

    function update(){
		$query = "UPDATE " . $this->table_name . " SET 
		gender=:gender
		, name=:name
		, mobile_no=:mobile_no
		, dob=:dob 
		, btc_am=:btc_am
		, btc_pm=:btc_pm
		, soi_phone_inout=:soi_phone_inout
		, soi_facebook=:soi_facebook
		, soi_advert=:soi_advert
		, soi_road_show=:soi_road_show
		, soi_television=:soi_television
		, soi_website=:soi_website
		, soi_existing_customer=:soi_existing_customer
		, soi_review=:soi_review
		, soi_walkin=:soi_walkin
		, soi_car_magazine=:soi_car_magazine
		, soi_broker=:soi_broker
		, soi_other=:soi_other	
		, soi_other_remark=:soi_other_remark	
		, vehicle_of_interest=:vehicle_of_interest
		, sales_status=:sales_status
		, needs_requirements=:needs_requirements
		, estimate_delivery_date=:estimate_delivery_date
		, close_date=:close_date
		, alternative_telephone_no=:alternative_telephone_no
		, email=:email
		, home_phone=:home_phone
		, pcm_mobile=:pcm_mobile
		, pcm_email=:pcm_email
		, pcm_other=:pcm_other
		, business=:business
		, township=:township
		, address=:address
		, vip=:vip
		, customer_history=:customer_history
		, cv_brand=:cv_brand
		, cv_model_year=:cv_model_year
		, cv_rtad_no=:cv_rtad_no
		, cv_mileage=:cv_mileage
		, cv_vehicle_as_commercial=:cv_vehicle_as_commercial
		, cvd_outstanding_payments=:cvd_outstanding_payments
		, cv_private=:cv_private
		, cv_business=:cv_business
		, cv_off_road=:cv_off_road
		, cv_travelling=:cv_travelling
		, cv_dislike_about_car=:cv_dislike_about_car
		, cv_would_you_like_to_have_that_not_already_have=:cv_would_you_like_to_have_that_not_already_have
		, cv_annual_usage=:cv_annual_usage
		, cv_who_will_be_using_vehicle=:cv_who_will_be_using_vehicle
		, lifestyle_family_members=:lifestyle_family_members
		, lifestyle_dream_brand=:lifestyle_dream_brand
		, lifestyle_dream_car=:lifestyle_dream_car
		, lifestyle_interested_model=:lifestyle_interested_model
		, lifestyle_hobbies_interests=:lifestyle_hobbies_interests
		, lifestyle_expectations_of_new_vehicle=:lifestyle_expectations_of_new_vehicle WHERE id=:id";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":gender", $this->gender);
        $stmt->bindParam(":name", $this->name);	
        $stmt->bindParam(":mobile_no", $this->mobile_no);
        $stmt->bindParam(":dob", $this->dob);		
		$stmt->bindParam(":btc_am", $this->btc_am);
		$stmt->bindParam(":btc_pm", $this->btc_pm);
		$stmt->bindParam(":soi_phone_inout", $this->soi_phone_inout);
		$stmt->bindParam(":soi_facebook", $this->soi_facebook);
		$stmt->bindParam(":soi_advert", $this->soi_advert);
		$stmt->bindParam(":soi_road_show", $this->soi_road_show);
		$stmt->bindParam(":soi_television", $this->soi_television);
		$stmt->bindParam(":soi_website", $this->soi_website);
		$stmt->bindParam(":soi_existing_customer", $this->soi_existing_customer);
		$stmt->bindParam(":soi_review", $this->soi_review);
		$stmt->bindParam(":soi_walkin", $this->soi_walkin);
		$stmt->bindParam(":soi_car_magazine", $this->soi_car_magazine);
		$stmt->bindParam(":soi_broker", $this->soi_broker); 
		$stmt->bindParam(":soi_other", $this->soi_other);
		$stmt->bindParam(":soi_other_remark", $this->soi_other_remark);
        $stmt->bindParam(":vehicle_of_interest", $this->vehicle_of_interest);
		$stmt->bindParam(":sales_status", $this->sales_status);
		$stmt->bindParam(":needs_requirements", $this->needs_requirements);
		$stmt->bindParam(":estimate_delivery_date", $this->estimate_delivery_date);
		$stmt->bindParam(":close_date", $this->close_date);
		$stmt->bindParam(":alternative_telephone_no", $this->alternative_telephone_no);
		$stmt->bindParam(":email", $this->email);
		$stmt->bindParam(":home_phone", $this->home_phone);
		$stmt->bindParam(":pcm_mobile", $this->pcm_mobile);
		$stmt->bindParam(":pcm_email", $this->pcm_email);
		$stmt->bindParam(":pcm_other", $this->pcm_other);
		$stmt->bindParam(":business", $this->business);
		$stmt->bindParam(":township", $this->township);
		$stmt->bindParam(":address", $this->address);
		$stmt->bindParam(":vip", $this->vip);
		$stmt->bindParam(":customer_history", $this->customer_history);
		$stmt->bindParam(":cv_brand", $this->cv_brand);
		$stmt->bindParam(":cv_model_year", $this->cv_model_year);
		$stmt->bindParam(":cv_rtad_no", $this->cv_rtad_no);
		$stmt->bindParam(":cv_mileage", $this->cv_mileage);
		$stmt->bindParam(":cv_vehicle_as_commercial", $this->cv_vehicle_as_commercial);
		$stmt->bindParam(":cvd_outstanding_payments", $this->cvd_outstanding_payments);
		$stmt->bindParam(":cv_private", $this->cv_private);
		$stmt->bindParam(":cv_business", $this->cv_business);
		$stmt->bindParam(":cv_off_road", $this->cv_off_road);
		$stmt->bindParam(":cv_travelling", $this->cv_travelling);
		$stmt->bindParam(":cv_dislike_about_car", $this->cv_dislike_about_car);
		$stmt->bindParam(":cv_would_you_like_to_have_that_not_already_have", $this->cv_would_you_like_to_have_that_not_already_have);
		$stmt->bindParam(":cv_annual_usage", $this->cv_annual_usage);
		$stmt->bindParam(":cv_who_will_be_using_vehicle", $this->cv_who_will_be_using_vehicle);
		$stmt->bindParam(":lifestyle_family_members", $this->lifestyle_family_members);
		$stmt->bindParam(":lifestyle_dream_brand", $this->lifestyle_dream_brand);
		$stmt->bindParam(":lifestyle_dream_car", $this->lifestyle_dream_car);
		$stmt->bindParam(":lifestyle_interested_model", $this->lifestyle_interested_model);
		$stmt->bindParam(":lifestyle_hobbies_interests", $this->lifestyle_hobbies_interests);
		$stmt->bindParam(":lifestyle_expectations_of_new_vehicle", $this->lifestyle_expectations_of_new_vehicle);

		if($stmt->execute()){
			return true;
		}
		return false;
    } 
 
	function checkBrokerStatus(){
		$query = "SELECT soi_broker FROM " . $this->table_name . " WHERE id=:id LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":id", $this->id);
		$stmt->execute();
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		return $row['soi_broker'];
	}

	function updateFromOrder(){
		$query = "UPDATE " . $this->table_name . " SET sales_status='Deal', nrc_no=:nrc_no WHERE id=:id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":nrc_no", $this->nrc_no);
		if($stmt->execute()){
			return true;
		}
		return false;
    }

    function autocomplete(){
        $condition = "";
        
        if($this->name){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (name LIKE  :name '%' or name LIKE '%' :name '%' or name Like '%' :name )";
        }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }

        $query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY name";
        $stmt = $this->conn->prepare($query);
        if($this->name) $stmt->bindParam(":name", $this->name);
        $stmt->execute();
        return $stmt;
    }

    function search(){
		$condition = "";	

		if($this->sales_center){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " sales_center =:sales_center ";
		}

		if($this->name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (name LIKE :name '%' or name LIKE '%' :name '%' or name Like '%' :name) ";
		}

		if($this->staff_name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (staff_name LIKE :staff_name '%' or staff_name LIKE '%' :staff_name '%' or staff_name Like '%' :staff_name) ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY registration_no, `name`";

		$stmt = $this->conn->prepare($query);
		
		if($this->sales_center) $this->sales_center=htmlspecialchars(strip_tags($this->sales_center));
		if($this->name) $this->name=htmlspecialchars(strip_tags($this->name));
		if($this->staff_name) $this->staff_name=htmlspecialchars(strip_tags($this->staff_name));
		
		if($this->sales_center) $stmt->bindParam(":sales_center", $this->sales_center);
		if($this->name) $stmt->bindParam(":name", $this->name);
		if($this->staff_name) $stmt->bindParam(":staff_name", $this->staff_name);
		
		$stmt->execute();
		return $stmt;
	}
}
?>