<?php
class ServiceCar{
    private $conn;
    private $table_name = "service_car";
 
	public $id;
	public $service_customer_id; 
	public $brand;
	public $model;
	public $model_year; 
	public $exterior_color;
	public $vin_no;
	public $engine_no;
	public $plate_no;
	public $entry_by;
	public $entry_date_time;
 
    public function __construct($db){
        $this->conn = $db;
    } 

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE plate_no=:plate_no LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );	
		$stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	} 

    function create(){
		$query = "INSERT INTO " . $this->table_name . " SET service_customer_id=:service_customer_id,
		 brand=:brand,
		 model=:model,  
		 model_year=:model_year, 
		 exterior_color=:exterior_color, 
		 vin_no=:vin_no, 
		 engine_no=:engine_no, 
		 plate_no=:plate_no,  
		 entry_by=:entry_by, 
		 entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_customer_id", $this->service_customer_id);
		$stmt->bindParam(":brand", $this->brand);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":model_year", $this->model_year);
		$stmt->bindParam(":exterior_color", $this->exterior_color);
		$stmt->bindParam(":vin_no", $this->vin_no);
		$stmt->bindParam(":engine_no", $this->engine_no);
		$stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}	 
		return false;
	}

	function getServiceCarByCustomer(){	
		$query = "SELECT * FROM " . $this->table_name . " WHERE service_customer_id=:service_customer_id ORDER BY plate_no";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":service_customer_id", $this->service_customer_id);
		$stmt->execute();
		return $stmt;
	} 

	function getAllServiceCarExceptOwner(){	
		$query = "SELECT service_car.*, service_customer.name FROM " . $this->table_name . " LEFT JOIN service_customer ON service_car.service_customer_id=service_customer.id WHERE service_customer_id<>:service_customer_id ORDER BY plate_no";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":service_customer_id", $this->service_customer_id);
		$stmt->execute();
		return $stmt;
	} 

	function updateOwner(){
		$query = "UPDATE " . $this->table_name . " SET service_customer_id=:service_customer_id WHERE id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":service_customer_id", $this->service_customer_id);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function autocomplete(){
		$condition = "";
		
		if($this->plate_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (plate_no LIKE  :plate_no '%' or plate_no LIKE '%' :plate_no '%' or plate_no Like '%' :plate_no )";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY plate_no";
		$stmt = $this->conn->prepare($query);
		if($this->plate_no) $stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->execute();
		return $stmt;
	}

	function search(){
		$condition = "";

		if($this->plate_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " plate_no=:plate_no ";
		}

		if($this->brand){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (brand LIKE  :brand '%' or brand LIKE '%' :brand '%' or brand Like '%' :brand ) ";
		}

		if($this->model){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (model LIKE  :model '%' or model LIKE '%' :model '%' or model Like '%' :model ) ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT service_car.*, service_customer.name, service_customer.phone_no FROM " . $this->table_name . " LEFT JOIN service_customer ON service_car.service_customer_id=service_customer.id " . $condition . " ORDER BY plate_no"; 

		$stmt = $this->conn->prepare($query);

		if($this->plate_no) $stmt->bindParam(":plate_no", $this->plate_no);
		if($this->brand) $stmt->bindParam(":brand", $this->brand);
		if($this->model) $stmt->bindParam(":model", $this->model);

		$stmt->execute();
		return $stmt;
	} 

	function getAllServiceCar(){	
		$query = "SELECT service_car.id, service_customer_id, service_car.plate_no, service_customer.name, service_customer.phone_no, brand, model, model_year, exterior_color, IFNULL(A, '') AS A, IFNULL(B, '') AS B, IFNULL(C, '') AS C, IFNULL(D, '') AS D, IFNULL(E, '') AS E
FROM " . $this->table_name . "
LEFT JOIN service_customer ON service_car.service_customer_id=service_customer.id LEFT JOIN (SELECT plate_no,             
MAX(CASE WHEN warranty = 'A' THEN if(`status`='', 'Valid', `status`) END) `A`,                                        
MAX(CASE WHEN warranty = 'B' THEN if(`status`='', 'Valid', `status`) END) `B`,                                        
MAX(CASE WHEN warranty = 'C' THEN if(`status`='', 'Valid', `status`) END) `C`,                                        
MAX(CASE WHEN warranty = 'D' THEN if(`status`='', 'Valid', `status`) END) `D`,                                        
MAX(CASE WHEN warranty = 'E' THEN if(`status`='', 'Valid', `status`) END) `E` FROM warranty_car GROUP BY plate_no) AS wc ON service_car.plate_no=wc.plate_no";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}  
}
?>