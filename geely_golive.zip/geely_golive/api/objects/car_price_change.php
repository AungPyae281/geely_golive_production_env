<?php
class CarPriceChange{
    // database connection and table name
	private $conn;
	private $table_name = "car_price_change";

	// object properties

	public $id;
	public $car_list_id;
	public $date_from;
	public $date_to;
	public $old_vehicle_price;
	public $vehicle_price;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET car_list_id=:car_list_id, date_from=:date_from, date_to=:date_to, old_vehicle_price=:old_vehicle_price, vehicle_price=:vehicle_price, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":car_list_id", $this->car_list_id);
		$stmt->bindParam(":date_from", $this->date_from);
		$stmt->bindParam(":date_to", $this->date_to);
		$stmt->bindParam(":old_vehicle_price", $this->old_vehicle_price);
		$stmt->bindParam(":vehicle_price", $this->vehicle_price);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){ 
			return true;
		}
		return false;		
	}
}
?>