<?php
class GLAccount{ 
	private $conn;
	private $table_name = "gl_account";
 
	public $id;
	public $type;
	public $category;
	public $gl_code;
	public $name;
	public $min_amount;
	public $max_amount;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE gl_code = :gl_code LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->gl_code = htmlspecialchars(strip_tags($this->gl_code)); 
		$stmt->bindParam(":gl_code", $this->gl_code); 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET `type`=:type, category=:category, gl_code=:gl_code, name=:name, min_amount=:min_amount, max_amount=:max_amount, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":type", $this->type);
		$stmt->bindParam(":category", $this->category);
		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":min_amount", $this->min_amount);
		$stmt->bindParam(":max_amount", $this->max_amount);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$condition = "";

		if($this->type){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `type` = :type ";
		}

		if($this->category){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " category = :category ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY gl_code, name";
		$stmt = $this->conn->prepare( $query );
		if($this->type) $stmt->bindParam(":type", $this->type);
		if($this->category) $stmt->bindParam(":category", $this->category);
		$stmt->execute();
		return $stmt;
	}

	function getAdvanceBalance(){
		$query = "SELECT gl_account.gl_code,gl_account.name,(IFNULL(opening_balance, 0) + IFNULL(total_debit, 0) - IFNULL(total_credit, 0)) AS balance FROM gl_account
				LEFT JOIN bank_account ON gl_account.gl_code=bank_account.gl_code
				LEFT JOIN
				(SELECT gl_code, SUM(credit) AS total_credit FROM (
				SELECT gl_code_from AS gl_code, SUM(amount_from) AS credit FROM bank_account_transfer WHERE  date<=:date GROUP BY gl_code_from
				UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit FROM advance WHERE  date<=:date GROUP BY gl_code_from
				UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit FROM account_transfer WHERE  date<=:date GROUP BY gl_code_from
				UNION ALL SELECT gl_code, SUM(amount) AS credit FROM payment WHERE date<=:date GROUP BY gl_code
				UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(amount) AS credit FROM deposit_refund WHERE date<=:date GROUP BY gl_code_bank_or_cash
				UNION ALL SELECT gl_code, SUM(amount) AS credit FROM deposit_refund WHERE date<=:date GROUP BY gl_code) AS tc GROUP BY gl_code) AS tc1 ON gl_account.gl_code=tc1.gl_code
				LEFT JOIN
				(SELECT gl_code, SUM(debit) AS total_debit FROM (
				SELECT gl_code_to AS gl_code, SUM(amount_to) AS debit FROM bank_account_transfer WHERE date<=:date GROUP BY gl_code_to
				UNION ALL SELECT gl_code_to AS gl_code, SUM(amount) AS debit FROM advance WHERE date<=:date GROUP BY gl_code_to
				UNION ALL SELECT gl_code_to AS gl_code, SUM(amount) AS debit FROM account_transfer WHERE date<=:date GROUP BY gl_code_to
				UNION ALL SELECT gl_code, SUM(sales.deposit) AS debit FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE r_date<=:date GROUP BY gl_code
				UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(sales.deposit) AS debit FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE  r_date<=:date GROUP BY gl_code_bank_or_cash
				UNION ALL SELECT gl_code, SUM(amount) AS debit FROM payment WHERE  date<=:date GROUP BY gl_code
				UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(amount) AS debit FROM payment WHERE  date<=:date GROUP BY gl_code_bank_or_cash) AS td GROUP BY gl_code) AS b ON gl_account.gl_code=b.gl_code
				WHERE gl_account.category = 'advance'";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getAllUnregisterBankGL(){
		$query = "SELECT gl_account.* FROM " . $this->table_name . " LEFT JOIN bank_account ON gl_account.gl_code=bank_account.gl_code WHERE bank_account.gl_code IS NULL AND gl_account.category='Bank' ORDER BY gl_account.gl_code, gl_account.name";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	} 

	function getBankCash(){
		$query = "SELECT * FROM " . $this->table_name . " where category in ('Bank','Cash')";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	} 

	function getAllTransaction(){
		$query   = "SELECT * FROM (SELECT '' as date, gl_account.gl_code, 'Opening Balance' as `transaction`, 0 AS credit, (IFNULL(opening_balance, 0) + IFNULL(total_debit, 0) - IFNULL(total_credit, 0)) AS debit, '' AS entry_date_time FROM gl_account
				LEFT JOIN bank_account ON gl_account.gl_code=bank_account.gl_code
				LEFT JOIN
				(SELECT gl_code, SUM(credit) AS total_credit FROM (
				SELECT gl_code_from AS gl_code, SUM(amount_from) AS credit FROM bank_account_transfer WHERE gl_code_from=:gl_code AND date<:date_from GROUP BY gl_code_from
				UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit FROM advance WHERE gl_code_from=:gl_code AND date<:date_from GROUP BY gl_code_from
				UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit FROM advance_claim WHERE gl_code_from=:gl_code AND date<:date_from GROUP BY gl_code_from
				UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit FROM account_transfer WHERE gl_code_from=:gl_code AND date<:date_from GROUP BY gl_code_from
				UNION ALL SELECT gl_code, SUM(amount) AS credit FROM payment WHERE gl_code=:gl_code AND date<:date_from GROUP BY gl_code
				UNION ALL SELECT gl_code, SUM(amount) AS credit FROM service_payment WHERE gl_code=:gl_code AND date<:date_from GROUP BY gl_code
				UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(amount) AS credit FROM deposit_refund WHERE gl_code_bank_or_cash=:gl_code AND date<:date_from GROUP BY gl_code_bank_or_cash
				UNION ALL SELECT gl_code, SUM(amount) AS credit FROM deposit_refund WHERE gl_code=:gl_code AND date<:date_from GROUP BY gl_code) AS tc GROUP BY gl_code) AS tc1 ON gl_account.gl_code=tc1.gl_code
				LEFT JOIN
				(SELECT gl_code, SUM(debit) AS total_debit FROM (
				SELECT gl_code_to AS gl_code, SUM(amount_to) AS debit FROM bank_account_transfer WHERE gl_code_to=:gl_code AND date<:date_from GROUP BY gl_code_to
				UNION ALL SELECT gl_code_to AS gl_code, SUM(amount) AS debit FROM advance WHERE gl_code_to=:gl_code AND date<:date_from GROUP BY gl_code_to
				UNION ALL SELECT gl_code_to AS gl_code, SUM(amount) AS debit FROM advance_claim WHERE gl_code_to=:gl_code AND date<:date_from GROUP BY gl_code_to
				UNION ALL SELECT gl_code_to AS gl_code, SUM(amount) AS debit FROM account_transfer WHERE gl_code_to=:gl_code AND date<:date_from GROUP BY gl_code_to
				UNION ALL SELECT gl_code, SUM(sales.deposit) AS debit FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE gl_code=:gl_code AND r_date<:date_from GROUP BY gl_code
				UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(sales.deposit) AS debit FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE gl_code=:gl_code AND r_date<:date_from GROUP BY gl_code_bank_or_cash
				UNION ALL SELECT gl_code, SUM(amount) AS debit FROM payment WHERE gl_code=:gl_code AND date<:date_from GROUP BY gl_code
				UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(amount) AS debit FROM payment WHERE gl_code_bank_or_cash=:gl_code AND date<:date_from GROUP BY gl_code_bank_or_cash
				UNION ALL SELECT gl_code, SUM(amount) AS debit FROM service_payment WHERE gl_code=:gl_code AND date<:date_from GROUP BY gl_code
				UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(amount) AS debit FROM service_payment WHERE gl_code_bank_or_cash=:gl_code AND date<:date_from GROUP BY gl_code_bank_or_cash) AS td GROUP BY gl_code) AS b ON gl_account.gl_code=b.gl_code
				WHERE gl_account.gl_code=:gl_code

				UNION ALL

				SELECT date, crdb.gl_code, `transaction`, credit, debit, entry_date_time FROM (
				SELECT date, gl_code_to AS gl_code, 'Bank Account Transfer' AS `transaction`, 0 AS credit, amount_to AS debit, entry_date_time FROM bank_account_transfer WHERE gl_code_to=:gl_code AND date>=:date_from AND date<=:date_to
				UNION ALL
				SELECT date, gl_code_to AS gl_code, 'Advance' AS `transaction`, 0 AS credit, amount AS debit, entry_date_time FROM advance WHERE gl_code_to=:gl_code AND date>=:date_from AND date<=:date_to
				UNION ALL
				SELECT date, gl_code_to AS gl_code, 'Advance Claim' AS `transaction`, 0 AS credit, amount AS debit, entry_date_time FROM advance_claim WHERE gl_code_to=:gl_code AND date>=:date_from AND date<=:date_to
				UNION ALL
				SELECT date, gl_code_to AS gl_code, 'Account Transfer' AS `transaction`, 0 AS credit, amount AS debit, entry_date_time FROM account_transfer WHERE gl_code_to=:gl_code AND date>=:date_from AND date<=:date_to
				UNION ALL
				SELECT r_date AS date, gl_code, CONCAT(deposit_receipt.oc_no, ' (Deposit)') AS `transaction`, 0 AS credit, sales.deposit AS debit, deposit_receipt.entry_date_time FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE gl_code=:gl_code AND r_date>=:date_from AND r_date<=:date_to
				UNION ALL
				SELECT r_date AS date, gl_code_bank_or_cash AS gl_code, CONCAT(deposit_receipt.oc_no, ' (Deposit)') AS `transaction`, 0 AS credit, sales.deposit AS debit, deposit_receipt.entry_date_time FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE gl_code_bank_or_cash=:gl_code AND r_date>=:date_from AND r_date<=:date_to
				UNION ALL
				SELECT date, gl_code, CONCAT(oc_no, ' ', description) AS `transaction`, 0 AS credit, amount AS debit, entry_date_time FROM payment WHERE gl_code=:gl_code AND date>=:date_from AND date<=:date_to
				UNION ALL
				SELECT date, gl_code_bank_or_cash AS gl_code, CONCAT(oc_no, ' ', description) AS `transaction`, 0 AS credit, amount AS debit, entry_date_time FROM payment WHERE gl_code_bank_or_cash=:gl_code AND date>=:date_from AND date<=:date_to
				UNION ALL
				SELECT service_payment.date, gl_code, CONCAT(service.registration_no, ' ', service_payment.description) AS `transaction`, 0 AS credit, amount AS debit, service_payment.entry_date_time FROM service_payment LEFT JOIN service ON service_payment.service_id=service.id WHERE gl_code=:gl_code AND service_payment.date>=:date_from AND service_payment.date<=:date_to
				UNION ALL
				SELECT service_payment.date, gl_code_bank_or_cash AS gl_code, CONCAT(service.registration_no, ' ', service_payment.description) AS `transaction`, 0 AS credit, service_payment.amount AS debit, service_payment.entry_date_time FROM service_payment LEFT JOIN service ON service_payment.service_id=service.id WHERE gl_code_bank_or_cash=:gl_code AND service_payment.date>=:date_from AND service_payment.date<=:date_to
				UNION ALL
				SELECT date, gl_code_from AS gl_code, 'Bank Account Transfer' AS `transaction`, amount_from AS credit, 0 AS debit, entry_date_time FROM bank_account_transfer WHERE gl_code_from=:gl_code AND date>=:date_from AND date<=:date_to
				UNION ALL
				SELECT date, gl_code_from AS gl_code, 'Advance' AS `transaction`, amount AS credit, 0 AS debit, entry_date_time FROM advance WHERE gl_code_from=:gl_code AND date>=:date_from AND date<=:date_to
				UNION ALL
				SELECT date, gl_code_from AS gl_code, 'Advance Claim' AS `transaction`, amount AS credit, 0 AS debit, entry_date_time FROM advance_claim WHERE gl_code_from=:gl_code AND date>=:date_from AND date<=:date_to
				UNION ALL
				SELECT date, gl_code_from AS gl_code, 'Account Transfer' AS `transaction`, amount AS credit, 0 AS debit, entry_date_time FROM account_transfer WHERE gl_code_from=:gl_code AND date>=:date_from AND date<=:date_to
				UNION ALL
				SELECT date, gl_code, CONCAT(oc_no, ' ', ' Payment Transfer to Bank or Cash Account') AS `transaction`, amount AS credit, 0 AS debit, entry_date_time FROM payment WHERE gl_code=:gl_code AND date>=:date_from AND date<=:date_to
				UNION ALL
				SELECT service_payment.date, gl_code, CONCAT(service.registration_no, ' ', ' Payment Transfer to Bank or Cash Account') AS `transaction`, service_payment.amount AS credit, 0 AS debit, service_payment.entry_date_time FROM service_payment LEFT JOIN service ON service_payment.service_id=service.id WHERE gl_code=:gl_code AND service_payment.date>=:date_from AND service_payment.date<=:date_to
				UNION ALL
				SELECT date, gl_code_bank_or_cash AS gl_code, CONCAT(oc_no, ' (Deposit Refund)') AS `transaction`, amount AS credit, 0 AS debit, entry_date_time FROM deposit_refund WHERE gl_code_bank_or_cash=:gl_code AND date>=:date_from AND date<=:date_to
				UNION ALL
				SELECT date, gl_code, CONCAT(oc_no, ' (Deposit Refund)') AS `transaction`, amount AS credit, 0 AS debit, entry_date_time FROM deposit_refund WHERE gl_code=:gl_code AND date>=:date_from AND date<=:date_to) AS crdb) AS main order by main.date, main.entry_date_time";

		$stmt = $this->conn->prepare($query);
		 
		$this->date_from=htmlspecialchars(strip_tags($this->date_from));
		$this->date_to=htmlspecialchars(strip_tags($this->date_to));
		$this->gl_code=htmlspecialchars(strip_tags($this->gl_code));
		 
		$stmt->bindParam(":date_from", $this->date_from);
		$stmt->bindParam(":date_to", $this->date_to);
		$stmt->bindParam(":gl_code", $this->gl_code);
		
		$stmt->execute();
		return $stmt;
	}


}
?>