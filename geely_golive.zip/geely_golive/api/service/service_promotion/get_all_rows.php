<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	  
	include_once '../../config/database.php';
	include_once '../../objects/service_promotion.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	  
	$service_promotion = new ServicePromotion($db);

	$stmt = $service_promotion->getAllRows();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();
	
	if($num>0){ 
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"promotion_name" => $promotion_name,
				"start_date" => $start_date,
				"end_date" => $end_date
			);
			array_push($arr["records"], $detail);
		} 
	} 
	echo json_encode($arr);
?>