<?php
	header("Access-Control-Allow-Origin: *");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service.php';
	 
	date_default_timezone_set('Asia/Rangoon');
	
	$database = new Database();
	$db = $database->getConnection();

	$service = new Service($db);

	$prefix = "SV-" . substr(date("Y"), -2) . date("m") . "-";
	echo $service->getGenerateRegNo($prefix);
?>