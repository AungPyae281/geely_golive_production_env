<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service.php';

    date_default_timezone_set('Asia/Rangoon');
     
    $database = new Database();
    $db = $database->getConnection();

    $service = new Service($db);
    $data = json_decode(file_get_contents("php://input"));

    $service->id = $data->id;
    $service->getOneService();
     
    $arr = array(
        "id" =>  $service->id,
        "plate_no" =>  $service->plate_no,
        "registration_no" => $service->registration_no,
        "contact_person" => $service->contact_person,
        "car_return_date" => $service->car_return_date,
        "car_return_time" => (($service->car_return_time!="")?date('h:i A', strtotime($service->car_return_time)):"")
    );
    echo json_encode($arr);
?>