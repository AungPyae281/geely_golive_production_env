<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service.php';
    
    date_default_timezone_set('Asia/Rangoon');
     
    $database = new Database();
    $db = $database->getConnection();

    $service = new Service($db);
    $data = json_decode(file_get_contents("php://input"));

    $service->df = $data->df;
    $service->dt = $data->dt;

    $stmt = $service->getAllServicingListForFN();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $detail = array(
                "id" => $id,
                "registration_no" => $registration_no,
                "date" => $service_date,
                "plate_no" => $plate_no,
                "contact_person" => $contact_person,
                "contact_phone" => $contact_phone,
                "total_waiting_time" => $total_waiting_time,
                "services" => $finish_services . '/' . $total_services,
                "total_amount" => number_format((int)$total_amount),
                "discount" => number_format((int)$discount),
                "net_amount" => number_format((int)$total_amount - (int)$discount)
            );
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>