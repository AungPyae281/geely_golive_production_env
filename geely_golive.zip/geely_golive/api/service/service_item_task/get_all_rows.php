<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	  
	include_once '../../config/database.php';
	include_once '../../objects/service_item_task.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	  
	$service_item_task = new ServiceItemTask($db);
	$data = json_decode(file_get_contents("php://input"));

	$service_item_task->service_item_id = $data->service_item_id;
	
	$stmt = $service_item_task->getAllRows();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"service_item_id" => $service_item_id,
				"service_item_name" => $service_item_name,
				"description" => $description,
				"tips" => $tips,
				"requirements" => $requirements
			);
			array_push($arr["records"], $detail);
		}
	}
	echo json_encode($arr);
?>