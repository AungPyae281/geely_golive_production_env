<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/staff_service_center.php';
    session_start();

    $database = new Database();
    $db = $database->getConnection();

    $staff_service_center = new StaffServiceCenter($db);
    $data = json_decode(file_get_contents("php://input"));

    if($_SESSION['user']!=""){

        $staff_service_center->id = $data->id; 
        
        if($staff_service_center->delete()){
            $msg_arr = array(
                "message" => "deleted"
            );
        }else{
            $msg_arr = array(
                "message" => "error"
            );
        }
    }else{
        $msg_arr = array(
            "message" => "session expire"
        );
    }
    echo json_encode($msg_arr);
?>