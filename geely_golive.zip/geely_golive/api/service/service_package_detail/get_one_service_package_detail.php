<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service_package.php';
    include_once '../../objects/service_package_detail.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $service_package = new ServicePackage($db);
    $service_package_detail = new ServicePackageDetail($db);
    $data = json_decode(file_get_contents("php://input"));

    $service_package->id = $data->id;
    $service_package_detail->service_package_id = $data->id;

    $service_package->getOneServicePackage();

    $service_package_details = array();

    $stmt = $service_package_detail->getServicePackageDetail();
    $num = $stmt->rowCount();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
    		$detail = array(
                "service_package_id" => $service_package_id,
                "service_item_id" => $service_item_id,
                "code" => $code,
                "service_item" => $service_item,
                "package_name" => $package_name,
                "price" => number_format($price),
                "waiting_time" => $waiting_time
            );
            array_push($service_package_details, $detail);
        }
    }

    $arr = array(    
        "id" => $service_package->id,
        "discount" => number_format($service_package->discount),
        "service_package_details" => $service_package_details
    );

    echo json_encode($arr);
?>