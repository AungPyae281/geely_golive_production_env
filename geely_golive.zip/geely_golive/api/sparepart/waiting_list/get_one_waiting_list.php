<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart_waiting_list.php';
    include_once '../../objects/sparepart_waiting_list_detail.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $sparepart_waiting_list = new SparepartWaitingList($db);
    $sparepart_waiting_list_detail = new SparepartWaitingListDetail($db);
    $data = json_decode(file_get_contents("php://input"));

    $sparepart_waiting_list->id = $data->id; 
    $sparepart_waiting_list->getOneWaitingList();

    $sparepart_waiting_list_detail->waiting_list_id = $data->id;

    $total_amount = 0;

    $sparepart_waiting_list_details = array();

    $stmt = $sparepart_waiting_list_detail->getWaitingListDetail();
    $num = $stmt->rowCount();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "id" => $id, 
                "sparepart_code" => $sparepart_code,
                "sparepart_name" => $sparepart_name,
                "price" => number_format($sales_price),
                "quantity" => number_format($quantity),
                "amount" => number_format((int)$sales_price * (int)$quantity)
            );
            $total_amount += ((int)$sales_price * (int)$quantity);
            array_push($sparepart_waiting_list_details, $detail);
        }
    }

    $arr = array(
        "id" =>  $sparepart_waiting_list->id,
        "wl_id" =>  $sparepart_waiting_list->wl_id,
        "service_center" => $sparepart_waiting_list->service_center,
        "service_customer_id" => $sparepart_waiting_list->service_customer_id,
        "customer_name" => $sparepart_waiting_list->customer_name,
        "customer_phone" => $sparepart_waiting_list->customer_phone,
        "service_car_id" => $sparepart_waiting_list->service_car_id,
        "plate_no" => $sparepart_waiting_list->plate_no,
        "total_amount" => $total_amount,
        "remark" => $sparepart_waiting_list->remark,
        "entry_by" => $sparepart_waiting_list->entry_by,
        "entry_date_time" => $sparepart_waiting_list->entry_date_time,
        "sparepart_waiting_list_details" => $sparepart_waiting_list_details
    );
    echo json_encode($arr);
?>