<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/sparepart_stock_out.php';
	include_once '../../objects/sparepart_stock_balance.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start(); 

	$database = new Database();
	$db = $database->getConnection();
	 
	$sparepart_stock_out = new SparepartStockOut($db);
	$sparepart_stock_balance = new SparepartStockBalance($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		$sparepart_stock_out->date = $data->date;
		$sparepart_stock_out->service_id = $data->service_id;
		$sparepart_stock_out->store_name = $data->store_name; 
		$sparepart_stock_out->sparepart_code = $data->sparepart_code;
		$sparepart_stock_out->sparepart_name = $data->sparepart_name;
		$sparepart_stock_out->quantity = $data->quantity;

		$damage = 0; 
		$lost = 0; 

		if($data->reason=="Damage"){
			$damage = 1; 
		}else if($data->reason=="Lost"){
			$lost = 1; 
		}

		$sparepart_stock_out->damage = $damage;
		$sparepart_stock_out->lost = $lost;

		$sparepart_stock_out->stock_out_by = $data->stock_out_by;
		$sparepart_stock_out->remark = $data->remark;
		$sparepart_stock_out->entry_by = $_SESSION['user'];
		$sparepart_stock_out->entry_date_time = date("Y-m-d H:i");

		$sparepart_stock_balance->store_name = $data->store_name; 
		$sparepart_stock_balance->sparepart_code = $data->sparepart_code;
		$sparepart_stock_balance->sparepart_name = $data->sparepart_name;

		$sparepart_stock_balance->reason = $data->reason;
		$sparepart_stock_balance->quantity = $data->quantity;

		if($sparepart_stock_balance->checkSparepartForStockOut()){
			if((int)$sparepart_stock_balance->bal_qty<=0 || (int)$sparepart_stock_balance->bal_qty<(int)$data->quantity){
				$msg_arr = array(
					"message" => "balance not enough"
				);
			}else{
			    if($sparepart_stock_out->create()){
			        if($sparepart_stock_balance->updateFromStockOut()){
			            $msg_arr = array(
							"message" => "created"
						);
			        }else{
			            $sparepart_stock_out->delete();
			            $msg_arr = array(
							"message" => "errorStockBalanceUpdate"
						); 
			        }    
			    }else{
			        $msg_arr = array(
						"message" => "errorStockOutCreate"
					);
			    }
			}
		}else{
			$msg_arr = array(
				"message" => "balance not enough"
			);
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($msg_arr);
?>