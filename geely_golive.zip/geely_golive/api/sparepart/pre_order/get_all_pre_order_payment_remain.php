<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart_pre_order.php'; 

    $database = new Database();
    $db = $database->getConnection();

    $sparepart_pre_order = new SparepartPreOrder($db);
    $data = json_decode(file_get_contents("php://input")); 

    $sparepart_pre_order->df = $data->df;
    $sparepart_pre_order->dt = $data->dt;
    $sparepart_pre_order->deposit = $data->deposit;

    $stmt = $sparepart_pre_order->getAllPreOrderPaymentRemain();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row); 
            $detail = array(
                "id" => $id,
                "pre_order_id" => $wl_id,
                "date" => $pre_order_date,
                "service_center" => $service_center,
                "customer_name" => $customer_name,
                "customer_phone" => $customer_phone,
                "plate_no" => $plate_no,
                "total_items" => (int)$total_items,
                "total_quantity" => (int)$total_quantity,
                "amount" => number_format((int)$total_amount),
                "payment" => number_format((int)$payment),
                "balance" => number_format((int)$balance)
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>