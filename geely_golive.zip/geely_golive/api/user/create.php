<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../config/database.php';
	include_once '../objects/user.php';

	$database = new Database();
	$db = $database->getConnection();

	$user = new User($db);
	$data = json_decode(file_get_contents("php://input"));
	
	$user->staff_id = $_POST['txtStaffID'];
	$user->username = $_POST['txtUserName'];
	$user->userrole = $_POST['cboUserRole'];
	$user->dashboard = $_POST['cboDashboard'];

	if($_POST['formState'] == "Create"){
		$user->password = $_POST['txtPassword'];
	}

	$targetPath = "";
	$img = $_FILES['file'];
	if(!empty($_FILES['file']))
	{
		$ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
		if($ext!=""){
			$newname = date("Y-m-d H-i-s") .  "." . $ext;
			$targetPath = './upload/' . $newname;
			move_uploaded_file($_FILES['file']['tmp_name'],$targetPath);
		}
		$user->profilepicture = $targetPath;	
	}

	if($_POST['formState'] == "Create"){
		$user->staff_name = $_POST['cboStaff'];

		if($user->isExistUsername()){
			$arr = array(
				"message" => "duplicate"
			);
		}else{
			if($user->create()){
				$arr = array(
					"message" => "created"
				);
			}else{
				$arr = array(
					"message" => "errorCreate"
				);
			}
		}
	}else{
		if($user->update()){
			$arr = array(
				"message" => "updated"
			);
		}else{
			$arr = array(
				"message" => "errorUpdate"
			);
		}
	}
	echo json_encode($arr);
?>