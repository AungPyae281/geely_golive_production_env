<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/gl_account.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $gl_account = new GLAccount($db);
    $data = json_decode(file_get_contents("php://input")); 

    $stmt = $gl_account->getAllUnregisterBankGL();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "id" => $id,
                "gl_code" => $gl_code,
                "name" => $name
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>