<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
	  
	include_once '../../config/database.php';
	include_once '../../objects/gl_account.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	  
	$gl_account = new GLAccount($db);
	$data = json_decode(file_get_contents("php://input"));
	
	$gl_account->date_from = $data->df;
	$gl_account->date_to = $data->dt;
	$gl_account->gl_code = $data->gl_code;
	
	$stmt = $gl_account->getAllTransaction();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	$closing_balance = 0 ;
	if($num>0){ 
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array( 
				"date" => ($date)?$date:"",
				"gl_code" => $gl_code,
				"transaction" => $transaction,
				"debit" => round((float)$debit,2),
				"credit" => round((float)$credit,2)
			);
			$closing_balance += (float)$debit - (float)$credit;
			array_push($arr["records"], $detail);
		} 
		$arr["closing_balance"] = round($closing_balance,2);
	} 
	echo json_encode($arr);
?>