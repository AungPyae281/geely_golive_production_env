<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/gl_account.php';

	date_default_timezone_set('Asia/Rangoon');
	session_start();

	$database = new Database();
	$db = $database->getConnection();

	$gl_account = new GLAccount($db);
	$data = json_decode(file_get_contents("php://input"));

	$gl_account->type = $data->type;
	$gl_account->category = $data->category;
	$gl_account->gl_code = $data->gl_code;
	$gl_account->name = $data->name;
	$gl_account->min_amount = $data->min_amount;
	$gl_account->max_amount = $data->max_amount;
	$gl_account->entry_by = $_SESSION['user'];
	$gl_account->entry_date_time = date("Y-m-d H:i:s");

	if($gl_account->isExist()){
		$arr = array(
			"message" => "duplicate"
		);
	}else{
		if($gl_account->create()){
			$arr = array(
				"message" => "created"
			);
		}else{
			$arr = array(
				"message" => "error"
			);
		}
	}
	echo json_encode($arr);
?>