<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/delivery_note.php';
    include_once '../../../config/_globle.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $delivery_note = new DeliveryNote($db);
    $data = json_decode(file_get_contents("php://input"));

    $delivery_note->oc_no = $data->oc_no;

    $delivery_note->getOneDeliveryNote();

    $arr = array(
        "oc_no" => $delivery_note->oc_no,
        "date" => $delivery_note->date,
        "delivery_to" => $delivery_note->delivery_to,
        "phone_no" => $delivery_note->phone_no,
        "address" => $delivery_note->address,
        "model" => $delivery_note->model,
        "grade" => $delivery_note->grade,
        "vin_no" => $delivery_note->vin_no,
        "engine" => $delivery_note->engine,
        "colour_ext_int" => $delivery_note->colour_ext_int,
        "registration_no" => $delivery_note->registration_no,
        "invoice_no" => $delivery_note->invoice_no,
        "sales_person" => $delivery_note->sales_person,
        "name" => $delivery_note->name,
        "nrc_no" => $delivery_note->nrc_no,
        "mobile_no" => $delivery_note->mobile_no,
        "cust_sig" => $app_url . "api/sales/sales/upload/" . $data->oc_no . "/signature.png",
        "se_sig" => $app_url . (($delivery_note->se_sig)?("api/hr/staff/signature/" . $delivery_note->se_sig):("img/signature_dummy.png")),
    );
    echo json_encode($arr);
?>