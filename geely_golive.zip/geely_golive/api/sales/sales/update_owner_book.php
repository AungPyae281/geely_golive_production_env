<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/sales.php';	

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$sales = new Sales($db);
	$data = json_decode($_POST['objArr']);

	if($_SESSION['staff_id']!=""){
		$targetPath = "";
		$img = "";

		if(!empty($_FILES['file-obho']))
		{
			$ext = pathinfo($_FILES['file-obho']['name'], PATHINFO_EXTENSION);
			if($ext!=""){
				if (!is_dir('./upload/' . $data[0]->oc_no)) {
			        mkdir('./upload/' . $data[0]->oc_no, 0777, true);
			    }

				$newname = "owner-book." . $ext;
				$targetPath = './upload/' . $data[0]->oc_no . '/' . $newname;
				move_uploaded_file($_FILES['file-obho']['tmp_name'], $targetPath);
				$img = $newname;
			}	
		}

		$sales->oc_no = $data[0]->oc_no;
		$sales->owner_book_img = $img;

		if($sales->updateOwnerBook()){ 
			$sales->status = "Owner Book Handover";
			$sales->processing = "";
			
			if(!$sales->updateStatus()){
				$arr = array(
					"message" => "Status Update Error"
				);
				echo json_encode($arr);
				die();
			}
			$arr = array(
				"message" => "created"
			);
		}else{
			$arr = array(
				"message" => "error"
			);
		}
	}else{
		$arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($arr);
?>