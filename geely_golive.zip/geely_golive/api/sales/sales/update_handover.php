<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/sales.php';	
	include_once '../../objects/car_stock.php';	
	include_once '../../objects/service_car.php';	
	include_once '../../objects/service_customer.php';	
	include_once '../../objects/service_customer_car.php';	
	include_once '../../objects/warranty_rules.php';
	include_once '../../objects/warranty_car.php';	

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$sales = new Sales($db);
	$car_stock = new CarStock($db);
	$service_car = new ServiceCar($db);
	$service_customer = new ServiceCustomer($db);
	$service_customer_car = new ServiceCustomerCar($db);
	$warranty_rules = new WarrantyRules($db);
	$warranty_car = new WarrantyCar($db);
	$data = json_decode($_POST['objArr']);

	if($_SESSION['staff_id']!=""){
		
		$sales->oc_no = $data[0]->oc_no;
		$sales->getSalesDetail();

		$targetPath = "";
		$img = "";

		if(!empty($_FILES['file-ho']))
		{
			$ext = pathinfo($_FILES['file-ho']['name'], PATHINFO_EXTENSION);
			if($ext!=""){
				if (!is_dir('./upload/' . $data[0]->oc_no)) {
			        mkdir('./upload/' . $data[0]->oc_no, 0777, true);
			    }

				$newname = "handover-vehicle." . $ext;
				$targetPath = './upload/' . $data[0]->oc_no . '/' . $newname;
				move_uploaded_file($_FILES['file-ho']['tmp_name'], $targetPath);
				$img = $newname;
			}	
		}

		$sales->oc_no = $data[0]->oc_no;
		$sales->handover_date = $data[0]->handover_date;
		$sales->handover_vehicle_img = $img;

		if($img){
			$sales->updateHandover();
		}
		$sales->status = "Handover";
		$sales->processing = "Owner Book Handover";

		if($sales->updateStatus()){
			$car_stock->oc_no = $data[0]->oc_no;
			$car_stock->location = "Handover";
			$car_stock->updateLocationHandover();

			// Service Customer

			$service_customer->name = $sales->rtad_name;
			$service_customer->nrc_no = $sales->rtad_nrc_no;
			$service_customer->phone_no = $sales->rtad_mobile_no;
			$service_customer->alternative_phone_no = "";
			$service_customer->email = "";
			$service_customer->township = $sales->rtad_township;
			$service_customer->address = "";
			$service_customer->source = "Sales";
			$service_customer->entry_by = $_SESSION["user"];
			$service_customer->entry_date_time = date("Y-m-d H:i:s");
			$service_customer_id = 0;

			if(!$service_customer->isExist()){
				$service_customer->registration_no = $service_customer->generateCode("S" . date("ymd"));
				$service_customer->create();
			}
			$service_customer_id = $service_customer->id;

			// Service Customer

			// Service Car

			$service_car->service_customer_id = $service_customer_id;
			$service_car->brand = $sales->brand;
			$service_car->model = $sales->model;
			$service_car->model_year = $sales->model_year;
			$service_car->exterior_color = $sales->exterior_color;
			$service_car->vin_no = $sales->vin_no;
			$service_car->engine_no = $sales->engine_no;
			$service_car->plate_no = $sales->plate_no;
			$service_car->entry_by = $_SESSION["user"];
			$service_car->entry_date_time = date("Y-m-d H:i:s");

			if($service_car->create()){
				$service_customer_car->service_customer_id = $service_customer_id;
				$service_customer_car->service_car_id = $service_car->id;
				$service_customer_car->plate_no = $sales->plate_no;
				$service_customer_car->entry_by = $_SESSION["user"];
				$service_customer_car->entry_date_time = date("Y-m-d H:i:s");

				$service_customer_car->create();
			}

			// Service Car

			// Warranty
		    $warranty_car->plate_no = $sales->plate_no;
		    $warranty_car->start_date = $data[0]->handover_date;
	        $warranty_car->entry_by = $_SESSION['user'];
	        $warranty_car->entry_date_time = date("Y-m-d H:i:s");

			$stmt = $warranty_rules->getWarrantyRules();
	    	$num = $stmt->rowCount();

	    	if($num>0){
	    		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		            extract($row); 
		            $expire_date = date("Y-m-d", strtotime("+" . $valid_duration, strtotime($data[0]->handover_date)));

		            $warranty_car->expire_date = $expire_date;
		            $warranty_car->warranty = $warranty;
		            $warranty_car->valid_kilometer = $valid_kilometer;

		            if(!$warranty_car->create()){
		            	$arr = array(
		            		"message" => "errorWarrantyCar"
		            	);
		            	echo json_encode($arr);
		            	die();
		            }
		        }
	    	}
			// Warranty
			
		}
		$arr = array(
			"message" => "created"
		);
	}else{
		$arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($arr);
?>