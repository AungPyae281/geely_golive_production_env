<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sales.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $sales = new Sales($db);
    $data = json_decode(file_get_contents("php://input"));

    $sales->oc_no = $data->oc_no;
    $sales->getOnePrint();

    $arr = array(
        "date" => $sales->date,
        "oc_no" => $sales->oc_no,
        "sales_center" => $sales->sales_center,

        "broker_registration_no" => $sales->broker_registration_no,
        "broker_name" => $sales->broker_name,

        "customer_registration_no" => $sales->customer_registration_no,
        "customer_name" => $sales->customer_name,
        "nrc_no" => $sales->nrc_no,
        "mobile_no" => $sales->mobile_no, 
        "email" => $sales->email, 
        "township" => $sales->township, 

        "customer_type" => $sales->customer_type, 
        "company_name" => $sales->company_name, 
        "company_register_no" => $sales->company_register_no, 

        "same_as_buyer" => (int)$sales->same_as_buyer, 
        "rtad_name" => $sales->rtad_name, 
        "rtad_nrc_no" => $sales->rtad_nrc_no, 
        "rtad_mobile_no" => $sales->rtad_mobile_no, 
        "rtad_township" => $sales->rtad_township, 

        "brand" => $sales->brand,
        "model" => $sales->model,
        "model_year" => $sales->model_year,
        "grade" => $sales->grade,
        "exterior_color" => $sales->exterior_color,
        "interior_color" => $sales->interior_color,
        "vin_no" => $sales->vin_no,
        "engine_no" => $sales->engine_no,

        "promotion_code" => $sales->promotion_code,
        "promotion_discount" => $sales->promotion_discount,

        "payment_type" => $sales->payment_type,
        "bank" => $sales->bank,
        "payment_percent" => $sales->payment_percent,
        "payment_term" => $sales->payment_term,

        "deposit" => number_format($sales->deposit), 
        "vehicle_price" => number_format($sales->vehicle_price), 
        "commercial_tax" => number_format($sales->commercial_tax), 
        "retail_price" => number_format((int)$sales->vehicle_price + (int)$sales->commercial_tax), 
        "rtad_tax" => number_format($sales->rtad_tax), 
        "total_price" => number_format((int)$sales->vehicle_price + (int)$sales->commercial_tax + (int)$sales->rtad_tax), 
        "selling_price" => number_format($sales->selling_price)
    ); 
    echo json_encode($arr);
?>