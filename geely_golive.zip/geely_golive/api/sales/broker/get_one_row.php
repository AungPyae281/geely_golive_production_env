<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/broker.php';
	include_once '../../objects/broker_bank_account.php';	
	 
	$database = new Database();
	$db = $database->getConnection();

	$broker = new Broker($db);
	$broker_bank_account = new BrokerBankAccount($db);
	$data = json_decode(file_get_contents("php://input"));

	$broker->id = $data->id;
	$broker->getOneRow();	

	$broker_bank_info = array();

	$broker_bank_account->broker_id = $data->id;
	$stmt = $broker_bank_account->getAllRowsByBroker();
	$num = $stmt->rowCount();

	if($num>0){
	    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
	        extract($row);
			$detail = array(
	            "id" => $id,
	            "broker_id" => $broker_id,
	            "name" => $name,
	            "account_no" => $account_no
	        );
	        array_push($broker_bank_info, $detail);
	    }
	}

	$arr = array(
	    "id" =>  $broker->id,
	    "registration_no" =>  $broker->registration_no,
		"name" => $broker->name,
		"gender" => $broker->gender,
		"dob" => $broker->dob,
		"nrc_no" => $broker->nrc_no,
		"phone" => $broker->phone,
		"email" => $broker->email,
		"address" => $broker->address, 
		"company" => $broker->company,
		"register_date" => $broker->register_date,
		"entry_by" => $broker->entry_by,
		"entry_date_time" => $broker->entry_date_time,
		"broker_bank_info" => $broker_bank_info
	);
	echo json_encode($arr);
?>