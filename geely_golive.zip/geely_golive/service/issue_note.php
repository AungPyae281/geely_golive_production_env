<?php include '../header.php'; ?>
<?php
	$action = "";
	$id = "";
	if(isset($_GET['act'])){
		if(!empty($_GET['act'])){
			$action = $_GET['act'];
		}
	}

	if(isset($_GET['id'])){
		if(!empty($_GET['id'])){
			$id = $_GET['id'];
		}
	}
?>
<style> 
	.form-group{
		font-size: 13px !important;
	}

	.col-form-label {
		padding-top: calc(0.20rem + 1px);
		padding-bottom: calc(0.375rem + 1px);
		margin-bottom: 0;
		font-size: 13px;
		line-height: 1.2;
	}

	.form-control {
		display: block;
		width: 100%;
		height: calc(1.11rem + 11px);
		padding: 0.375rem 0.75rem;
		font-size: 0.9rem;
		font-weight: 400;
		line-height: 1.2;
		color: #495057;
		background-color: #ffffff;
		background-clip: padding-box;
		border: 1px solid #ced4da;
		border-radius: 0.25rem;
		box-shadow: inset 0 0 0 rgba(0, 0, 0, 0);
		transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
	}

	.card-header {
		background-color: transparent;
		border-bottom: 1px solid rgba(0, 0, 0, 0.125);
		position: relative;
		padding: 0.35rem 1.10rem;
		border-top-left-radius: 0.25rem;
		border-top-right-radius: 0.25rem;
	}

	.btn{
		font-size: 13px;
		line-height: 1.4;
	}

	.table th, .table td {
		padding: 0.40rem;
	} 

	.breadcrumb-item {
		color: gray;
	}

	.breadcrumb-item.done{
		color: #000;
	}

	.breadcrumb-item.active {
		color: #000 !important;
		font-weight: bold;
	}

	.breadcrumb-item + .breadcrumb-item:before{
		content: ">" !important;
		font-weight: normal !important;
	} 
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Sparepart Issue Note (Stock Out Request)</h1>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item active">Arrival Inspection</li>
						<li class="breadcrumb-item">Service</li>
						<li class="breadcrumb-item">Job Card</li>
						<li class="breadcrumb-item">Final Inspection</li>
					</ol>
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
								<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
							</div>
							<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
						</div>
						<div class="card-body">	
							<div class="row">
								<div class="col-md-6">
									<div class="form-group row"> 
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Center: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtServiceCenter" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Registration No.: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtServiceRegistrationNo" value="" disabled>
										</div> 
									</div> 
									<div class="form-group row"> 
										<label class="col-md-4 col-form-label" style="text-align: right;">Contact Person: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtServiceContactPerson" data-id="" value="" disabled> 
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Contact Phone: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtServiceContactPhone" value="" disabled>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Plate No.: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtPlateNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Vin No.: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtVinNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Engine No.: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtEngineNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">SA Name: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtSAName" value="" disabled>
										</div>
									</div>
								</div>
							</div> 
						</div>
					</div>
				</div>
			</div>

			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">Sparepart List <span id="total_records" style="font-weight:bold;"></span></h3>
				</div>
				<div class="card-body p-0">
					<table class="table table-striped table-bordered" id="myTable">
						<thead>                  
							<tr>
								<th style="width: 5%">No.</th>
								<th style="width: 15%">Sparepart Code</th>
								<th>Sparepart Name</th>
								<th style="width: 10%">Request Qty</th>
								<th style="width: 10%">Received Qty</th>
								<th style="width: 10%">Price</th>
							</tr>
						</thead>
						<tbody></tbody>
					</table>
				</div>
			</div>

		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
    var id = '<?= $id ?>';
    var STATUS = "";
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
  	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker1').attr("data-date",customDate);
	$("#txtDatePicker1").val(customDate);

	$(function() {
		$("body").addClass("sidebar-collapse"); 
		$('#datePicker1').datepicker();
		getOneService();
	}); 

	function getOneService(){ 
		$.ajax({
			url: APP_URL + "api/service/service/get_one_service.php",
			type: "POST",
			data: JSON.stringify({ id: id })
		}).done(function(data) {
			var tf = false;
			$(".breadcrumb-item").removeClass("done");
			$(".breadcrumb-item").removeClass("active");
			$(".breadcrumb-item").each(function(){
				if(tf){
					$(this).addClass("active");
					return false;
				}else{
					$(this).addClass("done");
				}
				if($(this).text()==data.status){
					tf = true;
				}
			});
			STATUS = data.status;

			$("#txtServiceCenter").val(data.service_center);
			$("#txtServiceRegistrationNo").val(data.registration_no);
			$("#txtServiceContactPerson").val(data.contact_person);
			$("#txtServiceContactPerson").attr("data-id", data.service_customer_id);
			$("#txtServiceContactPhone").val(data.contact_phone);
			$("#txtPlateNo").val(data.plate_no);
			$("#txtSAName").val(data.sa_name);
			$("#txtVinNo").val(data.vin_no);
			$("#txtEngineNo").val(data.engine_no);

			$.each(data.spareparts, function(i, v) {
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + v.code + "</td>")
					.append("<td>" + v.name + "</td>")
					.append("<td style='text-align: right; padding-right: 25px;'>" + v.qty + "</td>")
					.append("<td style='text-align: right; padding-right: 25px;'>" + v.receive_qty + "</td>")
                    .append("<td style='text-align: right; padding-right: 25px;'>" + v.price + "</td>")
				);
			});
		});
	}
</script>	
