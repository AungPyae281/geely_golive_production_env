<?php include '../header.php'; ?>
<?php
	$action = "";
	$id = "";
	if(isset($_GET['act'])){
		if(!empty($_GET['act'])){
			$action = $_GET['act'];
		}
	}

	if(isset($_GET['id'])){
		if(!empty($_GET['id'])){
			$id = $_GET['id'];
		}
	}
?>
<style>
	.displayNone{
		display: none;
	} 

	.align{
		text-align: right;
	}

	.form-group{
		font-size: 13px !important;
	}

	.col-form-label {
		padding-top: calc(0.20rem + 1px);
		padding-bottom: calc(0.375rem + 1px);
		margin-bottom: 0;
		font-size: 13px;
		line-height: 1.2;
	}

	.form-control {
		display: block;
		width: 100%;
		height: calc(1.11rem + 11px);
		padding: 0.375rem 0.75rem;
		font-size: 0.9rem;
		font-weight: 400;
		line-height: 1.2;
		color: #495057;
		background-color: #ffffff;
		background-clip: padding-box;
		border: 1px solid #ced4da;
		border-radius: 0.25rem;
		box-shadow: inset 0 0 0 rgba(0, 0, 0, 0);
		transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
	}

	.card-header {
		background-color: transparent;
		border-bottom: 1px solid rgba(0, 0, 0, 0.125);
		position: relative;
		padding: 0.35rem 1.10rem;
		border-top-left-radius: 0.25rem;
		border-top-right-radius: 0.25rem;
	}

	.btn{
		font-size: 13px;
		line-height: 1.4;
	}

	.table th, .table td {
		padding: 0.40rem;
	}

	select{
		padding-top: 1px !important;
	}

	.breadcrumb-item {
		color: gray;
	}

	.breadcrumb-item.done{
		color: #000;
	}

	.breadcrumb-item.active {
		color: #000 !important;
		font-weight: bold;
	}

	.breadcrumb-item + .breadcrumb-item:before{
		content: ">" !important;
		font-weight: normal !important;
	}

	.toggle-group{
		width: 209%;
	}

	.toggle btn{
		width: 90.383px !important;
	}

	.badge{
		padding: 5px 12px;
		font-size: 11px;
		margin-right: 3px;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Service</h1>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item active">Arrival Inspection</li>
						<li class="breadcrumb-item">Service</li>
						<li class="breadcrumb-item">Job Card</li>
						<li class="breadcrumb-item">Final Inspection</li>
					</ol>
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="card-body">	
							<div class="row">
								<div class="col-md-6">
									<div class="form-group row"> 
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Center: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServiceCenter" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Registration No.: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServiceRegistrationNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Owner Name: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtOwnerName" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Owner Phone: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtOwnerPhone" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Appt. Contact Person: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtApptContactPerson" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Appt. Contact Phone: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtApptContactPhone" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Contact Person: </label>
										<div class="col-md-8">
											<div class="input-group input-group">
												<input id="txtServiceContactPerson" class="form-control" disabled value="" data-id="">
												<span class="input-group-btn">
													<button type="button" class="btn btn-primary" onclick="getAllServiceCustomer()" id="btnServiceCustomer" style="padding-bottom: 3px;">. . .</button>
												</span>         
											</div>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Contact Phone: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServiceContactPhone" value="" disabled>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Plate No.: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtPlateNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Model Name: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtModelName" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Vin No.: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtVinNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row" style="display:none;">
										<label class="col-md-4 col-form-label" style="text-align: right;">Valid Warranty: </label>
										<div class="col-md-8" id="ValidWarranty"></div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Main Technician: </label>
										<div class="col-md-8">
											<select class="form-control" id="cboMainTechnician"></select>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Visit Type: </label>
										<div class="col-md-8">
											<select class="form-control" id="cboVisitType">
												<option value=""></option>
												<option value="Initial Maintenance">Initial Maintenance</option>
												<option value="Regular Maintenance">Regular Maintenance</option>
												<option value="General Repair">General Repair</option>
												<option value="Warranty">Warranty</option>
												<option value="Body Repair&painting">Body Repair&painting</option>
												<option value="PDI">PDI</option>
												<option value="On Road Assistance">On Road Assistance</option>
												<option value="Warehouse unit Maintenance">Warehouse Unit Maintenance</option>
												<option value="Stock Arrival inspection">Stock Arrival Inspection</option>
												<option value="Inspection at port">Inspection at Port</option>
											</select>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Promotion: </label>
										<div class="col-md-8">
											<select class="form-control" id="cboServicePromotion"></select>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">SA Name: </label>
										<div class="col-md-8">
											<select class="form-control" id="cboSA"></select>
										</div>
									</div>
								</div>
							</div> 

							<div class="row" style="padding-top:12px;">
								<div class="col-md-12">
									<div class="card card-outline">
										<div class="card-header">
											<h3 class="card-title">Services</h3>
										</div>
										<div class="card-body">
											<div class="row">
												<div class="col-md-2">
													<div class="form-group row" style="margin-bottom: 0px !important; float: right;">
														<div class="icheck-primary d-inline" style="margin-right: 15px;">
															<input type="radio" id="optItem" value="Item" name="optServiceType" checked>
															<label for="optItem">Item</label>
														</div>
														<div class="icheck-primary d-inline" style="margin-right: 10px;">
															<input type="radio" id="optPackage" value="Package" name="optServiceType">
															<label for="optPackage">Package</label>
														</div>
													</div>
												</div>
												<div class="col-md-5">
													<div class="form-group row" style="margin-bottom: 5px !important;">
														<label class="col-md-3 col-form-label" style="text-align: right;">Code: </label>
														<div class="col-md-8">
															<input type="text" class="form-control" id="txtServiceItemCode" disabled>
														</div>
													</div>
													<div class="form-group row">
														<label class="col-md-3 col-form-label" style="text-align: right;">Name: </label>
														<div class="col-md-8">
															<div class="input-group input-group">
																<input id="txtServiceItemName" data-package-id="" data-price="0" class="form-control" disabled>
																<span class="input-group-btn">
																	<button type="button" class="btn btn-primary" onclick="getAllServiceItem()" id="btnServiceItem" style="padding-bottom: 3px;">. . .</button>
																</span>         
															</div>
														</div>
													</div>
												</div>	
												<div class="col-md-5">
													<div class="form-group row" style="margin-bottom: 5px !important;">
														<label class="col-md-3 col-form-label" style="text-align: right;">Waiting Time:</label>
														<div class="col-md-8">
															<input type="text" value="" class="form-control" id="txtServiceItemWaitingTime" disabled>
														</div>
													</div>
													<div class="form-group row">
														<label class="col-md-3 col-form-label" style="text-align: right;"></label>
														<div class="col-md-8" style="text-align: right;">
															<div class="checkbox" style="display: inline-block;">
																<label class="checkbox-inline"  style="padding-left: 20px;">
																	<input type="checkbox" data-toggle="toggle" id="chkWarrantyService" data-off="Warranty" data-on="Warranty" data-onstyle="success">
																</label>
															</div>
															<button type="button" class="btn btn-primary" onclick="addService()" id="btnAddService" style="width: 110px;">Add</button>
														</div>
													</div>
												</div>										
											</div>
											<div class="row">
												<div class="card-body p-0" style="height:250px; overflow-y: auto;">
													<table class="table table-bordered" id="myTableServiceItem">
														<thead>                  
															<tr> 
																<th style="width: 15%">Service Type</th>
																<th style="width: 15%">Package Name</th>
																<th style="width: 15%">Code</th>
																<th>Name</th>
																<th style="width: 15%">Waiting Time</th>
																<th style="width: 15%">Price</th>
																<th style="width: 10%">Warranty</th>
																<th style="width: 3%">Delete</th>
															</tr>
														</thead>
														<tbody></tbody>
													</table>
												</div>
											</div>
											<div class="row" style="padding-top: 9px;">
												<div class="col-md-9"></div>
												<div class="col-md-3">
													<div class="form-group row">
														<label class="col-md-4 col-form-label" style="text-align: right;">Total: </label>
														<div class="col-md-8" style="padding-right: 0px;">
															<input type="text" class="form-control" id="txtServiceItemTotalAmount" value="0" disabled style="text-align:right;">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="row" style="padding-top:12px;">
								<div class="col-md-12">
									<div class="card card-outline">
										<div class="card-header">
											<h3 class="card-title">Spareparts</h3>
										</div>
										<div class="card-body">
											<div class="row">
												<div class="col-md-6">
													<div class="form-group row" style="margin-bottom: 5px !important;">
														<label class="col-md-4 col-form-label" style="text-align: right;">Code: </label>
														<div class="col-md-8">
															<div class="input-group input-group">
																<input id="txtSparepartCode" type="text" class="form-control" disabled>
																<span class="input-group-btn">
																	<button type="button" class="btn btn-primary" onclick="getAllSpareparts()" id="btnSparepart" style="padding-bottom: 3px;">. . .</button>
																</span>         
															</div>
														</div>
													</div>
													<div class="form-group row">
														<label class="col-md-4 col-form-label" style="text-align: right;">Name: </label>
														<div class="col-md-8">
															<input id="txtSparepartName" value="" class="form-control" disabled>
														</div>
													</div>
												</div>
												<div class="col-md-6">
													<div class="form-group row" style="margin-bottom: 5px !important;">
														<label class="col-md-4 col-form-label" style="text-align: right;">Avail. Qty/Qty: </label>
														<div class="col-md-4">
															<input type="text" class="form-control" id="txtAvailQty" value="0" style="text-align:right;" disabled>
														</div>
														<div class="col-md-4">
															<input type="number" class="form-control" onkeypress="return isNumber(event)" onkeyup="btozero(this);" id="txtSparepartQty" value="1" min="1" style="text-align:right;">
														</div>
													</div>
													<div class="form-group row">
														<label class="col-md-4 col-form-label" style="text-align: right;">Price</label>
														<div class="col-md-4">
															<input type="text" class="form-control" id="txtSparepartPrice" value="0" style="text-align:right;" disabled>
														</div>
														<div class="col-md-4" style="text-align: right;">
															<div class="checkbox" style="display:inline-block; float: left;">
																<label class="checkbox-inline"  style="padding-left: 20px;">
																	<input type="checkbox" data-toggle="toggle" id="chkWarrantySpareparts" data-off="Warranty" data-on="Warranty" data-onstyle="success">
																</label>
															</div>
															<button type="button" class="btn btn-primary" onclick="addSparepart()" id="btnAddSparepart" style="width: 110px;">Add</button>
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="card-body p-0" style="height:192px; overflow-y: auto;">
													<table class="table table-bordered" id="myTableSparepart">
														<thead>                  
															<tr> 
																<th style="width: 12%;">Code</th>
																<th>Name</th>
																<th style="width: 10%">Warranty</th> 
																<th style="width: 15%">Price</th>
																<th style="width: 9%">Quantity</th>
																<th style="width: 15%">Amount</th>
															</tr>
														</thead>
														<tbody></tbody>
													</table>
												</div>
											</div>
											<div class="row" style="padding-top:9px;">
												<div class="col-md-9"></div>
												<div class="col-md-3">
													<div class="form-group row">
														<label class="col-md-4 col-form-label" style="text-align: right;">Total: </label>
														<div class="col-md-8" style="padding-right: 0px;">
															<input type="text" class="form-control" id="txtSparepartTotalAmount" value="0" disabled style="text-align:right;">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="row" style="padding-top:9px;"> 
								<div class="col-md-4"></div>
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Total Waiting Time: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtTotalWaitingTime" value="">
										</div>
									</div>
									<div class="form-group row" style="margin-bottom: 3px !important;">
										<label class="col-md-4 col-form-label" style="text-align: right;">Remark: </label>
										<div class="col-md-8">
											<textarea class="form-control" id="txtServiceRemark" rows="2"></textarea>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right; padding-top: 7px;">Test Drive Agree:</label>
										<div class="col-md-8 icheck-success d-inline">
											<input id="chkTestDriveAgree" type="checkbox">
											<label for="chkTestDriveAgree"></label>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Total Amount: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtTotalAmount" value="0" disabled style="text-align:right;">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Discount: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" onkeypress="return isNumber(event)" onkeyup="btozero(this);AddComma(this);calculate();" id="txtDiscount" value="0" style="text-align:right;">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Net Amount: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtNetAmount" value="0" disabled style="text-align:right;">
										</div>
									</div>
									<div class="form-group row">
										<div class="col-md-8"></div>
										<div class="col-md-4">
											<?php if($action=="entry"){ ?>
												<button type="button" class="btn btn-block btn-success" onclick="validateAndSave()">Submit</button>
											<?php }else{ ?>
												<button type="button" class="btn btn-block btn-primary" onclick="validateAndSave()">Update</button>
											<?php } ?>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div> 

					<center>
						<div class="modal fade" id="myModalServiceCustomer">
							<div class="modal-dialog" style="max-width: 100% !important;">
								<div class="modal-content" style="width: 70%; top: 29px;">
									<div class="modal-header" style="padding: 12px;">
										<h4 class="modal-title">Service Customer List</h4>
										<button type="button" class="btn btn-success btn-sm" onclick="goToNewServiceCustomer();" style="font-size: 14px; padding-left: 15px; padding-right: 15px; margin-left: 10px;"><i class="fas fa-user-plus"></i> Add New</button>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<div class="modal-body">
										<table id="myTableServiceCustomerModal" class="table table-head-fixed" style="cursor: pointer;">
											<thead>
												<tr>
													<th>No.</th>
													<th>Registration No.</th>
													<th>Name</th>
													<th>NRC No.</th>
													<th>Phone No.</th>
													<th>Email</th>
													<th>Township</th>
													<th style="display:none;">ID</th>
												</tr>
											</thead>
											<tbody></tbody>
										</table>
									</div>
								</div>
							</div>
						</div> 
					</center>
					
					<center>
						<div class="modal fade" id="myModalServiceItem">
							<div class="modal-dialog" style="max-width: 100% !important;">
								<div class="modal-content" style="width: 65%; top: 30px;">
									<div class="modal-header" style="padding: 12px;">
										<h4 class="modal-title">Service Item List <span id="total_records" style="font-weight:bold;"> </span></h4>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<div class="modal-body">
										<table id="myTableServiceItemModal" class="table table-head-fixed" style="cursor: pointer;">
											<thead>
												<tr>
													<th>Code</th>
													<th>Name</th>
													<th>Waiting Time</th>
													<th>Price</th>
													<th style="display:none;">ID</th>
												</tr>
											</thead>
											<tbody></tbody>
										</table>
									</div>
								</div>
							</div>
						</div> 
					</center>

					<center>
						<div class="modal fade" id="myModalServicePackage">
							<div class="modal-dialog" style="max-width: 100% !important;">
								<div class="modal-content" style="width: 65%; top: 30px;">
									<div class="modal-header" style="padding: 12px;">
										<h4 class="modal-title">Service Package List <span id="total_records" style="font-weight:bold;"> </span></h4>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<div class="modal-body">
										<table id="myTableServicePackageModal" class="table table-head-fixed" style="cursor: pointer;">
											<thead>
												<tr>
													<th>Name</th>
													<th>Price</th>
													<th style="display:none;"></th>
												</tr>
											</thead>
											<tbody></tbody>
										</table>
									</div>
								</div>
							</div>
						</div> 
					</center>
					
					<center>
						<div class="modal fade" id="myModalSparepart">
							<div class="modal-dialog" style="max-width: 100% !important;">
								<div class="modal-content" style="width: 75%; top: 29px;">
									<div class="modal-header" style="padding: 12px;">
										<h4 class="modal-title">Sparepart List</h4>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<div class="modal-body">
										<table class="table table-head-fixed" id="myTableSparepartModal" style="cursor:pointer;">
											<thead>                  
												<tr>
													<th>Group</th>
													<th>Sub Group</th>
													<th>Code</th>
													<th>Name</th>
													<th>Category</th>
													<th>Origin</th>
													<th>Unit</th>
													<th>Sales Price</th>
													<th>Dealer Price</th>
													<th>Avail. Qty</th>
													<th>ID</th>
												</tr>
											</thead>
											<tbody></tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</center>

				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
    var action = '<?= $action ?>';
    var id = '<?= $id ?>';
    var STATUS = "";
    var itemCodeArr = [];

	$(function() {
		$("body").addClass("sidebar-collapse"); 
		if(action=="edit"){
			$("#btnServiceCustomer").attr("disabled", true);
		}
		getOneService();
	}); 

	$("input[name='optServiceType']").change(function(){
		$("#txtServiceItemCode").val("");
		$("#txtServiceItemName").val("");
		$("#txtServiceItemName").attr("data-package-id", "");
		$("#txtServiceItemName").attr("data-price", 0);
		$("#txtServiceItemWaitingTime").val("");
	});

	$("#txtDiscount").on("input", function(){
		if(parseInt($("#txtTotalAmount").val().replace(/,/g, ''))<parseInt($("#txtDiscount").val().replace(/,/g, ''))){
			bootbox.alert("Discount amount is greater than total amount. Please check discount amount.");
			$("#txtDiscount").val(0);
		}
		calculate();
	});

	function getAllTechnician(eid){
		$("#cboMainTechnician").find("option").remove();
        $("#cboMainTechnician").append("<option value=''></option>");
        $.ajax({
            url: APP_URL + "api/hr/staff/get_staff_by_position.php",
            type: "POST",
            data: JSON.stringify({ position: "Technician" })
        }).done(function(data) {
            $.each(data.records, function(i, v) {
            	if(v.id==eid){
                	$("#cboMainTechnician").append("<option value ='" + v.id + "' selected>" + v.name + "</option>");
            	}else{
                	$("#cboMainTechnician").append("<option value ='" + v.id + "'>" + v.name + "</option>");
            	}
            });
        });
	}

	function getAllSA(eid){
		$("#cboSA").find("option").remove();
        $("#cboSA").append("<option value=''></option>");
        $.ajax({
            url: APP_URL + "api/hr/staff/get_staff_by_position.php",
            type: "POST",
            data: JSON.stringify({ position: "Service Advisor" })
        }).done(function(data) {
            $.each(data.records, function(i, v) {
            	if(v.id==eid){
                	$("#cboSA").append("<option value='" + v.id + "' selected>" + v.name + "</option>");
            	}else{
                	$("#cboSA").append("<option value='" + v.id + "'>" + v.name + "</option>");
            	}
            });
        });
	}

	function getAllServicePromotion(promotion){
		$("#cboServicePromotion").find("option").remove();
		$("#cboServicePromotion").append("<option value = ''></option>");
		$.ajax({
			url: APP_URL + "api/service/service_promotion/get_all_rows.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				if(v.promotion_name==promotion){
					$("#cboServicePromotion").append("<option value = '" + v.promotion_name + "' selected>" + v.promotion_name + "</option>");
				}else{
					$("#cboServicePromotion").append("<option value = '" + v.promotion_name + "'>" + v.promotion_name + "</option>");
				}
			});
		});
	}

	function getOneService(){
		$("#ValidWarranty").empty();
		$.ajax({
			url: APP_URL + "api/service/service/get_one_service.php",
			type: "POST",
			data: JSON.stringify({ id: id })
		}).done(function(data) {
			var tf = false;
			$(".breadcrumb-item").removeClass("done");
			$(".breadcrumb-item").removeClass("active");
			$(".breadcrumb-item").each(function(){
				if(tf){
					$(this).addClass("active");
					return false;
				}else{
					$(this).addClass("done");
				}
				if($(this).text()==data.status){
					tf = true;
				}
			});
			STATUS = data.status;

			getAllTechnician(data.main_technician_id);
			getAllSA(data.sa_id);

			$("#txtServiceCenter").val(data.service_center);
			$("#txtServiceRegistrationNo").val(data.registration_no);
			$("#txtOwnerName").val(data.owner_name);
			$("#txtOwnerPhone").val(data.owner_phone);
			$("#txtApptContactPerson").val(data.appt_contact_person);
			$("#txtApptContactPhone").val(data.appt_contact_phone);
			$("#txtServiceContactPerson").val(data.contact_person);
			$("#txtServiceContactPerson").attr("data-id", data.service_customer_id);
			$("#txtServiceContactPhone").val(data.contact_phone);
			$("#txtPlateNo").val(data.plate_no);
			$("#txtModelName").val(data.model);
			$("#txtVinNo").val(data.vin_no);

			if(data.valid_warranty.length>0){
				$("#ValidWarranty").parent().css("display", "");
				$.each(data.valid_warranty, function(i, v){
					$("#ValidWarranty").append('<span class="badge bg-primary">' + v + '</span>');
				});
			}else{
				$("#ValidWarranty").parent().css("display", "none");
			}

			$("#cboVisitType").val(data.visit_type);
			getAllServicePromotion(data.promotion);

			var package_id = 0;
			var x = 1;
			$.each(data.service_items, function(i, v) {
				var btn = "";
				if(v.technician_id==0){
					btn = "<button type='button' class='btn btn-danger btn-sm' style='padding: 2px 16px;font-size: 14px;' onclick='" + ((v.package_id==0)?"removeFromItemArr(this);$(this).parent().parent().remove();":"removeServicePackage();") + "calculate();calculateTotalWaitingTime();'><i class='far fa-trash-alt'></i></button>";
				}
				if(v.service_type=="Package"){
					$("#myTableServiceItem").find("tbody")
					.append($('<tr class="svpk' + v.package_id + '" data-service-type="' + v.service_type + '" data-package-name="' + v.package_name + '" data-item-code="' + v.item_code + '" data-item-name="' + v.item_name + '" data-item-wt="' + v.item_wt + '" data-item-price="0" data-package-price="' + v.package_price + '" data-technician-id="' + v.technician_id + '" data-bay-no="' + v.bay_no + '" data-start-time="' + v.start_time + '" data-end-time="' + v.end_time + '" data-warranty="' + v.warranty + '">')
						.append((package_id!=v.package_id)?("<td rowspan='' class='package" + v.package_id + "' style='vertical-align: middle;'>" + v.service_type + "</td>"):"")
						.append((package_id!=v.package_id)?("<td rowspan='' class='package" + v.package_id + "' style='vertical-align: middle;'>" + v.package_name + "</td>"):"")
						.append("<td style='padding: 0.40rem !important;'>" + v.item_code + "</td>")
						.append("<td style='padding: 0.40rem !important;'>" + v.item_name + "</td>")
						.append("<td style='padding: 0.40rem !important;'>" + v.item_wt + "</td>")
						.append((package_id!=v.package_id)?("<td rowspan='' class='package" + v.package_id + "' style='text-align:right; padding-right: 20px; vertical-align: middle;'>" + v.package_price + "</td>"):"")
						.append("<td>" + ((v.warranty==1)?"Yes":"No") + "</td>")
						.append((package_id!=v.package_id)?("<td rowspan='' class='package" + v.package_id + "' style='width: 70px; vertical-align: middle;'><button type='button' class='btn btn-danger btn-sm btn" + v.package_id + "' style='padding: 2px 16px;font-size: 14px;' onclick='removeServicePackage(this);calculate();calculateTotalWaitingTime();'><i class='far fa-trash-alt'></i></button>"):"")
					);
					if(v.package_id==package_id){
						++x;
						$("#myTableServiceItem .package" + package_id).attr("rowspan", x);
					}else{
						x = 1;
					}
					if(v.technician_id!=0){
						$(".btn" + v.package_id).remove();
					}
					package_id = v.package_id;
				}else{
					$("#myTableServiceItem").find("tbody")
					.append($('<tr class="svpk' + v.package_id + '" data-service-type="' + v.service_type + '" data-package-name="' + v.package_name + '" data-item-code="' + v.item_code + '" data-item-name="' + v.item_name + '" data-item-wt="' + v.item_wt + '" data-item-price="' + v.item_price + '" data-package-price="0" data-technician-id="' + v.technician_id + '" data-bay-no="' + v.bay_no + '" data-start-time="' + v.start_time + '" data-end-time="' + v.end_time + '" data-warranty="' + v.warranty + '">')
						.append("<td>" + v.service_type + "</td>")
						.append("<td data-package-id=''></td>")
						.append("<td>" + v.item_code + "</td>")
						.append("<td>" + v.item_name + "</td>")
						.append("<td>" + v.item_wt + "</td>")
						.append("<td style='text-align:right; padding-right: 20px;'>" + v.item_price + "</td>")
						.append("<td>" + ((v.warranty==1)?"Yes":"No") + "</td>")
						.append("<td style='width: 70px;'>" + btn + "</td>")
					);
				}

				itemCodeArr.push(v.item_code);
			});

			$.each(data.spareparts, function(i, v) { 
				$("#myTableSparepart").find("tbody")
				.append($('<tr>')
					.append("<td>" + v.code + "</td>")
					.append("<td>" + v.name + "</td>")
					.append("<td data-warranty='" + v.warranty + "'>" + ((v.warranty==1)?"Yes":"No") + "</td>") 
					.append("<td style='text-align:right; padding-right: 20px;'>" + v.price + "</td>")
					.append("<td style='text-align:right; padding-right: 20px;'>" + v.qty + "</td>")
					.append("<td style='text-align:right; padding-right: 20px;'>" + v.amount + "</td>") 
				);
			});

			if(data.total_waiting_time==""){
				calculateTotalWaitingTime();
			}else{
				$("#txtTotalWaitingTime").val(data.total_waiting_time);	
			}
			$("#txtServiceRemark").val(data.service_remark);
			$("#chkTestDriveAgree").prop("checked", data.test_drive_agree); 
			$("#txtDiscount").val(data.discount); 
			calculate();
		});
	}

	// Service Customer
	function goToNewServiceCustomer(){
		window.open(APP_URL + "service/service_customer.php?act=entry&s=service");
	}

	function getAllServiceCustomer(){ 
		table = $('#myTableServiceCustomerModal').DataTable({
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 10,
			"ajax": APP_URL + "api/service/service_customer/get_all_customer_data.php",
			"columnDefs": [
				{
					'targets': [7],
					"className": 'displayNone'
				}
			]
		});
		$("#myModalServiceCustomer").modal('show');
	}

	$('#myTableServiceCustomerModal').on('click', 'tbody tr', function(e){
		$("#myTableServiceCustomerModal tbody tr").css("color","");
		$("#myTableServiceCustomerModal tbody tr").css("background-color","");
		$(this).css("color", "rgb(34, 126, 140)");
		$(this).css("background-color", "#e3ecf5"); 

		$("#txtServiceContactPerson").val($(this).find("td").eq(2).text());
		$("#txtServiceContactPerson").attr("data-id", $(this).find("td").eq(7).text());
		$("#txtServiceContactPhone").val($(this).find("td").eq(4).text());
		$("#myModalServiceCustomer").modal('hide');
	});
	// Service Customer

	// Service Item
	function getAllServiceItem(){
		var service_type = $("input[name='optServiceType']:checked").val();

		if(service_type=="Item"){
			$("#myModalServiceItem").modal('show');
			table = $('#myTableServiceItemModal').DataTable({
				"destroy": true,
				"paging": true,
				"lengthChange": true,
				"searching": true,
				"ordering": true,
				"info": true,
				"autoWidth": false,
				"responsive": true,
				"lengthMenu": [5, 10, 50, 100],
				"pageLength": 5,
				"ajax": APP_URL + "api/service/service_item/get_all_service_item.php",
				"columnDefs": [
					{
						'targets': [3],
						"className": 'align'
					},
					{
						'targets': [4],
						"className": 'displayNone'
					}
				]
			});	
		}else{
			$("#myModalServicePackage").modal('show');
			table = $('#myTableServicePackageModal').DataTable({
				"destroy": true,
				"paging": true,
				"lengthChange": true,
				"searching": true,
				"ordering": true,
				"info": true,
				"autoWidth": false,
				"responsive": true,
				"lengthMenu": [5, 10, 50, 100],
				"pageLength": 5,
				"ajax": APP_URL + "api/service/service_package/get_all_service_package.php",
				"columnDefs": [
					{
						'targets': [1],
						'className': 'align'
					},
					{
						'targets': [2],
						'className': 'displayNone'
					}
				]
			});	
		}
	}

	$('#myTableServiceItemModal').on('click', 'tbody tr', function(e){
		$("#myTableServiceItemModal tbody tr").css("color","");
		$("#myTableServiceItemModal tbody tr").css("background-color","");
		$(this).css("color", "rgb(34, 126, 140)");
		$(this).css("background-color", "#e3ecf5"); 

		$("#txtServiceItemCode").val($(this).find("td").eq(0).text());
		$("#txtServiceItemName").val($(this).find("td").eq(1).text());
		$("#txtServiceItemName").attr("data-price", $(this).find("td").eq(3).text());
		$("#txtServiceItemWaitingTime").val($(this).find("td").eq(2).text());
		$("#myModalServiceItem").modal('hide');
	});

	$('#myTableServicePackageModal').on('click', 'tbody tr', function(e){
		$("#myTableServicePackageModal tbody tr").css("color","");
		$("#myTableServicePackageModal tbody tr").css("background-color","");
		$(this).css("color", "rgb(34, 126, 140)");
		$(this).css("background-color", "#e3ecf5"); 

		$("#txtServiceItemName").val($(this).find("td").eq(0).text());
		$("#txtServiceItemName").attr("data-package-id", $(this).find("td").eq(2).text());
		$("#txtServiceItemName").attr("data-price", $(this).find("td").eq(1).text());
		$("#myModalServicePackage").modal('hide');
	});

	function addService(){
		var service_type = $("input[name='optServiceType']:checked").val();
		var item_name = $("#txtServiceItemName").val();
		var warranty = ($("#chkWarrantyService").parent().hasClass("off"))?0:1;
		var price = (warranty==1)?"0":$("#txtServiceItemName").attr("data-price");

		if(service_type=="Item"){
			var item_code = $("#txtServiceItemCode").val();
			var waiting_time = $("#txtServiceItemWaitingTime").val();

			if(item_code==""){
				bootbox.alert("Please choose item.");
			}else{
				if(!itemCodeArr.includes(item_code)){
					$("#myTableServiceItem").find("tbody")
					.append($('<tr class="svpk0" data-service-type="' + service_type + '" data-package-name="" data-item-code="' + item_code + '" data-item-name="' + item_name + '" data-item-wt="' + waiting_time + '" data-item-price="' + price + '" data-package-price="0" data-technician-id="" data-bay-no="" data-start-time="" data-end-time="" data-warranty="' + warranty + '">')
						.append("<td>" + service_type + "</td>")
						.append("<td data-package-id=''></td>")
						.append("<td>" + item_code + "</td>")
						.append("<td>" + item_name + "</td>")
						.append("<td>" + waiting_time + "</td>")
						.append("<td style='text-align:right; padding-right: 20px;'>" + price + "</td>")
						.append("<td>" + ((warranty==1)?"Yes":"No") + "</td>")
						.append("<td style='width: 70px;'><button type='button' class='btn btn-danger btn-sm' style='padding: 2px 16px;font-size: 14px;' onclick='removeFromItemArr(this);$(this).parent().parent().remove();calculate();calculateTotalWaitingTime();'><i class='far fa-trash-alt'></i></button>")
					);
					itemCodeArr.push(item_code);
					calculate();
					calculateTotalWaitingTime();
					$("#txtServiceItemCode").val("");
					$("#txtServiceItemName").val("");
					$("#txtServiceItemName").attr("data-package-id", "");
					$("#txtServiceItemName").attr("data-price", "0");
					$("#txtServiceItemWaitingTime").val("");
				}else{
					bootbox.alert("Service item already exist!");
				}
			}
		}else{
			var service_package_id = $("#txtServiceItemName").attr("data-package-id");

			if(service_package_id==""){
				bootbox.alert("Please refresh the browser.");
			}else{
				$.ajax({
					url: APP_URL + "api/service/service_package_detail/get_service_package_detail.php",
					type: "POST",
					data: JSON.stringify({ service_package_id: service_package_id })
				}).done(function(data) {
					var tf = false;
					$.each(data.records, function(i, v) {
						if(itemCodeArr.includes(v.code)){
							tf = true;
						}
					});

					if(!tf){
						$.each(data.records, function(i, v) {
							$("#myTableServiceItem").find("tbody")
							.append($('<tr class="svpk' + service_package_id + '" data-service-type="' + service_type + '" data-package-name="' + item_name + '" data-item-code="' + v.code + '" data-item-name="' + v.service_item + '" data-item-wt="' + v.waiting_time + '" data-item-price="0" data-package-price="' + price + '" data-technician-id="" data-bay-no="" data-start-time="" data-end-time="" data-warranty="' + warranty + '">')
								.append((i==0)?("<td rowspan='' class='package" + service_package_id + "' style='vertical-align: middle;'>" + service_type + "</td>"):"")
								.append((i==0)?("<td rowspan='' class='package" + service_package_id + "' style='vertical-align: middle;'>" + item_name + "</td>"):"")
								.append("<td style='padding: 0.40rem !important;'>" + v.code + "</td>")
								.append("<td style='padding: 0.40rem !important;'>" + v.service_item + "</td>")
								.append("<td style='padding: 0.40rem !important;'>" + v.waiting_time + "</td>")
								.append((i==0)?("<td rowspan='' class='package" + service_package_id + "' style='text-align:right; padding-right: 20px; vertical-align: middle;'>" + price + "</td>"):"")
								.append("<td>" + ((warranty==1)?"Yes":"No") + "</td>")
								.append((i==0)?("<td rowspan='' class='package" + service_package_id + "' style='width: 70px; vertical-align: middle;'><button type='button' class='btn btn-danger btn-sm btn" + v.package_id + "' style='padding: 2px 16px;font-size: 14px;' onclick='removeServicePackage(this);calculate();calculateTotalWaitingTime();'><i class='far fa-trash-alt'></i></button>"):"")
							);
							itemCodeArr.push(v.code);

							if(data.records.length==(i + 1)){
								$("#myTableServiceItem .package" + service_package_id).attr("rowspan", data.records.length);
								calculate();
								calculateTotalWaitingTime();
								$("#txtServiceItemCode").val("");
								$("#txtServiceItemName").val("");
								$("#txtServiceItemName").attr("data-package-id", "");
								$("#txtServiceItemName").attr("data-price", "0");
								$("#txtServiceItemWaitingTime").val("");
							}
						});
					}else{
						bootbox.alert("Service item already exist!");
					}
				});
			}
		}
	}

	function removeServicePackage(obj){
		$("." + $(obj).parent().parent().attr("class")).each(function(){
			itemCodeArr = itemCodeArr.filter(item => item !== $(this).attr("data-item-code"));
		});
		$("." + $(obj).parent().parent().attr("class")).remove();
	}

	function removeFromItemArr(obj){
		itemCodeArr = itemCodeArr.filter(item => item !== $(obj).parent().parent().attr("data-item-code"));
	}
	// Service Item

	// Sparepart
	function getAllSpareparts(){
		var service_center = $("#txtServiceCenter").val(); 

		table = $('#myTableSparepartModal').DataTable({
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"ajax": APP_URL + "api/sparepart/sparepart/get_all_spareparts_by_service_center.php?sc=" + service_center,
			"columnDefs": [
				{
					'targets': [10],
					"className": 'displayNone'
				},
				{
					'targets': [7, 8, 9],
					"className": 'align'
				}
			]
		});
		$("#myModalSparepart").modal('show');
	}

	$('#myTableSparepartModal').on('click', 'tbody tr', function(e){
		$("#myTableSparepartModal tbody tr").css("color","");
		$("#myTableSparepartModal tbody tr").css("background-color","");
		$(this).css("color", "rgb(34, 126, 140)");
		$(this).css("background-color", "#e3ecf5"); 

		$("#txtSparepartCode").val($(this).find("td").eq(2).text());
		$("#txtSparepartName").val($(this).find("td").eq(3).text());
		$("#txtSparepartPrice").val($(this).find("td").eq(7).text());
		$("#txtAvailQty").val($(this).find("td").eq(9).text());
		$("#txtSparepartQty").attr("max", $(this).find("td").eq(9).text());
		$("#myModalSparepart").modal('hide');
	});

	function addSparepart(){ 
		var item_code = $("#txtSparepartCode").val();
		var item_name = $("#txtSparepartName").val();
		var price = parseInt($("#txtSparepartPrice").val().replace(/,/g, ''));
		var aval_qty = parseInt($("#txtAvailQty").val().replace(/,/g, ''));
		var qty = parseInt($("#txtSparepartQty").val().replace(/,/g, ''));
		var warranty = ($("#chkWarrantySpareparts").parent().hasClass("off"))?0:1;

		if(item_code==""){
			bootbox.alert("Please choose item.");
		}else if(qty==0){
			bootbox.alert("Please fill qty.");
		}else if(aval_qty<qty){
			bootbox.alert("Check again qty!");
		}else{
			$.ajax({
				url: APP_URL + "api/service/service_detail_sparepart/create.php",
				type: "POST",
				data: JSON.stringify({ service_id: id, code: item_code, name: item_name, qty: qty, warranty: warranty })
			}).done(function(data) {
				if(data.message=="created"){ 

					if(!checkSparepart(item_code, qty, price, warranty)){
						$("#myTableSparepart").find("tbody")
						.append($('<tr>')
							.append("<td>" + item_code + "</td>")
							.append("<td>" + item_name + "</td>")
							.append("<td data-warranty='" + warranty + "'>" + ((warranty==1)?"Yes":"No") + "</td>") 
							.append("<td style='text-align:right; padding-right: 20px;'>" + price.toLocaleString() + "</td>")
							.append("<td style='text-align:right; padding-right: 20px;'>" + qty.toLocaleString() + "</td>")
							.append("<td style='text-align:right; padding-right: 20px;'>" + ((warranty==1)?0:(price * qty).toLocaleString()) + "</td>")
						);
					}
					calculate();
					$("#txtSparepartCode").val("");
					$("#txtSparepartName").val("");
					$("#txtSparepartPrice").val(0);
					$("#txtSparepartQty").val(1);
				}else if(data.message=="not enough"){
					bootbox.alert("This item is not enough. Please check again.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}

	function checkSparepart(code, qty, price, warranty){
		var tf = false;
		$("#myTableSparepart tbody tr").each(function(){
			if($(this).find("td").eq(0).text()==code && parseInt($(this).find("td").eq(2).attr("data-warranty"))==warranty){
				var quantity = parseInt($(this).find("td").eq(4).text().replace(/,/g, '')) + qty;
				var amount = ((warranty==1)?0:(price * quantity).toLocaleString());
				$(this).find("td").eq(3).text(price.toLocaleString());
				$(this).find("td").eq(4).text(quantity.toLocaleString());
				$(this).find("td").eq(5).text(amount);
				tf = true;
				return false;
			}
		});
		return tf;
	} 
	// Sparepart

	function calculateTotalWaitingTime(){
		var total_mins = hour = min = 0;
		var est_time = "";

		$("#myTableServiceItem tbody tr").each(function (i,v){
			var wt = "";
			if($(this).find("td").length>4){
				var wt = $(this).find("td").eq(4).text().split(":");
			}else{
				var wt = $(this).find("td").eq(2).text().split(":");
			}
			if(wt.length>0){
				total_mins += ((parseInt(wt[0]) * 60) + parseInt(wt[1]));
			}
		});

		hour = parseInt(total_mins/60);
		min = (hour<parseFloat(total_mins/60))?Math.round((parseFloat(total_mins/60) - hour) * 60):0;
		total_wt = ((hour>9)?hour:"0" + hour) + ":" + ((min>9)?min:"0" + min);

		$("#txtTotalWaitingTime").val(total_wt);
	}

	function calculate(){
		var discount = (($("#txtDiscount").val()!="" && $("#txtDiscount").val()!=null)?parseInt($("#txtDiscount").val().replace(/,/g, '')):0);
		var total_service_item = total_sparepart = total_amount = net_amount = 0;

		$("#myTableServiceItem tbody tr").each(function (i,v){
			if($(this).find("td").length>4){
				total_service_item += parseInt($(this).find("td").eq(5).text().replace(/,/g, ''));
			}
		});
		$("#txtServiceItemTotalAmount").val(total_service_item.toLocaleString());

		$("#myTableSparepart tbody tr").each(function (i,v){
			total_sparepart += parseInt($(this).find("td").eq(5).text().replace(/,/g, ''));
		});
		$("#txtSparepartTotalAmount").val(total_sparepart.toLocaleString());

		total_amount = (total_service_item + total_sparepart);
		net_amount = (total_amount - discount);

		$("#txtTotalAmount").val(total_amount.toLocaleString());
		$("#txtNetAmount").val(net_amount.toLocaleString());
	}  

	function validateAndSave(){
		var service_customer_id = $("#txtServiceContactPerson").attr("data-id");
		var sa_id = $("#cboSA").val();
		var main_technician_id = $("#cboMainTechnician").val();
		var visit_type = $("#cboVisitType").val();
		var promotion = $("#cboServicePromotion").val();
		var total_waiting_time = $("#txtTotalWaitingTime").val();
		var service_remark = $("#txtServiceRemark").val();
		var test_drive_agree = (($("#chkTestDriveAgree").prop("checked"))?1:0); 
		var discount = parseInt($("#txtDiscount").val().replace(/,/g, ''));
		var status = "";
		if(STATUS=="Arrival Inspection"){
			status = "Service";
		}

		var service_detail = [];
		$("#myTableServiceItem tbody tr").each(function(){
			var detail = {
				"service_type": $(this).attr("data-service-type"),
				"package_id": parseInt($(this).attr("class").replace("svpk", "")),
				"package_name": $(this).attr("data-package-name"),
				"item_code": $(this).attr("data-item-code"),
				"item_name": $(this).attr("data-item-name"),
				"item_wt": $(this).attr("data-item-wt"),
				"item_price": parseInt($(this).attr("data-item-price").replace(/,/g, '')),
				"package_price": parseInt($(this).attr("data-package-price").replace(/,/g, '')),
				"technician_id": $(this).attr("data-technician-id"),
				"bay_no": $(this).attr("data-bay-no"),
				"start_time": $(this).attr("data-start-time"),
				"end_time": $(this).attr("data-end-time"),
				"warranty": parseInt($(this).attr("data-warranty"))
			}
			service_detail.push(detail);
		});

		if(service_customer_id=="" || service_customer_id=="0"){
			bootbox.alert("Please choose service customer.");
		}else if(sa_id==""){
			bootbox.alert("Please choose SA.");
		}else if(service_detail.length==0){
			bootbox.alert("Please choose at least one service item.");
		}else{
			$.ajax({
				url: APP_URL + "api/service/service/update_service.php",
				type: "POST",
				data: JSON.stringify({ id: id, service_customer_id: service_customer_id, sa_id: sa_id, main_technician_id: main_technician_id, visit_type: visit_type, promotion: promotion, total_waiting_time: total_waiting_time, service_remark: service_remark, test_drive_agree: test_drive_agree, discount: discount, status: status, service_detail: service_detail })
			}).done(function(data) {
				if(data.message=="updated"){ 
					document.location = APP_URL + "service/servicing_list.php"; 
				}else if(data.message=="session expire"){
					bootbox.alert("Session Expire! Please refresh the browser and login again.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	} 

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function AddComma(obj) {
		var amount = $(obj).val().replace(/,/g, '');
		$(obj).val(parseInt(amount).toLocaleString());
	} 
</script>	
