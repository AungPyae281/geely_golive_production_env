<?php include '../header.php'; ?>
<style>
	.displayNone{
		display: none;
	}
	.align{
		text-align: right;
	}
	select{
		padding-top: 1px !important;
	}
</style> 
<?php
	$id = "";
	if(isset($_GET['id'])){
		if(!empty($_GET['id'])){
			$id = $_GET['id'];
		}
	}
?>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6"> 
					<h1>Service Promotion - <?php if($id){ ?>Edit <?php }else{ ?> Entry <?php } ?></h1> 
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Input</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360" style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Promotion Name: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPromotionName">
											</div>
										</div>
									</div>
									<div class="col-md-4">
									    <div class="form-group row">
									    	<label class="col-md-4 col-form-label" style="text-align: right;">Start Date:</label>
											<div class="col-md-8">	
												<div class="input-group input-append date" id="datePicker1" data-date="2020-02-07" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker1" value="1982-06-15" readonly>
												</div>
											</div>
									    </div>						
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">End Date:</label>
											<div class="col-md-8">	
												<div class="input-group input-append date" id="datePicker2" data-date="2020-02-07" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker2" value="1982-06-15" readonly>
												</div>
											</div>
										</div>	
									</div>
								</div>	 
								<div class="row" style="padding-top: 12px;">
									<div class="col-md-4" style="border-right: 1px solid #ddd !important;">
										<legend style="font-size: 16px !important;">Service Promotion Package</legend>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Name: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboPackage"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Discount (%): </label>
											<div class="col-md-6">
												<input type="text" class="form-control" onkeypress="return isNumber(event)" onkeyup="btozero(this);" id="txtPackageDiscount" value="0" style="text-align:right;">
											</div>
											<div class="col-md-2">
												<button type="button" class="btn btn-primary btn-block" onclick="addPackage()">Add</button>
											</div>
										</div>
										<div class="card-body p-0" style="height:200px; overflow-y: auto;background-color: #e6e7e8 !important;">
											<table class="table table-striped table-bordered" id="myTable2">
												<thead>                  
													<tr> 
														<th>Name</th>
														<th>Discount (%)</th>
														<th style="width: 3%">Delete</th>
													</tr>
												</thead>
												<tbody></tbody>
											</table>
										</div>
									</div>
									<div class="col-md-4" style="border-right: 1px solid #ddd !important;">
										<legend style="font-size: 16px !important;">Service Promotion Gift</legend>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Name: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboGift"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Quantity: </label>
											<div class="col-md-6">
												<input type="text" class="form-control" onkeypress="return isNumber(event)" onkeyup="btozero(this);" id="txtGiftQuantity" value="0" style="text-align:right;">
											</div>
											<div class="col-md-2">
												<button type="button" class="btn btn-primary btn-block" onclick="addGift()">Add</button>
											</div>
										</div>
										<div class="card-body p-0" style="height:200px; overflow-y: auto;background-color: #e6e7e8 !important;">
											<table class="table table-striped table-bordered" id="myTable3">
												<thead>                  
													<tr> 
														<th>Name</th>
														<th>Quantity</th>
														<th style="width: 3%">Delete</th>
													</tr>
												</thead>
												<tbody></tbody>
											</table>
										</div>
									</div>
									<div class="col-md-4">
										<legend style="font-size: 16px !important;">Service Promotion Sparepart</legend>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Name: </label>
											<div class="col-md-8">
												<div class="input-group input-group">
													<input id="txtSparepart" data-code="" value="" class="form-control" disabled>
													<span class="input-group-btn">
														<button type="button" class="btn btn-primary" onclick="getAllSpareparts()" id="btnSparepart" style="padding-bottom: 3px;">. . .</button>
													</span>         
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Discount (%): </label>
											<div class="col-md-6">
												<input type="text" class="form-control" onkeypress="return isNumber(event)" onkeyup="btozero(this);" id="txtSparepartDiscount" value="0" style="text-align:right;">
											</div>
											<div class="col-md-2">
												<button type="button" class="btn btn-primary btn-block" onclick="addSparepart()">Add</button>
											</div>
										</div>
										<div class="card-body p-0" style="height:200px; overflow-y: auto;background-color: #e6e7e8 !important;">
											<table class="table table-striped table-bordered" id="myTable4">
												<thead>                  
													<tr>
														<th>Name</th>
														<th>Discount (%)</th>
														<th style="width: 3%">Delete</th>
													</tr>
												</thead>
												<tbody></tbody>
											</table>
										</div>
									</div>
								</div>
								<div class="row" style="padding-top: 9px;">
									<div class="col-md-8"></div>
									<div class="col-md-4">
										<div class="form-group row">
											<div class="col-md-8"></div>
											<div class="col-md-4"> 
												<?php if($id==""){ ?>
													<button type="button" class="btn btn-success btn-block" onclick="createUpdate()">Create</button>
												<?php }else{ ?>
													<button type="button" class="btn btn-primary btn-block" onclick="createUpdate()">Update</button>
												<?php } ?>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>

						<center>
							<div class="modal fade" id="myModalSparepart">
								<div class="modal-dialog" style="max-width: 100% !important;">
									<div class="modal-content" style="width: 70%;top: 29px;">
										<div class="modal-header" style="padding: 12px;">
											<h4 class="modal-title">Sparepart List</h4>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body">
											<table class="table table-head-fixed" id="myTable1" style="cursor:pointer;">
												<thead>                  
													<tr>
														<th>Group</th>
														<th>Sub Group</th>
														<th>Code</th>
														<th>Name</th>
														<th>Category</th>
														<th>Origin</th>
														<th>Unit</th>
														<th>Sales Price</th>
														<th>Dealer Price</th>
													</tr>
												</thead>
												<tbody></tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</center>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script> 
	var id = '<?=$id;?>';
	var package_arr = [];
	var gift_arr = [];

	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var yyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker1').attr("data-date",customDate);
	$("#txtDatePicker1").val(customDate);
	$('#datePicker2').attr("data-date",customDate);
	$("#txtDatePicker2").val(customDate);

	$(function() {
		$("body").addClass("sidebar-collapse");
		$('#datePicker1').datepicker();
		$('#datePicker2').datepicker(); 
		if(id){
			getOneRow();
		}else{
			getAllServicePackage();
			getAllServiceGift();
		}
	});

	function getAllServicePackage(){
        $("#cboPackage").find("option").remove();
        $("#cboPackage").append("<option value = '' data-id = ''></option>");
        $.ajax({
            url: APP_URL + "api/service/service_package/get_all_rows.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
            	if(!package_arr.includes(v.id)){
                	$("#cboPackage").append("<option value = '" + v.package_name + "' data-id = '" + v.id + "'>" + v.package_name + "</option>");
            	}
            });
        });
    }

    function getAllServiceGift(id){
        $("#cboGift").find("option").remove();
        $("#cboGift").append("<option value = '' data-id = ''></option>");
        $.ajax({
            url: APP_URL + "api/service/service_gift/get_all_rows.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
            	if(!gift_arr.includes(v.id)){
                	$("#cboGift").append("<option value = '" + v.name + "' data-id = '" + v.id + "'>" + v.name + "</option>");
                }
            });
        });
    }

    function getAllSpareparts(){
		$("#myModalSparepart").modal('show');
		table = $('#myTable1').DataTable({
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"ajax": APP_URL + "api/sparepart/sparepart/get_all_spareparts.php",
			"columnDefs": [
				{
					'targets': [7, 8],
					"className": 'align'
				}
			]
		});	
	} 

	$('#myTable1').on('click', 'tbody tr', function(e){ 
		$("#myTable1 tbody tr").css("color", "");
		$("#myTable1 tbody tr").css("background-color", "");
		$(this).css("color", "rgb(34, 126, 140)");
		$(this).css("background-color", "#e3ecf5"); 
		$("#txtSparepart").val($(this).find("td").eq(3).text());
		$("#txtSparepart").attr("data-code", $(this).find("td").eq(2).text());
		$("#myModalSparepart").modal('hide');
	});

	function addPackage(){
		var service_package_id = $("#cboPackage option:selected").attr('data-id');
		var service_package = $("#cboPackage").val();
		var discount_percent = parseInt($("#txtPackageDiscount").val().replace(/,/g, ''));

		if(service_package==""){
			bootbox.alert("Please choose the package.");
		}else if(discount_percent==0){
			bootbox.alert("Please fill the discount percent.");
		}else if(discount_percent>100){
			bootbox.alert("Discount Percent is greater than 100(%).");
		}else{
			$("#myTable2").find("tbody")
			.append($('<tr data-id="' + service_package_id + '">')
				.append("<td>" + service_package + "</td>")
				.append("<td style='text-align:right; padding-right: 20px;'>" + discount_percent + "</td>")
				.append("<td style='width: 70px'><button type='button' class='btn btn-danger btn-sm' style='padding: 0px 19px; font-size: 16px;' onclick='$(this).parent().parent().remove();removePackage(this);'>×</button></td>")
			);
			package_arr.push(parseInt(service_package_id));
			getAllServicePackage();
			$("#txtPackageDiscount").val(0);		
		}
	}

	function removePackage(obj){
		var id = $(obj).parent().parent().attr("data-id");
		package_arr.remove(parseInt(id));
		getAllServicePackage();
	}

	function addGift(){
		var gift_id = $("#cboGift option:selected").attr('data-id');
		var gift = $("#cboGift").val();
		var quantity = parseInt($("#txtGiftQuantity").val().replace(/,/g, ''));

		if(gift==""){
			bootbox.alert("Please choose the gift.");
		}else if(quantity==0){
			bootbox.alert("Please fill the quantity.");
		}else{
			$("#myTable3").find("tbody")
			.append($('<tr data-id="' + gift_id + '">')
				.append("<td>" + gift + "</td>")
				.append("<td style='text-align:right; padding-right: 20px;'>" + quantity.toLocaleString() + "</td>")
				.append("<td style='width: 70px'><button type='button' class='btn btn-danger btn-sm' style='padding: 0px 19px;font-size: 16px;' onclick='$(this).parent().parent().remove();removeGift(this);'>×</button></td>")
			);
			gift_arr.push(parseInt(gift_id));
			getAllServiceGift();
			$("#txtGiftQuantity").val(0);		
		}
	}

	function removeGift(obj){
		var id = $(obj).parent().parent().attr("data-id");
		gift_arr.remove(parseInt(id));
		getAllServiceGift();
	}

	function addSparepart(){
		var sparepart_code = $("#txtSparepart").attr("data-code");
		var sparepart_name = $("#txtSparepart").val();
		var discount_percent = parseInt($("#txtSparepartDiscount").val().replace(/,/g, ''));

		if(sparepart_code==""){
			bootbox.alert("Please choose the sparepart.");
		}else if(discount_percent==0){
			bootbox.alert("Please fill the discount percent.");
		}else if(discount_percent>100){
			bootbox.alert("Discount Percent is greater than 100(%).");
		}else{
			if(!checkSparepart(sparepart_code)){
				$("#myTable4").find("tbody")
				.append($('<tr data-code="' + sparepart_code + '">')
					.append("<td>" + sparepart_name + "</td>")
					.append("<td style='text-align:right; padding-right: 20px;'>" + discount_percent + "</td>")
					.append("<td style='width: 70px'><button type='button' class='btn btn-danger btn-sm' style='padding: 0px 19px;font-size: 16px;' onclick='$(this).parent().parent().remove();'>×</button></td>")
				);
				$("#txtSparepart").val("");
				$("#txtSparepart").attr("data-code", "");
				$("#txtSparepartDiscount").val(0);
			}else{
				bootbox.alert("Sparepart already exist!");
			}			
		}
	}

	function checkSparepart(code){
		var tf = false;
		$("#myTable4 tbody tr").each(function(){
			if($(this).attr("data-code")==code){
				tf = true;
				return false;
			}
		});
		return tf;
	}

	function createUpdate(){
		var package_lists = [];
		var gift_lists = [];
		var sparepart_lists = [];
		$("#myTable2 tbody tr").each(function (){
			var package_list = {
				"service_package_id" : $(this).attr("data-id"),
				"discount_percent" : parseInt($(this).find("td").eq(1).text().replace(/,/g, ''))
			};
			package_lists.push(package_list);
		});

		$("#myTable3 tbody tr").each(function (){
			var gift_list = {
				"service_gift_id" : $(this).attr("data-id"),
				"quantity" : parseInt($(this).find("td").eq(1).text().replace(/,/g, ''))
			};
			gift_lists.push(gift_list);
		});

		$("#myTable4 tbody tr").each(function (){
			var sparepart_list = {
				"sparepart_code" : $(this).attr("data-code"),
				"discount_percent" : parseInt($(this).find("td").eq(1).text().replace(/,/g, ''))
			};
			sparepart_lists.push(sparepart_list);
		});

		var promotion = {
			"id" : id,
			"promotion_name" : $("#txtPromotionName").val(),
			"start_date" : $("#txtDatePicker1").val(),
			"end_date" : $("#txtDatePicker2").val(),
			"package_lists" : package_lists,
			"gift_lists" : gift_lists,
			"sparepart_lists" : sparepart_lists
		}

		if($("#txtPromotionName").val()==""){
			bootbox.alert("Please fill the promotion name.");
		}else if(package_lists.length==0 && gift_lists.length==0 && sparepart_lists.length==0){
			bootbox.alert("Please fill the promotion package (or) gift (or) sparepart.");
		}else{
			$("#loading").css("display", "block");
			$.ajax({
				url: APP_URL + "api/service/service_promotion/create_update.php",
				type: "POST",
				data: JSON.stringify(promotion)
			}).done(function(data) {
				$("#loading").css("display", "none");
				if(data.message=="created"){
					package_arr = [];
					gift_arr = [];
					$("#txtPromotionName").val("");
					$("#myTable2 tbody tr").remove();
					$("#myTable3 tbody tr").remove();
					$("#myTable4 tbody tr").remove();
					getAllServicePackage();
					getAllServiceGift();
					$("#txtDatePicker1").val(customDate);
					$("#datePicker1").datepicker("setDate", customDate);
					$("#txtDatePicker2").val(customDate);
					$("#datePicker2").datepicker("setDate", customDate);
					bootbox.alert("Successfully created.");
				}else if(data.message=="updated"){
					document.location = APP_URL + "reports/service_promotion.php";
				}else if(data.message=="duplicate"){
					bootbox.alert("Not allow duplicate promotion name.");
				}else if(data.message=="session expire"){
					bootbox.alert("Session Expire! Please refresh the browser and login again.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}

	function getOneRow(){
		$.ajax({
			url: APP_URL + "api/service/service_promotion/get_one_row.php",
			type: "POST",
			data: JSON.stringify({ id: id })
		}).done(function(data){
			$("#txtPromotionName").attr("disabled", true);
			$("#txtPromotionName").val(data.promotion_name);
			$("#txtDatePicker1").val(data.start_date);
			$("#datePicker1").datepicker("setDate", data.start_date);
			$("#txtDatePicker2").val(data.end_date);
			$("#datePicker2").datepicker("setDate", data.end_date);

			$.each(data.service_promotion_packages, function(i, v) {
				$("#myTable2").find("tbody")
				.append($('<tr data-id="' + v.service_package_id + '">')
					.append("<td>" + v.package_name + "</td>")
					.append("<td style='text-align:right; padding-right: 20px;'>" + v.discount_percent + "</td>")
					.append("<td style='width: 70px'><button type='button' class='btn btn-danger btn-sm' style='padding: 0px 19px;font-size: 16px;' onclick='$(this).parent().parent().remove();removePackage(this);'>×</button></td>")
				);
				package_arr.push(v.service_package_id);
			});
			$.each(data.service_promotion_gifts, function(i, v) {
				$("#myTable3").find("tbody")
				.append($('<tr data-id="' + v.service_gift_id + '">')
					.append("<td>" + v.name + "</td>")
					.append("<td style='text-align:right; padding-right: 20px;'>" + v.quantity.toLocaleString() + "</td>")
					.append("<td style='width: 70px'><button type='button' class='btn btn-danger btn-sm' style='padding: 0px 19px;font-size: 16px;' onclick='$(this).parent().parent().remove();removeGift(this);'>×</button></td>")
				);
				gift_arr.push(v.service_gift_id);
			});
			$.each(data.service_promotion_spareparts, function(i, v) {
				$("#myTable4").find("tbody")
				.append($('<tr data-code="' + v.sparepart_code + '">')
					.append("<td>" + v.name + "</td>")
					.append("<td style='text-align:right; padding-right: 20px;'>" + v.discount_percent + "</td>")
					.append("<td style='width: 70px'><button type='button' class='btn btn-danger btn-sm' style='padding: 0px 19px;font-size: 16px;' onclick='$(this).parent().parent().remove();'>×</button></td>")
				);
			});
			getAllServicePackage();
			getAllServiceGift();
		});
	} 

    function isNumber(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if ( (charCode > 31 && charCode < 48) || charCode > 57) {
            return false;
        }
        return true;
    }

    function btozero(obj){
        if($(obj).val() == "")$(obj).val(0);
    }

    Array.prototype.remove = function(elem) {
		var indexElement = this.findIndex(el => el === elem);
		if (indexElement != -1)
			this.splice(indexElement, 1);
		return this;
	};
</script>	
