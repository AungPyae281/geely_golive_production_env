<?php include '../header.php'; ?>
<?php
    $oc_no = "";
    if(isset($_GET['oc_no'])){
        if(!empty($_GET['oc_no'])){
            $oc_no = $_GET['oc_no'];
        }
    }
?>
<style>
	.form-group {
		margin-bottom: 6px !important;
	}
	.form-control:disabled, .form-control:readonly {
		background-color: #f8f8f9;
	}
	.col-form-label {
		padding-top: 3px !important;
	}
	select {
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Deposit Refund</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<div class="card-body">
							<div class="row">
								<div class="col-md-2"></div>
								<div class="col-md-7">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">OC No.:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtOCNo" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Sales Center:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtSalesCenter" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Sales Date:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtSalesDate" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Customer Name:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtCustomerName" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Customer Phone:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtCustomerPhone" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Deposit:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtDeposit" style="text-align: right;" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">G/L Code:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtGLCode" data-glcode="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Refund Date:</label>
										<div class="col-md-8">  
											<div class="input-group input-append date" id="datePicker" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
												<div class="input-group-prepend">
													<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
														<i class="far fa-calendar-alt"></i>
													</span>
												</div>
												<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15" readonly>
											</div>
										</div>
									</div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Account (From):</label>
                                        <div class="col-md-8">
                                            <select class="form-control" id="cboBankCashAccount"></select>
                                        </div>
                                    </div>
									<div class="form-group row">
										<div class="col-md-9"></div>
										<div class="col-md-3">
											<button type="button" class="btn btn-danger btn-block" onclick="refund();">Refund</button>
										</div>
									</div>
								</div>
								<div class="col-md-3"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
    var oc_no = "<?= $oc_no ?>";
	var d = new Date();
	var mm = (d.getMonth("MM") + 1);
	var dd = d.getDate();
  	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date", customDate);
	$("#txtDatePicker").val(customDate);

	$(function(){
		$('#datePicker').datepicker();
        getAllBankAndCashAccount();
		getSalesDetail();
	});	

	function getAllBankAndCashAccount(){ 
        $("#cboBankCashAccount").find("option").remove();
        $("#cboBankCashAccount").append("<option value=''></option>");

        $.ajax({
            url: APP_URL + "api/finance/bank_account/get_all_bank_and_cash_account.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                $("#cboBankCashAccount").append("<option value = '" + v.gl_code + "'>" + v.gl_code + " (" + v.name + ")</option>");
            });
        });
    }

	function getSalesDetail(){
		$.ajax({
			url: APP_URL + "api/sales/sales/get_sales_detail_dp_refund.php",
			type: "POST",
			data: JSON.stringify({ oc_no: oc_no })
		}).done(function(data) {
			$("#txtOCNo").val(data.oc_no);
			$("#txtSalesCenter").val(data.sales_center);
			$("#txtSalesDate").val(data.date);
			$("#txtCustomerName").val(data.customer_name);
			$("#txtCustomerPhone").val(data.customer_phone);
			$("#txtRRP").val(data.rrp);

			$("#txtGLCode").val(data.gl_code + " (" + data.gl_code_name + ")"); 
			$("#txtGLCode").attr("data-glcode", data.gl_code); 
			$("#txtDeposit").val(data.deposit);
		});
	}

	function refund(){
		var date = $("#txtDatePicker").val();
		var gl_code = $("#txtGLCode").attr("data-glcode");
		var gl_code_bank_or_cash = $("#cboBankCashAccount").val();
		var amount = parseInt($("#txtDeposit").val().replace(/,/g, ''));

		if(gl_code=="" || amount==0){
			bootbox.alert("Please refresh the browser!");
		}else if(gl_code_bank_or_cash==""){
			bootbox.alert("Please choose account.");
		}else{
			$.ajax({
				url: APP_URL + "api/finance/deposit_refund/create.php",
				type: "POST",
				data: JSON.stringify({ date: date, oc_no: oc_no, gl_code: gl_code, gl_code_bank_or_cash: gl_code_bank_or_cash, amount: amount })
			}).done(function(data) {
				if(data.message=="created"){
					document.location = APP_URL + "reports/sales.php";
				}else if(data.message=="session expire"){
					bootbox.alert("Session Expire! Please refresh the browser and login again.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}
</script>
