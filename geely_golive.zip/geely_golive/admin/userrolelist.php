<?php include '../header.php'; ?> 
<div class="content-wrapper">
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<h1>User Role</h1>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="card card-outline card-primary">
				<div class="card-body">
					<button type="button" class="btn btn-success btn-md" onclick='addNewRole()'>Create User Role</button>
				</div>
			</div>
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">User Role List</h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
						<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
					</div>
				</div>
				<div class="card-body p-0">
					<table class="table table-striped table-bordered" id="myTable">
						<thead>                  
							<tr>
								<th style="width: 4%;">#</th>
								<th>Dashboard</th>
								<th>Role Name</th>
								<th style="width: 6%;">Edit</th>
								<th style="width: 6%;">Delete</th>
							</tr>
						</thead>
						<tbody></tbody>
					</table>
				</div>
			</div>
		</div>
	</section>
</div>

<?php include '../footer.php'; ?>
<script>
	$(function() { 
		getAll();
	});

	function getAll(){
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/userrole/get_roles.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				var dashb = "";
		    	if(v.dashboard=="hr"){
		    		dashb = "HR";
		    	}else{
		    		var arrD = v.dashboard.split("_");
		    		for (var x = 0; x < arrD.length; x++) {
		    			dashb += ((dashb!="")?" ":"") + arrD[x].charAt(0).toUpperCase() + arrD[x].slice(1);
		    		}
		    	}

				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + dashb + "</td>")
					.append("<td>" + v.role_name + "</td>")
					.append("<td><button type='button' class='btn btn-block btn-success btn-sm fas fa-edit' onclick='editUserRole(this)' style='padding: 0px 13px;font-size: 20px; min-width: 37px'></button></td>")
					.append("<td>" + ((v.is_delete)?"<button type='button' class='btn btn-block btn-danger btn-sm' onclick='deleteUserRole(this)' style='padding: 0px 13px;font-size: 20px; min-width: 35px'><i class='fa fa-solid fa-trash'></i></button>":"") + "</td>")
					)
			});
		});
	}

	function deleteUserRole(obj){
		bootbox.confirm({
			message: "<h4>Are you sure that you want to delete?</h4>",
			buttons: {
				confirm: {
					label: '<span class="glyphicon glyphicon-ok"></span> Yes',
					className: 'btn-danger'
				},
				cancel: {
					label: '<span class="glyphicon glyphicon-remove"></span> No',
					className: 'btn-primary'
				}
			},
			callback: function (result) {
				if(result){
					$.ajax({
						type: "POST",
						url: APP_URL + "api/userrole/delete_role.php",
						data: JSON.stringify({ role_name: $(obj).closest("tr").find("td").eq(2).text() }),
						success: function(data){
							if(data.message == "deleted"){
								$(obj).parent().parent().remove();
								getAll();
							}else{
								bootbox.alert("Error on server side.");
							}
						}
					});
				}
			}
		});
	}

	function editUserRole(obj){
		window.location.href = APP_URL + "admin/userrole.php?act=edit&dashboard=" + $(obj).closest("tr").find("td").eq(1).text() + "&name=" + $(obj).closest("tr").find("td").eq(2).text();
	}

	function addNewRole(){
		window.location.href = APP_URL + "admin/userrole.php";
	}

</script>	
