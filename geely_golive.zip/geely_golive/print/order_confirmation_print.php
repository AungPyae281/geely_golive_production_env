<!DOCTYPE html>
<?php include '../config/_globle.php'; ?>
<html>
<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" type="image/x-icon" href="<?=$app_url;?>img/logo_sm.png" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Geely</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="stylesheet" href="../plugins/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
	<link rel="stylesheet" href="../plugins/icheck-bootstrap/icheck-bootstrap.min.css">	
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
	<style type="text/css">
	@media print and (color)
	{
		table { page-break-inside:auto }
		tr    { page-break-inside:avoid; page-break-after:auto }
		thead { display:table-header-group;}
		tfoot { display:table-footer-group }
	}
	@page {
        size: auto;
        margin: 0;
    }
    html, body {
        width: 183mm !important;
        height: 127mm !important;
        margin-left: 25px;
        margin-top: 5px;;
    }
    
	body{
		width: 100%;
        height: 100%;
		font-size: 12px;
		font-family: 'Century Gothic';
		font-weight: normal;
	}
	.page-header {
	    border-bottom: 1px solid #eee0 !important;
	}
	.table, .table-bordered th, .table-bordered td, th, td{
		border-color: #000 !important;
	}

	th, td{
		line-height: 1.5 !important;
	}
	table{
		border: 1px solid #eee !important;
		border-collapse: collapse;
	}
</style>
</head>
<?php
$oc_no = "";
if(isset($_GET['oc_no'])){
	if(!empty($_GET['oc_no'])){
		$oc_no = $_GET['oc_no'];
	}
}
?>
<body>
	<div class="wrapper">
		<section>
			<div class="col-xs-12" style="padding-left:0px; padding-right: 0px;padding-top: 20px;padding-bottom: 9px;">
				<center>
					<h2 class="page-header" style="margin:0px;">
						<!-- <i class="fa fa-globe"></i>Xtrame Co.LTD -->
						<img src="<?=$app_url;?>img/login.png" style="width:160px;height:auto;">
						<div style="margin-bottom:12px; font-size:22px; font-weight: bold;"><span style="color: #0070b7; font-weight: bold;">Premier Automotive Ltd.</span></div>
						<div style="margin-top:4px; font-size:12px; line-height:18px; font-weight: bold;">Yangon Office: No.3, 12 Ward, Insein Road, Hlaing Township, Yangon  </div>
						<div style="margin-top:4px; font-size:12px; line-height:18px; font-weight: bold;">Mandalay Office: No.40,41,42,43,73 Street, Between 27th and 28th Street, Chan Aye Thar Zan Township, Mandalay</div>
						<div style="margin-top:6px; font-size:18px; font-weight: bold;"><span style="border-bottom: double;">Order Confirmation</span></div>
					</h2>
				</center>
			</div>
			<div class="col-xs-12" style="padding-left:0px; padding-bottom:15px;padding-right: 0px;">
				<div class="col-xs-8" style="padding-left: 0px;">
					<table class="table" id="myTable1" style="margin-bottom:0px;border: 1px solid #000;">
						<thead>
							<tr style="background-color: #7faad3;">
							    <th colspan="2" style="font-size: 15px;text-align: center;">Buyer Information</th>
							</tr>
							<tr>
								<td style="width: 31%;">Attendion To <span style="float:right;">:</span></td>
								<td  id="txtCustomerName"></td>
							</tr>
							<tr>
								<td style="width: 31%;">NRC No. <span style="float:right;">:</span></td>
								<td  id="txtNRCNO"></td>
							</tr>
							<tr style="height: 45px;">
								<td style="width: 31%;">Address <span style="float:right;">:</span></td>
								<td id="txtAddress" style="line-height: 16px !important; padding-top: 4px;"></td>
							</tr>
							<tr>
								<td style="width: 31%;">Email <span style="float:right;">:</span></td>
								<td id="txtEmail"></td>
							</tr>
							<tr>
								<td style="width: 31%;">Contact Number <span style="float:right;">:</span></td>
								<td id="txtContactNumber"></td>
							</tr>
						</thead>
						<tbody id="fbody">
						</tbody>
					</table>
				</div>
				<div class="col-xs-4" style="padding-left: 0px;padding-right: 0px;">
					<table class="table table-bordered" id="myTable2" style="margin-bottom:0px;border: 1px solid #000;">
						<thead>
							<tr>
								<td style="width: 10%;font-weight: bold;">Reference</td>
								<td id="txtReferenceNo"></td>
							</tr>
							<tr>
								<td style="width: 10%;">O.C No.</td>
								<td id="txtOrderConfirmationNo"></td>
							</tr>
							<tr>
								<td style="width: 10%;">Date</td>
								<td id="txtOrderDate"></td>
							</tr>
							<tr>
								<td style="width: 10%;">Updated</td>
								<td id="txtUpdatedDate"></td>
							</tr>
						</thead>
						<tbody id="fbody">
						</tbody>
					</table>
					<table class="table table-bordered" id="myTableSE" style="margin-bottom:0px;border: 1px solid #000;margin-top: 10px;">
						<thead>
							<tr>
								<td style="font-weight: bold;">Sales Executive:</td>	
							</tr>
							<tr>
								<td id="txtSalesExecutive" style="background-color: #ccd8e4;"></td>
							</tr>
						</thead>
						<tbody id="fbody">
						</tbody>
					</table>
				</div>
			</div>
			<div class="col-xs-12" style="padding-left:0px; padding-bottom:15px;padding-right: 0px;">
				<table class="table table-bordered" id="myTable3" style="margin-bottom:0px;">
					<thead>
						<tr style="background-color: #7faad3;">
						    <th style="font-size: 12px;text-align: center;">No.</th>
						    <th style="font-size: 12px;text-align: center;">Product Description</th>
						    <th style="font-size: 12px;padding-left: 0px;padding-right: 0px; text-align: center;">Unit Price (MMK)</th>
						    <th style="font-size: 12px;padding-left: 0px;padding-right: 0px; text-align: center;">No. of Unit</th>
						    <th style="font-size: 12px;padding-left: 0px;padding-right: 0px; text-align: center;">Total Price (MMK)</th>
						</tr>
					</thead>
					<tbody id="tbody">
						<tr>
							<td rowspan="15" style="vertical-align: middle; text-align: center;">1</td>
							<td>
								<div style="width: 40%; display: inline-block;">Brand Name</div>
								<div style="width: 3%; display: inline-block;">:</div>
								<div style="width: 25%; display: inline-block;" id="txtBrandName"></div>
							</td>
							<td rowspan="9" style="vertical-align: middle;text-align: center;" id="txtUnitPrice">0</td>
							<td rowspan="9" style="vertical-align: middle;text-align: center;" id="txtNoOfUnit">1</td>
							<td rowspan="9" style="vertical-align: middle;text-align: right;" id="txtTotalPrice">0</td>
						</tr>
						<tr>
							<td>
								<div style="width: 40%; display: inline-block;">Model Name</div>
								<div style="width: 3%; display: inline-block;">:</div>
								<div style="width: 25%; display: inline-block;" id="txtModelName"></div>
							</td>
						</tr>
						<tr>
							<td>
								<div style="width: 40%; display: inline-block;">VIN No.</div>
								<div style="width: 3%; display: inline-block;">:</div>
								<div style="width: 25%; display: inline-block;" id="txtProductVin"></div>
							</td>
						</tr>
						<tr>
							<td>
								<div style="width: 40%; display: inline-block;">Drive</div>
								<div style="width: 3%; display: inline-block;">:</div>
								<div style="width: 25%; display: inline-block;" id="txtDrive"></div>
							</td>
						</tr>
						<tr>
							<td>
								<div style="width: 40%; display: inline-block;">Grade</div>
								<div style="width: 3%; display: inline-block;">:</div>
								<div style="width: 25%; display: inline-block;" id="txtGrade"></div>
							</td>
						</tr>
						<tr>
							<td>
								<div style="width: 40%; display: inline-block;">Model Year</div>
								<div style="width: 3%; display: inline-block;">:</div>
								<div style="width: 25%; display: inline-block;" id="txtModelYear"></div>
							</td>
						</tr>
						<tr>
							<td>
								<div style="width: 40%; display: inline-block;">Engine Power</div>
								<div style="width: 3%; display: inline-block;">:</div>
								<div style="width: 25%; display: inline-block;" id="txtEnginePower"></div>
							</td>
						</tr>
						<tr>
							<td>
								<div style="width: 40%; display: inline-block;">Body Color</div>
								<div style="width: 3%; display: inline-block;">:</div>
								<div style="width: 25%; display: inline-block;" id="txtBodyColor"></div>
							</td>
						</tr>
						<tr>
							<td>
								<div style="width: 40%; display: inline-block;">Lot No.</div>
								<div style="width: 3%; display: inline-block;">:</div>
								<div style="width: 25%; display: inline-block;" id="txtLotNo"></div>
							</td>
						</tr>
						<tr>
							<td colspan="3" style="text-align: right;font-weight: bold;background-color: #f5eeca;">Commercial Tax </td>
							<td style="text-align: right;" id="txtCommercialTax">0</td>
						</tr>

						<tr style="background-color: #ccd8e4;">
							<td colspan="3" style="text-align: right;font-weight: bold;">Retail Price </td>
							<td style="text-align: right;" id="txtRetailPrice">0</td>
						</tr>
						<tr>
							<td colspan="3" style="text-align: right;font-weight: bold;">Registration Tax & Fees </td>
							<td style="text-align: right;" id="txtRegistrationTaxFees">0</td>
						</tr>
						<tr>
							<td colspan="3" style="text-align: right;font-weight: bold;">Total Price </td>
							<td style="text-align: right;" id="txtTotalPriceC">0</td>
						</tr>
						<tr>
							<td colspan="3" style="text-align: right;font-weight: bold;">Promotion </td>
							<td style="text-align: right;" id="txtPromotion">0</td>
						</tr>
						<tr style="background-color: #7faad3;line-height: 1.42857143;">
							<td colspan="3" style="text-align: right;font-weight: bold;">Selling Price </td>
							<td style="text-align: right;" id="txtSellingPrice">0</td>
						</tr>
						<tr>
							<td colspan="2" style="text-align: right; padding-right: 15px; vertical-align: middle;">
								<div>Payment Method:</div>
							</td>
							<td><input type="checkbox" id="chkCash" value="Cash" onclick="return false;"> Cash</td>
							<td><input type="checkbox" id="chkHP" value="Finance" onclick="return false;"> Finance</td>
						</tr>
						<tr>
							<td></td>
							<td style="text-align: right; padding-right: 15px;">
								<div>1st Deposit Amount:</div>
							</td>
							<td style="background-color: #ccd8e4;text-align: right;" id="txtpayment1ExchangeRate"></td>
							<td style="text-align: right;" id="txtDepositAmountUSD"></td>
							<td style="background-color: #d6d4d4;text-align: right;" id="txtDepositAmountMMK">0</td>
						</tr>
						<tr>
							<td></td>
							<td style="text-align: right; padding-right: 15px;">
								<div>2nd Payment Amount:</div>
							</td>
							<td style="background-color: #ccd8e4;text-align: right;" id="txtpayment2ExchangeRate"></td>
							<td style="text-align: right;" id="txtSecondPaymentAmountUSD"></td>
							<td style="background-color: #ccd8e4;text-align: right;" id="txtSecondPaymentAmountMMK">0</td>
						</tr>
						<tr>
							<td></td>
							<td style="text-align: right; padding-right: 15px;">
								<div>Final Payment Amount:</div>
							</td>
							<td style="background-color: #ccd8e4;text-align: right;" id="txtpayment2ExchangeRate"></td>
							<td style="text-align: right;" id="txtFinalPaymentAmountUSD"></td>
							<td style="background-color: #d6d4d4;text-align: right;" id="txtFinalPaymentAmountMMK">0</td>
						</tr>
						<tr>
							<td></td>
							<td style="text-align: right; padding-right: 15px;">
								<div>Total Paid:</div>
							</td>
							<td colspan="2" style="text-align: right;" id="txtTotalPaidUSD">-</td>
							<td style="text-align: right;" id="txtTotalPaidMMK">0</td>
						</tr>
						<tr>
							<td></td>
							<td style="text-align: right; padding-right: 15px; font-weight: bold;">
								<div>Balance to Pay:</div>
							</td>
							<td colspan="2" style="text-align: right; background-color: #7faad3; font-weight: bold;">$ <span id="txtBalanceToPayUSD">0</span></td>
							<td style="text-align: right; background-color: #7faad3; font-weight: bold;" id="txtBalance"> <span id="txtBalanceToPayMMK">0</span></td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="col-xs-12" style="padding-left:0px; padding-bottom:80px;padding-right: 0px;">
				<p style="margin-bottom: 5px; font-style: italic; font-weight: bold;">Following cost are buyer's responsibility and is not included in the Vehicle price</p>
				<table class="table table-bordered" id="myTable6" style="margin-bottom:0px;border: 1px solid #000;">
					<thead>
						<tr>
							<td style="text-align: right;">Estimate Income Tax: </td>
							<td id="txtEstimateIncomeTax"></td>
							<td>Mandatory (according per Income Tax policy)</td>
						</tr>
						<tr>
							<td style="text-align: right;">Insurance: </td>
							<td> 1% on total vehicle price</td>
							<td>If needed</td>
						</tr>
					</thead>
					<tbody id="fbody">
					</tbody>
				</table>
			</div>
			<div class="col-xs-12" style="padding-left:0px; padding-bottom:10px;padding-right: 0px;padding-top: 40px;">
				<div class="col-xs-8" style="padding-left: 0px;">
					<table class="table" id="myTableRTAD" style="margin-bottom:0px;border: 1px solid #000;">
						<thead>
							<tr style="background-color: #7faad3;">
							    <th colspan="2" style="font-size: 15px;text-align: center;">RTAD Register Information</th>
							</tr>
							<tr>
								<td><span>Sames as buyer</span> &nbsp;&nbsp;<input type="checkbox" id="chkSameAsBuyer" value="same_as_buyer" style="margin-top: 0px;" onclick="return false;"></td>
								<td></td>
							</tr>
							<tr>
								<td style="width: 31%;">Name <span style="float: right;">:</span></td>
								<td id="txtRTADName" style="padding-right: 100px;"></td>
							</tr>
							<tr>
								<td style="width: 31%;">NRC No. <span style="float: right;">:</span></td>
								<td  id="txtRTADNRCNo" style="padding-right: 100px;"></td>
							</tr>
							<tr>
								<td style="width: 31%;">Contract No. <span style="float: right;">:</span></td>
								<td id="txtRTADContactNo" style="padding-right: 100px;"></td>
							</tr>
							<tr>
								<td style="width: 31%;">Address <span style="float: right;">:</span></td>
								<td id="txtRTADAddress" style="padding-right: 100px;"></td>
							</tr>
						</thead>
						<tbody id="fbody">
						</tbody>
					</table>
				</div>
				<div class="col-xs-4" style="padding-left: 0px;padding-right: 0px;">
					<table class="table table-bordered" id="myTable4" style="margin-bottom:0px;border: 1px solid #000;">
						<thead>
							<tr>
								<td style="width: 10%;">Reference</td>
								<td id="txtReference"></td>
							</tr>
							<tr>
								<td style="width: 10%;">VIN No.</td>
								<td id="txtVinNo"></td>
							</tr>
						</thead>
						<tbody id="fbody">
						</tbody>
					</table>
				</div>
			</div>
			<div class="col-xs-12" style="padding-left:0px; padding-bottom:10px;padding-right: 0px;">
				<table class="table table-bordered" id="myTable5" style="margin-bottom:0px;">
					<thead>
						<tr>
						    <th colspan="2" style="font-size: 14px;text-align: center;line-height: 1.42857143 !important;background-color: #7faad3;">Terms and Condition of Vehicle Order</th>
						</tr>
						<tr style="font-size: 12px;">
							<td style="width: 16%;line-height: 1.42857143 !important;">Sales Term</td>
							<td style="line-height: 1.42857143 !important;">
								<p><span style="width: 2%; float: left;">:</span> <span style="width: 98%; display: inline-block;">Prices are included Custom Duty, Commercial Tax and RTAD tax.</span></p>
								<p><span style="width: 2%; float: left;">:</span> <span style="width: 98%; display: inline-block;">Income Tax and Commercial Insurance is the Buyer's responsibility and is not included in the vehicle price.</span></p>
								<p><span style="width: 2%; float: left;">:</span> <span style="width: 98%; display: inline-block;"> If the buyer required Yangon license and needed PAL' service, the cost (which should use latest of market price) will be add in vehicle price as an additionally. Or if buyer will handle by him/herself, the Yangon license should provide to PAL within a reasonable time to proceed RTA register in time.</span></p>
								<p><span style="width: 2%; float: left;">:</span> <span style="width: 98%; display: inline-block;">Vehicle Registration will be processed on behalf of the Buyer by Premier Automotive Ltd as the Buyer's request.</span></p>
							</td>
						</tr>
						<tr style="font-size: 12px;">
							<td style="width: 16%;line-height: 1.42857143 !important;">Payment Term </td>
							<td style="line-height: 1.42857143 !important;">
								<p><span style="width: 2%; float: left;">:</span> <span style="width: 98%; display: inline-block;"> 50% upon sales contract, 50% before RTA registration</p>
								<p><span style="width: 2%; float: left;">:</span> <span style="width: 98%; display: inline-block;">All prices are based on a USD value that will be converted to MMK at the exchange rate on date/s of the signing this order or payment and the invoices will be in MMK.</span></p>
								<p><span style="width: 2%; float: left;">:</span> <span style="width: 98%; display: inline-block;"> Customers using Hire Purchase agreements and any other forms of Bank Financing where the bank pays Premier Automotive the vehicle price, are required to pay PAL prior to delivery, the difference between the payment from the finance company at the exchange rate applied in the financing agreement and the Vehicle Price calculated using the PAL' Exchange Rate on the date of delivery.In the event of an exchange rate reduction, PAL will refund the Buyer the difference between the exchange rates.</span></p>
							</td>
						</tr>
						<tr style="font-size: 12px;">
							<td style="width: 16%;line-height: 1.42857143 !important;">Delivery</td>
							<td style="line-height: 1.42857143 !important;">
								<p><span style="width: 2%; float: left;">:</span> <span style="width: 98%; display: inline-block;"> Vehicle delivery to the Buyer will only take place after full payment for the vehicle is received in Premier Automotive' bank account.</span></p>
							</td>
						</tr>
						<tr style="font-size: 12px;">
							<td style="width: 16%;line-height: 1.42857143 !important;">Warranty</td>
							<td style="line-height: 1.42857143 !important;">
								<p><span style="width: 2%; float: left;">:</span> <span style="width: 98%; display: inline-block;"> 5 years (or) 150,000 km after delivery date whichever comes first depend on Manufacture’s standard warranty terms & conditions.</span></p>
							</td>
						</tr>
						<tr style="font-size: 12px;">
							<td style="width: 16%;line-height: 1.42857143 !important;">Cancellation</td>
							<td style="line-height: 1.42857143 !important;">
								<p><span style="width: 2%; float: left;">:</span> <span style="width: 98%; display: inline-block;"> If Premier Automotive didn't received full payment in within 30 days of signing this Vehicle Order, the order will be cancel automotivelly.</span></p>
								<p><span style="width: 2%; float: left;">:</span> <span style="width: 98%; display: inline-block;"> If the buyer cancels the motor vehicle sales agreement on any cause, it is known and accepted, the seller shall not return the advance deposit as compensation.</span></p>
							</td>
						</tr>
						<tr style="font-size: 12px;">
							<td style="width: 16%;line-height: 1.42857143 !important;">Remark</td>
							<td style="line-height: 1.42857143 !important;">
								<p><span style="width: 2%; float: left;">:</span> <span style="width: 98%; display: inline-block;">Premier Automotive Ltd reserves the unconditional right to revise this Vehicle Order, and the Buyer unconditionally agrees, that any future increases in tax rates on Customs Duty, Commercial Tax, Special Goods Tax, Registration fees, and/or any new or additional taxes,processing fees or other charges imposed by Government Regulation on the importation and trading in motor vehicles, will be borne solely by the Buyer. In the case that the tax amount of a vehicle reduces, Premier Automotive Ltd will refund the reduction in amount to the Buyer.</span></p>
							</td>
						</tr>
					</thead>
					<!-- <tbody id="fbody">
					</tbody> -->
				</table>
			</div>
			<div class="col-xs-12" style="padding-left:0;padding-right:0;line-height:18px;">
				<div class="col-xs-4">	
					<div class="row">
						<div class="col-xs-10" style="text-align: center;">
							<img id="img1ApproverSignature" src="<?=$app_url;?>img/transparent.png" style="height:140px; cursor:pointer;">
						</div>
					</div>
					<div class="row" style="padding-left: 25px;">
						<div class="col-xs-8" style="text-align:center;border-top:1px solid black;padding-left: 0px;padding-right: 0px;" id="txt1Approver"></div>
					</div>
				</div>
				<div class="col-xs-4">	
					<div class="row">
						<div class="col-xs-10" style="text-align: center;">
							<img id="img2ApproverSignature" src="<?=$app_url;?>img/transparent.png" style="height:140px; cursor:pointer;">
						</div>
					</div>
					<div class="row" style="padding-left: 25px;">
						<div class="col-xs-8" style="text-align:center;border-top:1px solid black;padding-left: 0px;padding-right: 0px;" id="txt2Approver"></div>
					</div>
				</div>
				<div class="col-xs-4" style="padding-right: 0px;">
					<div class="row">
						<div class="col-xs-10" style="text-align: center;">
							<img id="imgCustomerSignature" src="<?=$app_url;?>img/transparent.png" style="height:140px; cursor:pointer;">
						</div>
					</div>
					<div class="row" style="padding-left: 25px;">
						<div class="col-xs-8" style="text-align:center;border-top:1px solid black;padding-left: 0px;padding-right: 0px;">(Customer Acceptance) </div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<div style="page-break-before: always;"></div>
</body>
<script src="../plugins/jquery/jquery.min.js"></script>
</html>	 
<script>
	var APP_URL = '<?=$app_url;?>';
	var oc_no = "<?=$oc_no;?>";

	$(function(){ 
		if(oc_no){
			getOnePrint();
		}
	});

	function getOnePrint(){
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/sales/order/get_one_order_confirm.php?d=" + Math.random(),
			type: "POST",
			data: JSON.stringify({ oc_no: oc_no })
		}).done(function(data) {	
			$("#txtCustomerName").text(data.customer_name);
			$("#txtNRCNO").text(data.nrc_no);
			$("#txtAddress").text(data.address);
			$("#txtEmail").text(data.email);
			$("#txtContactNumber").text(data.mobile_no);

			$("#txtOrderConfirmationNo").text(data.oc_no);	
			$("#txtOrderDate").text(data.date); 
			$("#txtSalesExecutive").text(data.staff_name);

			$("#txtBrandName").text(data.brand);
			$("#txtModelName").text(data.model_name);
			$("#txtProductVin").text(data.vin_no); 
			$("#txtGrade").text(data.grade);
			$("#txtModelYear").text(data.model_year);
			$("#txtEnginePower").text(data.engine_no);
			$("#txtBodyColor").text(data.exterior_color);

			$("#txtUnitPrice").text(data.vehicle_price);
			$("#txtTotalPrice").text(data.vehicle_price);
			$("#txtCommercialTax ").text(data.commercial_tax);
			$("#txtRetailPrice").text(data.retail_price);

			$("#txtRegistrationTaxFees").text(data.rtad_tax);
			$("#txtTotalPriceC").text(data.total_price_c);
			$("#txtPromotion").text(data.promotion_discount);
			$("#txtSellingPrice").text(data.selling_price);

			if(data.payment_type=="Cash"){
				$("#chkCash").prop("checked", true);
				$("#chkHP").prop("checked", false);
			}else{
				$("#chkCash").prop("checked", false);
				$("#chkHP").prop("checked", true);
			}

			if(data.same_as_buyer==1){
				$("#chkSameAsBuyer").prop("checked", true);
			}else{
				$("#chkSameAsBuyer").prop("checked", false);
			}

			$("#txtRTADName").text(data.rtad_name);
			$("#txtRTADNRCNo").text(data.rtad_nrc_no);
			$("#txtRTADContactNo").text(data.rtad_mobile_no);
			$("#txtRTADAddress").text(data.rtad_township);

			$("#txtReference").text(data.oc_no);
			$("#txtVinNo").text(data.vin_no);  

			if(data.approvers.length>0){
				$.each(data.approvers, function(i, v) {
					$("#txt" + v.order + "Approver").text("(" + v.position + ")");
					if(v.signature) $("#img" + v.order + "ApproverSignature").attr("src", v.signature + "?d=" + Math.random()); 
				});
			}

			if(data.cust_sig && ImageExist(data.cust_sig)) $("#imgCustomerSignature").attr('src', data.cust_sig + "?d=" + Math.random()); 

			window.print();
		});
	} 

	function ImageExist(url){
		var img = new Image();
		img.src = url;
		return img.height != 0;
	}
</script>
