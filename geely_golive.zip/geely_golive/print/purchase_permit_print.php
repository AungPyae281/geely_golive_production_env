<!DOCTYPE html>
<?php include '../config/_globle.php'; ?>
<html>
<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" type="image/x-icon" href="<?=$app_url;?>img/logo_sm.png" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Geely</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="stylesheet" href="../plugins/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
	<link rel="stylesheet" href="../plugins/icheck-bootstrap/icheck-bootstrap.min.css">	
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
	<style type="text/css">
	@media print and (color)
	{
		table { page-break-inside:auto }
		tr    { page-break-inside:avoid; page-break-after:auto }
		thead { display:table-header-group;}
		tfoot { display:table-footer-group }
	}
	@page {
        size: auto;
        margin: 0;
    }
    html, body {
        width: 220mm !important;
		height: 127mm !important;
		margin-left: 46px;
		margin-top: 24px;
    }
    
	body{
		width: 100%;
        height: 100%;
		font-size: 11px;
		font-family: 'Century Gothic';
		font-weight: normal;
	}
	.page-header {
	    border-bottom: 1px solid #eee0 !important;
	}
</style>
</head>
<?php
$oc_no = "";
if(isset($_GET['oc_no'])){
	if(!empty($_GET['oc_no'])){
		$oc_no = $_GET['oc_no'];
	}
}
?>
<body>
	<div class="wrapper">
		<section>
			<div class="col-xs-12" style="padding-left:0;">
				<div class="col-xs-4">
					<div class="row">
						သို့ 
					</div>
					<div class="row">
						<div class="col-xs-2"> </div>
						<div class="col-xs-7">ညွှန်ကြားရေးမှူးချုပ် ကာကွယ်ရေးဦးစီးဌာန နေပြည်တော်။ </div>
					</div>
				</div>
			</div>
			<div class="col-xs-12" style="padding-left:0;">
				<div class="col-xs-6"></div>
				<div class="col-xs-4">
					<div class="row">
						<div class="col-xs-4" style="padding-left:0;">ရက်စွဲ။&emsp; &emsp; ။</div>
						<div class="col-xs-4" id="txtDate" style="padding-left: 0px;">2022-09-19</div>
					</div>
				</div>
				<div class="col-xs-2"></div>
			</div>
			<div class="col-xs-12" style="padding-left:0;padding-top: 6px;font-weight: bold;">
					အကြောင်းအရာ။&emsp; &emsp; ။ မော်တော်ယာဉ်အရောင်းပြခန်းမှ <span id="txtMY"></span> Model Year နှင့်အထက် မော်တော်ယာဉ် (၁) စီး  ဝယ်ယူခွင့်ပြုပါရန် လျှောက်ထားခြင်း။
			</div>
			<div class="col-xs-12" style="padding-left:0;padding-top: 6px;">
				 &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;အထက်အကြောင်းအရာပါကိစ္စနှင့် ပတ်သက်၍ အောက်ဖော်ပြပါ အချက်အလက်များဖြင့် ပြည်တွင်းရှိ မော်တော်ယာဉ် အရောင်းပြခန်းမှ မော်တော်ယာဉ်(၁)စီးဝယ်ယူခွင့်ပြုပါရန် လျှောက်ထားအပ်ပါသည်။
			</div>
			<div class="col-xs-12" style="padding-left:0;padding-top: 6px;font-weight: bold;">
					( က ) ကိုယ်ရေးအချက်အလက်များ
			</div>
			<div class="col-xs-12" style="padding-left:0;padding-top: 6px;">
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၁ ) အမည် </div>
					<div class="col-xs-7" id="txtName">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၂ ) မှတ်ပုံတင်အမှတ် </div>
					<div class="col-xs-7" id="txtNRC">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၃ ) အရောင်းစင်တာအမည် </div>
					<div class="col-xs-7" id="txtSalesCenter">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၄ ) ဘဏ်အမည် </div>
					<div class="col-xs-7" id="txtBank">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၅ ) A/C NO. </div>
					<div class="col-xs-7" id="txtBankAccount">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၆ ) နိုင်ငံခြားငွေလက်ကျန်/ရက်စွဲ </div>
					<div class="col-xs-7" id="txtUSDRemain">-</div>
				</div>
			</div>
			<div class="col-xs-12" style="padding-left:0;padding-top: 6px;font-weight: bold;">
					( ခ ) မော်တော်ယာဉ် အချက်အလက်များ
			</div>
			<div class="col-xs-12" style="padding-left:0;padding-top: 6px;">
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၁ ) VEHICLE TYPE </div>
					<div class="col-xs-7" id="txtVehicleType">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၂ ) BRAND </div>
					<div class="col-xs-7" id="txtBrand">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၃ ) MODEL YEAR </div>
					<div class="col-xs-7" id="txtModelYear">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၄ ) ENGINE POWER </div>
					<div class="col-xs-7" id="txtEnginePower">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၅ ) VALUE </div>
					<div class="col-xs-7" id="txtValue">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၆ ) COUNTRY OF ORIGIN </div>
					<div class="col-xs-7" id="txtCountryofOrigin">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၇ )  COMMISSION % </div>
					<div class="col-xs-7" id="txtCommission">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-1"></div>
					<div class="col-xs-3" style="padding-left:0; padding-right:0;">( ၈ ) ACCORDING TO </div>
					<div class="col-xs-7" id="txtAccordingTo">-</div>
				</div>
			</div>
			<div class="col-xs-12" style="padding-left:0;padding-top: 6px;font-weight: bold;">
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-6"></div>
					<div class="col-xs-1">SIGN </div>
					<div class="col-xs-4" id="txtSign">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-6"></div>
					<div class="col-xs-1">NAME </div>
					<div class="col-xs-4" id="txtSignName">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-6"></div>
					<div class="col-xs-1">N.R.C NO. </div>
					<div class="col-xs-4" id="txtSignNRC">-</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="col-xs-6"></div>
					<div class="col-xs-1">ADDRESS </div>
					<div class="col-xs-4" id="txtSignAddress">-</div>
				</div>
			</div>
		</section>
	</div>
	<div style="page-break-before: always;"></div>
</body>
<script src="../plugins/jquery/jquery.min.js"></script>
</html>	

<script>
	var APP_URL = '<?=$app_url;?>';
	var oc_no = '<?= $oc_no ?>';
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);

	$(function(){
		$("#txtDate").text(customDate); 
		if(oc_no!=""){
			getOnePrint();
		}
	});

	function getOnePrint(){
		$.ajax({
			url: APP_URL + "api/sales/purchase_permit/get_one_row.php",
			type: "POST",
			data: JSON.stringify({ oc_no: oc_no })
		}).done(function(data) {
			
			if(data.name) $("#txtName").text(data.name);
			if(data.nrc) $("#txtNRC").text(data.nrc);
			if(data.sales_center) $("#txtSalesCenter").text(data.sales_center);
			if(data.bank) $("#txtBank").text(data.bank);
			if(data.ac_no) $("#txtBankAccount").text(data.ac_no);
			if(data.foreign_currency_balance && data.balance_date) $("#txtUSDRemain").text(data.foreign_currency_balance + "/" + data.balance_date);

			if(data.vehicle_type) $("#txtVehicleType").text(data.vehicle_type);
			if(data.brand) $("#txtBrand").text(data.brand);
			if(data.model_year) $("#txtMY").text(data.model_year); $("#txtModelYear").text(data.model_year);
			if(data.engine_power) $("#txtEnginePower").text(data.engine_power);
			if(data.value) $("#txtValue").text(data.value);
			if(data.country_of_origin) $("#txtCountryofOrigin").text(data.country_of_origin);
			if(data.commission) $("#txtCommission").text(data.commission);
			if(data.according_to) $("#txtAccordingTo").text(data.according_to);

			if(data.other_name) $("#txtSignName").text(data.other_name);
			if(data.other_nrc) $("#txtSignNRC").text(data.other_nrc);
			if(data.other_address) $("#txtSignAddress").text(data.other_address);
			window.print();
	
		});
	}

</script>
