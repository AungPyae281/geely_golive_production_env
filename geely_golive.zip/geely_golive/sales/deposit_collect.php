<?php include '../header.php'; ?>
<?php
    $oc_no = "";
    if(isset($_GET['oc_no'])){
        if(!empty($_GET['oc_no'])){
            $oc_no = $_GET['oc_no'];
        }
    }
?>
<style>
    .card{
        margin-bottom: 10px !important;
    }
    .card-header{
        padding: 8px 2px 8px 15px;
    }
    .card-body{
        padding: 15px 20px 5px 20px;
    }
    .nav-tabs{
        display: inline-flex;
    }
    .form-group{
        margin-bottom: 5px !important;
    }
    .form-control{
        border: 1px solid #d4d6d8ba !important;
    }
    .form-control:disabled, .form-control[readonly]{
        background-color: #e6e8ea9e !important;
    }
    input, textarea{
        font-size: 14px !important;
    }
    select{
        padding-top: 1px !important;
    }
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
    <section class="content-header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                </div>
            </div>
        </div>
    </section>
    <section class="content"> 
    	<div class="container-fluid">
    		<div class="row">
                <div class="col-md-12" id="SummaryPanel">
                    <div class="card card-outline card-primary">
                        <div class="card-header">
                            <h3 class="card-title" id="txtProcessing"></h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">OC No.:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" id="txtOCNo" disabled value="<?=$oc_no?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Sales Center:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" id="txtSalesCenter" disabled>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card card-outline card-outline-tabs collapsed-card">
                        <div class="card-header p-0 border-bottom-0">
                            <ul class="nav nav-tabs" id="custom-tabs-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="custom-tabs-customer-tab" data-toggle="pill" href="#custom-tabs-customer" role="tab" aria-controls="custom-tabs-customer" aria-selected="true">Customer Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-vehicle-tab" data-toggle="pill" href="#custom-tabs-vehicle" role="tab" aria-controls="custom-tabs-vehicle" aria-selected="false">Vehicle Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-payment-tab" data-toggle="pill" href="#custom-tabs-payment" role="tab" aria-controls="custom-tabs-payment" aria-selected="false">Payment Info</a>
                                </li>
                            </ul>
                            <div class="card-tools" style="padding-top: 10px;">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="tab-content" id="custom-tabs-tabContent">
                                <div class="tab-pane fade active show" id="custom-tabs-customer" role="tabpanel" aria-labelledby="custom-tabs-customer-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerName" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">NRC No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerNRCNo" disabled>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Mobile No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerMobileNo" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Township:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerTownship" disabled>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="custom-tabs-vehicle" role="tabpanel" aria-labelledby="custom-tabs-vehicle-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Vin No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtVinNo" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Engine No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtEngineNo" disabled>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Particular:</label>
                                                <div class="col-md-8">
                                                    <textarea class="form-control" id="txtParticular" rows="4" style="height: 100px;" disabled></textarea>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="custom-tabs-payment" role="tabpanel" aria-labelledby="custom-tabs-payment-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Total Payment:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtTotalPayment" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Total Payment (%):</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtTotalPaymentPercent" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Deposit Amount:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtDeposit" value="0" disabled style="text-align:right;">
                                                    <input type="hidden" id="txtPaymentType">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Remaining Balance:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtRemainingBalance" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12" id="DepositCollect">
                    <div class="card card-outline card-primary">
                        <div class="card-body">
                            <form id="frmDCEntry">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Date:</label>
                                            <div class="col-md-8">  
                                                <div class="input-group input-append date" id="datePickerDC" data-date="2022-09-01" data-date-format="yyyy-mm-dd">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-addon input-group-text" style="width: 40px; display: table-cell; height: 31px !important;">
                                                            <i class="far fa-calendar-alt"></i>
                                                        </span>
                                                    </div>
                                                    <input type="text" class="form-control float-right dc-info" id="txtDatePickerDC" value="1982-06-15" readonly>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right; ">G/L Code:</label>
                                            <div class="col-md-8">
                                                <select class="form-control dc-info" id="cboGLCode"></select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right; ">Account:</label>
                                            <div class="col-md-8">
                                                <select class="form-control dc-info" id="cboBankCashAccount"></select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right; ">Payment Type:</label>
                                            <div class="col-md-8">
                                                <select class="form-control dc-info" id="cboReceiptTypeDC">
                                                    <option value="Cash">Cash</option>
                                                    <option value="AGD">AGD</option>
                                                    <option value="MCB">MCB</option>
                                                    <option value="MAB">MAB</option>
                                                    <option value="YOMA">YOMA</option>
                                                    <option value="AYA">AYA</option>
                                                    <option value="KBZ">KBZ</option>
                                                    <option value="CB">CB</option>
                                                    <option value="Kpay">Kpay</option>
                                                    <option value="AYA Pay">AYA Pay</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Voucher No.:</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control dc-info" id="txtReceiptVoucherDC">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Amount:</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtAmountDC" style="text-align: right;" disabled>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-md-4 control-label"></label>
                                            <div class="col-md-8">
                                                <input style="display:none" name="file-dc" id="input-dc-image-hidden" onchange="document.getElementById('dc-previewing').src = window.URL.createObjectURL(this.files[0])" type="file" accept="image/jpeg, image/png" >
                                                <img id="dc-previewing" name="dc-previewing" src="<?=$app_url;?>img/no_image.jpg" style="height:170px; width:auto;cursor:pointer;border: 2px solid #a2a2a2;" onclick="HandleBrowseClick(this)" title="Click to Change the Photo.">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">
                                            </label>
                                            <div class="col-md-4">
                                                <button type="button" class="btn btn-success btn-block" id="btnDCSubmit">Save</button>
                                            </div>
                                            <label class="col-md-4"></label>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
    	</div>
    </section> 
</div>
<?php include '../footer.php'; ?>
<script>
    var oc_no = "<?= $oc_no ?>";
    var d = new Date();
    var mm = (d.getMonth("MM")+1);
    var dd = d.getDate();
    var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
    $('#datePickerDC').attr("data-date", customDate);
    $("#txtDatePickerDC").val(customDate);

	$(function(){
        $("body").addClass("sidebar-collapse");  
        $('#datePickerDC').datepicker();
        getAllGLCode();
        getAllBankAndCashAccount();
        
        getSalesDetail();
    });

    function getAllGLCode(glc){
        $("#cboGLCode").find("option").remove();
        $("#cboGLCode").append("<option value=''></option>");
        $.ajax({
            url: APP_URL + "api/finance/gl_account/get_all_rows.php",
            type: "POST",
            data: JSON.stringify({ category: 'Customer' })
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                if(v.gl_code==glc){
                    $("#cboGLCode").append("<option value='" + v.gl_code + "' selected>" + v.gl_code + " (" + v.name + ")</option>");
                }else{
                    $("#cboGLCode").append("<option value='" + v.gl_code + "'>" + v.gl_code + " (" + v.name + ")</option>");
                }
            });
        });
    }

    function getAllBankAndCashAccount(glc){ 
        $("#cboBankCashAccount").find("option").remove();
        $("#cboBankCashAccount").append("<option value=''></option>");

        $.ajax({
            url: APP_URL + "api/finance/bank_account/get_all_bank_and_cash_account.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                if(v.gl_code==glc){
                    $("#cboBankCashAccount").append("<option value = '" + v.gl_code + "' selected>" + v.gl_code + " (" + v.name + ")</option>");
                }else{
                    $("#cboBankCashAccount").append("<option value = '" + v.gl_code + "'>" + v.gl_code + " (" + v.name + ")</option>");
                }
            });
        });
    }

    function getSalesDetail(){
        $.ajax({
            url: APP_URL + "api/sales/sales/get_sales_detail.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {    
            $("#txtProcessing").text(data.processing);
            $("#txtSalesCenter").val(data.sales_center);

            $("#txtCustomerName").val(data.c_name);
            $("#txtCustomerNRCNo").val(data.c_nrc_no);
            $("#txtCustomerMobileNo").val(data.c_mobile_no);
            $("#txtCustomerTownship").val(data.c_township);

            $("#txtVinNo").val(data.vin_no);
            $("#txtEngineNo").val(data.engine_no);
            $("#txtParticular").val(data.particular);

            $("#txtTotalPayment").val(data.total_payment);
            $("#txtTotalPaymentPercent").val(data.payment_percent);

            if(data.payment_type=="HP"){
                $("#txtDeposit").val(data.deposit);
            }
            $("#txtRemainingBalance").val(data.remaining_balance);

            $("#txtAmountDC").val(data.deposit);

            $("#txtPaymentType").val(data.payment_type);

            getDepositCollect();
        });
    }  

    // Deposit Collect
    function getDepositCollect(){
        $.ajax({
            type: "POST",
            url: APP_URL + "api/sales/deposit_receipt/get_one_row.php",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {
            $("#txtAmountDC").val(data.deposit);
            $("#txtPaymentDepositAmount").val(data.deposit);
            if(data.r_date){
                $("#txtDatePickerDC").val(data.r_date);
                getAllGLCode(data.gl_code);
                getAllBankAndCashAccount(data.gl_code_bank_or_cash);
                $("#cboReceiptTypeDC").val(data.r_payment_type);
                $("#txtReceiptVoucherDC").val(data.receipt_no);
                if(data.receipt_img){
                    document.getElementById('dc-previewing').src = APP_URL + "api/sales/deposit_receipt/upload/" + oc_no + "/" + data.receipt_img;
                }

                $(".dc-info").attr("disabled", true);
                $("#input-dc-image-hidden").attr("disabled", true);
                $("#btnDCSubmit").css("display", "none");
            }else{
                $(".dc-info").attr("disabled", false);
                $("#input-dc-image-hidden").attr("disabled", false);
                $("#btnDCSubmit").css("display", "");
            }
       });
    }

    $("#btnDCSubmit").click(function(){ 
        $("#frmDCEntry").submit(); 
    });

    $("#frmDCEntry").on('submit',(function(e) {
        e.preventDefault();             
        var formData = new FormData(this);
        var o_payment_type = $("#txtPaymentType").val();
        var date = $("#txtDatePickerDC").val();
        var gl_code = $("#cboGLCode").val();
        var gl_code_bank_or_cash = $("#cboBankCashAccount").val();
        var payment_type = $("#cboReceiptTypeDC").val();
        var receipt_no = $("#txtReceiptVoucherDC").val();
        var pp = "<?=$app_url;?>img/no_image.jpg";
        var dc_pic = $("#dc-previewing").attr("src");

        if(gl_code==""){
            bootbox.alert("Please choose G/L code.");
        }else if(gl_code_bank_or_cash==""){
            bootbox.alert("Please choose account.");
        }else if(receipt_no==""){
            bootbox.alert("Please fill voucher no.!");
        }else if(dc_pic==pp){
            bootbox.alert("Please upload photo."); 
        }else{
            var objArr = [];
            objArr.push({ "oc_no": oc_no, "gl_code": gl_code, "gl_code_bank_or_cash": gl_code_bank_or_cash, "o_payment_type": o_payment_type, "r_date": date, "r_payment_type": payment_type, "receipt_no": receipt_no, "amount": parseInt($("#txtAmountDC").val().replace(/,/g, '')) });
            formData.append('objArr', JSON.stringify( objArr ));

            $("#btnDCSubmit").attr("disabled", true);
            $.ajax({
                url: APP_URL + "api/sales/deposit_receipt/create.php",
                type: "POST",
                processData: false,
                contentType: false,
                data: formData,
                success: function(data){    
                    $("#btnDCSubmit").attr("disabled", false);
                    $("#btnDCSubmit").css("display", "none");
                    if(data.message=="created"){ 
                        document.location = APP_URL + "sales/sales_list.php";
                    }else if(data.message=="session expire"){
                        bootbox.alert("Session Expire! Please refresh the browser and login again.");
                    }else{
                        bootbox.alert("Error on server side.");
                    }
                }
            });
        }
    })); 
    // Deposit Collect

    function HandleBrowseClick(obj){
        var inputID = $(obj).parent().find("input[type='file']").attr("id");
        var file = document.getElementById(inputID);
        file.click();
    }
</script>