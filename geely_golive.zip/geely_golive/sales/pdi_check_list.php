<?php include '../header.php'; ?> 
<?php
	$oc_no = "";
	if(isset($_GET['oc_no'])){
		if(!empty($_GET['oc_no'])){
			$oc_no = $_GET['oc_no'];
		}
	}
	
?> 
<style> 
	table thead tr:nth-child(1){
		background-color: #e5e5e7;
	}

	table thead tr th:nth-child(2){
		width: 3%;
	}

	table thead tr th:nth-child(3){
		width: 3%;
	}

	.car_wrapper {
	  position: relative;
	  width: 400px;
	  height: 300px;
	  -moz-user-select: none;
	  -webkit-user-select: none;
	  -ms-user-select: none;
	  user-select: none;
	} 

	.signature-pad {
	  position: absolute;
	  left: 0;
	  top: 0;
	  width: 400px;
	  height: 300px;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-12">
					<h1>Pre-Delivery Inspection(PDI) checking list</h1>
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<form role="form" id="frmEntry">
				<div class="card-body">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="card card-outline">
								<div class="card-body p-0">
									<table class="table table-bordered" id="myTable1"></table>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-sm-12">
							<div class="card card-outline">
								<div class="card-body p-0">
									<table class="table table-bordered" id="myTable2"></table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var alphabet = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
	var fieldID = [];

	var OCNO = '<?= $oc_no ?>';
	var d = new Date();
  	var n = d.getTime();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);

	$(function() {
		$("body").addClass("sidebar-collapse");
		getAllRows();
	});

	function getAllRows(){
		$("#myTable1").find("tbody").find("tr").remove();
		$("#myTable2").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/sales/lookup_check_list/get_all_rows.php?t=" + n,
			type: "POST",
			data: JSON.stringify({ check_list_name: 'PDI', oc_no: OCNO })
		}).done(function(data) {	
			//chkOK_ (Check Box), chkAdjustRepair_ (Check Box), img_ (Car Sheet), txt_ (Text Box), datePicker_ & txtDatePicker_ (Date) 
			var category_id = "";
			var subcategory_id = "";
			fieldID = [];
			$.each(data.records, function(i, v) {	
				//category
				if(category_id!=v.category_id){
					if(v.category!="Nameless"){
						$("#myTable" + v.group_order).append('<thead id="thead_' + v.category_id + '"><tr><th ' + (($("#myTable" + v.group_order + " thead").length==0)?"":"colspan='3'") + '>' + alphabet[v.category_order_no - 1] + ". " + v.category + '</th>' + (($("#myTable" + v.group_order + " thead").length==0)?'<th>OK</th><th>AR</th>':'') + '</tr></thead><tbody id="tbody_' + v.category_id + '"></tbody>');
					}else{
						$("#myTable" + v.group_order).append('<thead id="thead_' + v.category_id + '"></thead><tbody id="tbody_' + v.category_id + '"></tbody>');
					}
				}
				category_id = v.category_id;
				//category

				//subcategory
				if(subcategory_id!=v.subcategory_id && v.subcategory_id!=0){
					$("#myTable" + v.group_order).find("#tbody_" + v.category_id)
					.append($('<tr style="font-weight:bold;" class="subcategory">')
						.append('<td style="text-align: center;">' + v.subcategory + '</td>')
						.append('<td colspan="2"></td>')
					);
				}
				subcategory_id = v.subcategory_id;
				//subcategory

				//checklist
				if(v.type=="Check Box"){
					$("#myTable" + v.group_order).find("#tbody_" + v.category_id)
					.append($('<tr>')
						.append('<td>' + v.check_list + '</td>')
						.append('<td><div class="icheck-primary d-inline"><input type="checkbox" id="chkOK_' + v.id + '"><label for="chkOK_' + v.id + '"></label></div></td>')
						.append('<td><div class="icheck-success d-inline"><input type="checkbox" id="chkAdjustRepair_' + v.id + '"><label for="chkAdjustRepair_' + v.id + '"></label></div></td>')
					);
					if(v.val!=""){
						var okVal = parseInt(v.val.split("|")[0]);
						var adjustRepairVal = parseInt(v.val.split("|")[1]);
						$("#chkOK_" + v.id).prop("checked", okVal);
						$("#chkAdjustRepair_" + v.id).prop("checked", adjustRepairVal);
					}
				}else if(v.type=="Car Sheet"){
					$("#myTable" + v.group_order).find("#tbody_" + v.category_id)
					.append($('<tr>')
						.append('<td colspan="3" style="padding: 0px !important;"><div class="row" style="padding-bottom: 9px; padding-top: 9px;"><div class="col-md-1"></div><div class="col-md-11"> <div class="car_wrapper" style="margin-left: 74px !important;"><img id="img_' + v.id + '" src="" style="display:none;" /><canvas id="canvas_' + v.id + '" class="signature-pad" width=400 height=300></canvas></div> <div><button type="button" class="btn btn-primary" id="btnSave_' + v.id + '">Save</button> <button type="button" class="btn btn-danger" id="btnClear_' + v.id + '">Clear</button></div> </div></div></td>')
					);
					var finalImg = "";
					if(v.val!=""){
						finalImg = APP_URL + "api/sales/pdi_check_list/" + v.val.split("./")[1];
					}
					signaturePad(v.id, v.check_list, finalImg);
				}else{
					if($("#myTable" + v.group_order + " #tbody_" + v.category_id + " tr").length==0){
						$("#myTable" + v.group_order).find("#tbody_" + v.category_id)
						.append($('<tr>')
							.append('<td colspan="3" style="padding: 0px !important;"><div class="row" style="border-top: 1px solid #3b3b3b;margin-left: 0px;margin-right: 0px;padding-top: 12px;" id="txtContainer_' + v.category_id + '"></div></th>')
						);
					}

					var formControl = "";

					if(v.type=="Text Box"){
						formControl = '<input type="text" class="form-control" id="txt_' + v.id + '">';
					}else if(v.type=="Date"){
						datePicker = 'datePicker_' + v.id;
						formControl = '<div class="input-group input-append date" id="datePicker_' + v.id + '" data-date="2020-02-04" data-date-format="yyyy-mm-dd"><div class="input-group-prepend"><span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;"><i class="far fa-calendar-alt"></i></span></div><input type="text" class="form-control float-right" id="txtDatePicker_' + v.id + '" value="1982-06-15"></div>';
					}

					$("#myTable" + v.group_order).find("#tbody_" + v.category_id).find("#txtContainer_" + v.category_id)
					.append($('<div class="col-md-6">')
						.append($('<div class="form-group row">')
							.append('<label class="col-md-5 col-form-label" style="text-align: right;">' + v.check_list + '</label><div class="col-md-7">' + formControl + '</div>')
						)
					);
					if(v.type=="Text Box"){
						if(v.val!=""){
							$("#txt_" + v.id).val(v.val);
						}
					}else if(v.type=="Date"){
						$("#datePicker_" + v.id).attr("data-date", customDate);
						$("#txtDatePicker_" + v.id).val(customDate);
						$("#datePicker_" + v.id).datepicker();

						if(v.val!=""){
							$("#txtDatePicker_" + v.id).val(v.val);
							$("#datePicker_" + v.id).datepicker("setDate", v.val);
						}
					}
				}
				//checklist

				//Type & ID Push to fieldID
				var fid = {
					"type" : v.type,
					"id" : v.id
				}
				fieldID.push(fid);
				//Type & ID Push to fieldID

				//Note
				if(i == (data.records.length - 1)){
					$("#myTable" + v.group_order).append('<thead id=""></thead><tbody id=""><tr><td colspan="3" style="padding: 0px !important;"><div class="row" style="border-top: 1px solid #3b3b3b;margin-left: 0px;margin-right: 0px;padding-top: 12px;"><div class="col-md-12">Note: <ul><li>The items with "⚫" circular mark shold be done in both distributor and dealer.</li><li>For the distributor mode, the rst items should be done in distributor.</li><li>For the dealer mode, the rest items should be done in dealer.</li></ul></div></div> <div class="col-md-12"><div class="form-group row" style="margin-right: 10px;"><label class="col-md-10 col-form-label" style="text-align: right; padding-top: 6px;" id="PDIDone">Done <div class="icheck-success d-inline" style="padding-left: 3px;"><input type="checkbox" id="chkPDIDone" style="padding-top: 6px;"><label for="chkPDIDone"></label></div></label><label class="col-md-10" id="PDINoDone"></label><button type="button" class="col-md-2 btn btn-block btn-success" onclick="validateAndSave()" id="btnSubmit">Save</button> </div></div></td></tr></tbody>');
					// <div class="col-md-9"></div><div class="col-md-3"><button type="button" class="btn btn-success btn-block" onclick="validateAndSave()">Save</button></div>
				}
				//Note
			});
			if(data.ff_done){
				$("#PDIDone").css("display", "");
				$("#PDINoDone").css("display", "none");
			}else{
				$("#PDIDone").css("display", "none");
				$("#PDINoDone").css("display", "");
			}
			if(data.pdi_done){
				$("#chkPDIDone").prop("checked", true);
				$("#chkPDIDone").prop("disabled", true);
			}
		});
	}

	function signaturePad(id, orgImg, finalImg){
		//SignaturePad
		const canvas = document.getElementById("canvas_" + id);
		const context = canvas.getContext("2d");
		const img = new Image();
		img.src = ((finalImg!="")?finalImg:orgImg);
		img.onload = () => { 
			context.drawImage(img, 0, 0, canvas.width, canvas.height);
		}

		var signaturePad = new SignaturePad(canvas, {
			backgroundColor: 'rgba(255, 255, 255, 0)',
			penColor: 'rgb(227, 0, 0)'
		});

		var saveButton = document.getElementById('btnSave_' + id);
		var clearButton = document.getElementById('btnClear_' + id);

		clearButton.addEventListener('click', function (event) {
			signaturePad.clear();
			$("#img_" + id).attr("src", "");
			img.src = orgImg;
			img.onload = () => { 
				context.drawImage(img, 0, 0, canvas.width, canvas.height);
			}
		});

		saveButton.addEventListener("click", () => {
			if (signaturePad.isEmpty()) {
				bootbox.alert("Please provide a signature first.");
			} else {
				canvas.getContext("2d");
				$("#img_" + id).attr("src", canvas.toDataURL("image/png"));
			}
		}); 
	}

	function validateAndSave(){
		//chkOK_ (Check Box), chkAdjustRepair_ (Check Box), img_ (Car Sheet), txt_ (Text Box), datePicker_ & txtDatePicker_ (Date) 
        var pdi_done = ($("#chkPDIDone").prop("checked"))?1:0;
        var pdi_disabled = ($("#chkPDIDone").prop("disabled"))?1:0;

		var fieldDetail = [];
		var carSheetDetail = [];
		$.each(fieldID, function(i, v) {

			var val = "";
			if(v.type=="Check Box"){
				val = (($("#chkOK_" + v.id).prop("checked"))?1:0) + "|" + (($("#chkAdjustRepair_" + v.id).prop("checked"))?1:0);
			}else if(v.type=="Car Sheet"){
				val = $("#img_" + v.id).attr("src");
			}else if(v.type=="Text Box"){
				val = $("#txt_" + v.id).val();
			}else if(v.type=="Date"){
				val = $("#txtDatePicker_" + v.id).val();
			}

			if(val!=""){
				var detail = {
					"type" : v.type,
					"id" : v.id,
					"col_name" : "cl_" + v.id,
					"val" : val
				}
				fieldDetail.push(detail);

				if(v.type=="Car Sheet"){
					carSheetDetail.push(detail);
				}
			}

		});

		$("#btnSubmit").attr("disabled", true);
		$.ajax({
			url: APP_URL + "api/sales/pdi_check_list/create_update.php",
			type: "POST",
			data: JSON.stringify({ oc_no: OCNO, pdi_done, pdi_done, pdi_disabled: pdi_disabled, field_detail: fieldDetail, car_sheet_detail: carSheetDetail })
		}).done(function(data) {
			$("#btnSubmit").attr("disabled", false);
			if(data.message=="updated"){ 
				document.location = APP_URL + "sales/sales_list.php"; 
			}else if(data.message=="session expire"){
                bootbox.alert("Session Expire! Please refresh the browser and login again.");
            }else{
				bootbox.alert("Error on server side.");
			}
		});
	}
</script>