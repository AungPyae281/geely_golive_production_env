<?php include '../header.php'; ?>
<?php
    $oc_no = "";
    if(isset($_GET['oc_no'])){
        if(!empty($_GET['oc_no'])){
            $oc_no = $_GET['oc_no'];
        }
    }
?>
<style>
    .card{
        margin-bottom: 10px !important;
    }
    .card-header{
        padding: 8px 2px 8px 15px;
    }
    .card-body{
        padding: 15px 20px 5px 20px;
    }
    .nav-tabs{
        display: inline-flex;
    }
    .form-group{
        margin-bottom: 5px !important;
    }
    .form-control{
        border: 1px solid #d4d6d8ba !important;
    }
    .form-control:disabled, .form-control[readonly]{
        background-color: #e6e8ea9e !important;
    }
    input, textarea{
        font-size: 14px !important;
    }
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
    <section class="content-header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                </div>
            </div>
        </div>
    </section>
    <section class="content"> 
    	<div class="container-fluid">
    		<div class="row">
                <div class="col-md-12" id="SummaryPanel">
                    <div class="card card-outline card-primary">
                        <div class="card-header">
                            <h3 class="card-title" id="txtProcessing"></h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">OC No.:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" id="txtOCNo" disabled value="<?=$oc_no?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Sales Center:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" id="txtSalesCenter" disabled>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card card-outline card-outline-tabs collapsed-card">
                        <div class="card-header p-0 border-bottom-0">
                            <ul class="nav nav-tabs" id="custom-tabs-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="custom-tabs-customer-tab" data-toggle="pill" href="#custom-tabs-customer" role="tab" aria-controls="custom-tabs-customer" aria-selected="true">Customer Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-vehicle-tab" data-toggle="pill" href="#custom-tabs-vehicle" role="tab" aria-controls="custom-tabs-vehicle" aria-selected="false">Vehicle Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-payment-tab" data-toggle="pill" href="#custom-tabs-payment" role="tab" aria-controls="custom-tabs-payment" aria-selected="false">Payment Info</a>
                                </li>
                            </ul>
                            <div class="card-tools" style="padding-top: 10px;">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="tab-content" id="custom-tabs-tabContent">
                                <div class="tab-pane fade active show" id="custom-tabs-customer" role="tabpanel" aria-labelledby="custom-tabs-customer-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerName" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">NRC No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerNRCNo" disabled>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Mobile No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerMobileNo" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Township:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerTownship" disabled>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="custom-tabs-vehicle" role="tabpanel" aria-labelledby="custom-tabs-vehicle-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Vin No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtVinNo" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Engine No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtEngineNo" disabled>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Particular:</label>
                                                <div class="col-md-8">
                                                    <textarea class="form-control" id="txtParticular" rows="4" style="height: 100px;" disabled></textarea>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="custom-tabs-payment" role="tabpanel" aria-labelledby="custom-tabs-payment-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Total Payment:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtTotalPayment" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Total Payment (%):</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtTotalPaymentPercent" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Deposit Amount:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtDeposit" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Remaining Balance:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtRemainingBalance" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12" id="ReadyToDeliver">
                    <div class="card card-outline card-primary">
                        <div class="card-body">
                            <h5><span style="font-weight: bold;margin-left:10px;">Accessories items list</span></h5>
                            <legend> </legend>
                            <div class="form-group row" style="margin-bottom: 40px !important;">
                                <label class="col-lg-1 col-form-label"></label>
                                <div class="col-lg-9">
                                    <div class="panel-body" >   
                                        <div class="col-lg-6 icheck-success d-inline">
                                            <input type="checkbox" id="chkRTDAISidestep" class="rtd-info">
                                            <label for="chkRTDAISidestep">
                                                Sidestep
                                            </label>
                                        </div>
                                        <div class="col-lg-6 icheck-success d-inline">
                                            <input type="checkbox" id="chkRTDAIFloorMat" class="rtd-info">
                                            <label for="chkRTDAIFloorMat">
                                                Floor Mat
                                            </label>
                                        </div>
                                        <div class="col-lg-6 icheck-success d-inline">
                                            <input type="checkbox" id="chkRTDAIPowerTailGate" class="rtd-info">
                                            <label for="chkRTDAIPowerTailGate">
                                                Power Tail Gate
                                            </label>
                                        </div>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control rtd-info" id="txtRTDAIOther">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <h5><span style="font-weight: bold;margin-left:10px;">3M window film installation</span></h5>
                            <legend> </legend>
                            <div class="form-group row" style="margin-bottom: 40px !important;">
                                <label class="col-lg-1 col-form-label"></label>
                                <div class="col-lg-9">
                                    <div class="panel-body" >   
                                        <div class="col-lg-6 icheck-success d-inline">
                                            <input type="checkbox" id="chkRTDWFI60" class="rtd-info">
                                            <label for="chkRTDWFI60">
                                                60%
                                            </label>
                                        </div>
                                        <div class="col-lg-6 icheck-success d-inline">
                                            <input type="checkbox" id="chkRTDWFI80" class="rtd-info">
                                            <label for="chkRTDWFI80">
                                                80%
                                            </label>
                                        </div>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control rtd-info" id="txtRTDWFIOther">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <h5><span style="font-weight: bold;margin-left:10px;">Detailing</span></h5>
                            <legend> </legend>
                            <div class="form-group row" style="margin-bottom: 40px !important;">
                                <label class="col-lg-1 col-form-label"></label>
                                <div class="col-lg-9">
                                    <div class="panel-body" >   
                                        <div class="col-lg-6 icheck-success d-inline">
                                            <input type="checkbox" id="chkRTDDetailingComplete" class="rtd-info">
                                            <label for="chkRTDDetailingComplete">
                                                Complete 
                                            </label>
                                        </div>  
                                        <div class="col-lg-6 icheck-success d-inline">
                                            <input type="checkbox" id="chkRTDDetailingGeneral" class="rtd-info">
                                            <label for="chkRTDDetailingGeneral">
                                                General  
                                            </label>
                                        </div>  
                                    </div>
                                </div>
                            </div>  

                            <h5><span style="font-weight: bold;margin-left:10px;">Gift</span></h5>
                            <legend> </legend>
                            <div class="form-group row" style="margin-bottom: 40px !important;">
                                <label class="col-lg-1 col-form-label"></label>
                                <div class="col-lg-9">
                                    <div class="panel-body" >    
                                        <div class="col-lg-6">
                                            <textarea class="form-control rtd-info" id="txtRTDGift" rows="2"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group row">
                                <label class="col-md-10 col-form-label" style="text-align: right; padding-top: 6px;" id="RTDDone">
                                    Done
                                    <div class="icheck-success d-inline" style="padding-left: 3px;">
                                        <input type="checkbox" id="chkRTDDone" style="padding-top: 6px;">
                                        <label for="chkRTDDone" style="margin-top: 6px;"></label>
                                    </div>
                                    <button type="button" class="btn btn-success" id="btnRTDSubmit" onclick="submitRTD();">Submit</button>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
    	</div>
    </section> 
</div>
<?php include '../footer.php'; ?>
<script>
    var oc_no = "<?= $oc_no ?>";

	$(function(){
        $("body").addClass("sidebar-collapse");  
        getSalesDetail();
    });

    function getSalesDetail(){
        $.ajax({
            url: APP_URL + "api/sales/sales/get_sales_detail.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {    
            $("#txtProcessing").text(data.processing);
            $("#txtSalesCenter").val(data.sales_center);

            $("#txtCustomerName").val(data.c_name);
            $("#txtCustomerNRCNo").val(data.c_nrc_no);
            $("#txtCustomerMobileNo").val(data.c_mobile_no);
            $("#txtCustomerTownship").val(data.c_township);

            $("#txtVinNo").val(data.vin_no);
            $("#txtEngineNo").val(data.engine_no);
            $("#txtParticular").val(data.particular);

            $("#txtTotalPayment").val(data.total_payment);
            $("#txtTotalPaymentPercent").val(data.payment_percent);
            $("#txtDeposit").val(data.deposit);
            $("#txtRemainingBalance").val(data.remaining_balance);

            getOneRTD();
        });
    }

    // Ready to Deliver
    function getOneRTD(){
        $.ajax({
            url: APP_URL + "api/sales/ready_to_deliver/get_one_row.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data){ 
            if(data.rtd_done==1){
                $("#RTDDone").css("display", "none");
            }

            if(data.ai_sidestep=="1"){
                $("#chkRTDAISidestep").prop( "checked", true );
            } 
            if(data.ai_floor_mat=="1"){
                $("#chkRTDAIFloorMat").prop( "checked", true );
            } 
            if(data.ai_power_tail_gate=="1"){
                $("#chkRTDAIPowerTailGate").prop( "checked", true );
            }
            $("#txtRTDAIOther").val(data.ai_other);

            if(data.wfi_60=="1"){
                $("#chkRTDWFI60").prop( "checked", true );
            }
            if(data.wfi_80=="1"){
                $("#chkRTDWFI80").prop( "checked", true );
            }
            $("#txtRTDWFIOther").val(data.wfi_other);

            if(data.detailing_complete=="1"){
                $("#chkRTDDetailingComplete").prop( "checked", true );
            } 
            if(data.detailing_general=="1"){
                $("#chkRTDDetailingGeneral").prop( "checked", true );
            }
            
            $("#txtRTDGift").val(data.gift);
        });
    }

    function submitRTD(){
        var rtd_detail = {
            "oc_no" : oc_no,

            "ai_sidestep":($("#chkRTDAISidestep").prop('checked'))?1:0,
            "ai_floor_mat":($("#chkRTDAIFloorMat").prop('checked'))?1:0,
            "ai_power_tail_gate":($("#chkRTDAIPowerTailGate").prop('checked'))?1:0,
            "ai_other":$("#txtRTDAIOther").val(),

            "wfi_60":($("#chkRTDWFI60").prop('checked'))?1:0,
            "wfi_80":($("#chkRTDWFI80").prop('checked'))?1:0,
            "wfi_other":$("#txtRTDWFIOther").val(),

            "detailing_complete":($("#chkRTDDetailingComplete").prop('checked'))?1:0,
            "detailing_general":($("#chkRTDDetailingGeneral").prop('checked'))?1:0,

            "gift":$("#txtRTDGift").val()
        };

        $("#btnRTDSubmit").attr("disabled", true);
        $.ajax({
            url: APP_URL + "api/sales/ready_to_deliver/create_update.php",
            type: "POST",
            data: JSON.stringify(rtd_detail)
        }).done(function(data){ 
            $("#btnRTDSubmit").attr("disabled", true);
            if(data.message=="updated"){ 
                getSalesDetail();
                document.location = APP_URL + "sales/sales_list.php";
            }else if(data.message=="session expire"){
                bootbox.alert("Session Expire! Please refresh the browser and login again.");
            }else{
                bootbox.alert("Error on server side.");
            }
        });
    } 
    // Ready to Deliver
</script>